# Dish Verification Protocol

This protocol is authoritative. `dish-verification-protocol-compact.md` must preserve every routing,
independence, correction, hold, approval, and submit invariant defined here; where the two diverge,
this protocol governs and the compact variant is stale until reconciled.

Decide whether the exact canonical dish task is safe, coherent, executable, supported, and ready to
sign. Do not read `dish-research-protocol.md`; this file contains the acceptance criteria needed for
independent review. Start from the task, its Planning brief, recorded evidence, and only the live
context needed to test a material claim.

Unless Marco requests read-only review, resolve every agent-owned correction the verifier can
confidently complete. **Material** means a plausible failed cook, hard-constraint breach, changed
dish or comparison, impractical execution, contradiction of a Marco decision, or false approval.

## Entry, state, and cycle

Verify only when `Status: pending-verification`. For any other status, report the next pending
action and stop. Marco's explicit `override` bypasses this gate; record exactly what was waived.

Every normal pass uses a fresh run by any agent that did not construct or materially edit the exact
candidate. A fresh run means a distinct agent invocation carrying its own `client.run_id`, not
merely a new governed operation ID or Verification cycle ID opened inside an ongoing run. Verifier
identity and agent/model family (Claude, Codex, ChatGPT, or the Custom GPT) describe who ran the
pass, not whether it was independent. A run is independent of the constructor or material editor
only when its `client.run_id` differs from the run that constructed or last materially edited the
exact candidate; the same agent, model, or verifier identity may recur across genuinely separate
runs. A new operation or cycle ID alone, issued inside the run that constructed or edited the
candidate, does not establish independence. The release frozen when the task enters
`pending-verification` governs through signoff. Verify against the exact text identified by
`Verification protocol release`; if it cannot be recovered, report the blocker and stop. Every new
cycle freezes the latest Git commit that changed this file, or without Git the SHA-256 of the exact
text plus read time.

The task contains these fields exactly once, using literal `None` where inapplicable:

```text
Status: pending-research | pending-evidence | pending-human-review | pending-verification | ready
Status detail: None | <one-sentence immediate work, evidence request, or decision>
Resume status: None | pending-research | pending-verification
Verification protocol release: None | <release>
Researched by: <agent> — <model>, <YYYY-MM-DD>
Verified by: None | <agent> — <model>, <YYYY-MM-DD>
Self-verified: None | <agent> — <model>, <YYYY-MM-DD>
```

Accept only these combinations:

- `pending-research`: detail required; resume, release, and `Verified by` are `None`;
  `Self-verified` may be `None`.
- `pending-evidence`: detail names the missing fact, why it matters, and exactly what Marco must
  provide; resume the interrupted phase. Preserve the release only when resuming Verification.
  `Self-verified` may be `None` only when resuming Research.
- `pending-human-review`: detail and resume required. Preserve the release only when resuming
  Verification. Preserve the valid `Self-verified` value from the interrupted phase; it may be
  `None` only when resuming Research.
- `pending-verification`: release and completed `Self-verified` required; detail, resume, and
  `Verified by` are `None`.
- `ready`: release, completed `Self-verified`, and completed `Verified by` required; detail and
  resume are `None`.

`Researched by` records the original constructor. `Self-verified` is `None` until an exact candidate
has been reviewed end to end by its latest material editor; afterward it records that editor.
`Verified by` records only completed independent signoff. Routine stock, thaw, soak, harvest,
sprout, and ferment-start checks remain title brackets plus `CHECK BEFORE COOKING`; they do not
change Status. `prepare` validates the destination structurally at every write, so a bad destination
normally fails Planning or Research, not Verification. If the destination becomes invalid only after
handoff — the section is renamed or removed while the task sits in Verification — the resulting
failed final move is a hard error: stop immediately, leave the task exactly as the tool left it, and
report the blocker to Marco. Do not attempt to correct the destination, retry with a guessed value,
or open a `pending-human-review` cycle for it; this follows the same rule as any other failed or
uncertain tool result.

After two independent passes without a signable task, stop: set `Status: pending-human-review` with
`Resume status: pending-verification` and the reason in `Status detail`. Only Marco's admin action
reopens it, after recording the concrete change in evidence, premise, method, or scope. This stop
exists to end repeated verification cycling; an agent never clears it by its own record. The state
lives on the task so the next reader sees that the next action is Marco's, not another pass.

## Verification

Read the whole task once as the cook standing at the stove. Check these five things in order.

### 1. It will come out as the dish

- The method produces the defining physical result: crisp rather than steamed, tender rather than
  tough, wet paste rather than dry rub, reduced glossy sauce rather than thin liquid.
- Vessel or heat-mode conversions recalculate liquid, reduction, timing, pressure release, and batch
  size instead of carrying the source method across unchanged.
- The chosen cut, form, substitute, and equipment preserve the dish's Purpose, identity, and lesson.
- Fragile components and fresh finishes are handled per sitting where batching would cost aroma,
  crispness, dryness, rawness, or absorption quality.
- Storage and reheating preserve the stated result, or the task says what must be finished fresh.
- `WHAT SUCCESS LOOKS LIKE` gives usable sensory stop points. Where a material visible boundary
  cannot be conveyed in text, exact accessible media is annotated with what to observe and ignore.

### 2. It is the agreed dish

- The candidate, Purpose, meal role, Locks, Exemptions, Research emphasis, and recorded Marco
  decisions are preserved. Exemptions use only `[nutrition-kcal]`, `[nutrition-protein]`, or
  `[nutrition-fat]`, with scope, reason, and Marco approval. A claimed decision records its route,
  scope, date, and reason.
- `WHY COOK IT`, when present, is the short plain-language Purpose; omission is valid for
  wanted-as-food.
- Role classification is binary: main is unmarked, and only a non-main task carries `[non-main]`.
  Role tags are never blocker markers. A `[non-main]` task matches the brief's `Role` and states
  which kind of non-main it is and why. A dish eaten as a lunch or dinner main stays main and uses a
  `[nutrition-*]` exemption; `[non-main]` is never a route around a nutrition limit.
- Do not re-litigate an approved intentional test or identity classification merely because a
  conventional route is safer or more authentic; its still-unknown outcome does not block `ready`.
- A genuinely disputable identity boundary goes to Human Review with the consequence and a
  recommended classification; do not invent an objective threshold.
- A comparison names one variable, its constants, and an observable result; claims already proven
  point to the prior cook.

### 3. It can actually be cooked as written

- `WHAT TO BUY`, recipe quantities, `pantry-snapshot.md`, package quantities, and usable form
  reconcile. A `[check stock]` item remains an actionable pre-cook check until Marco confirms it or
  the task plans to buy it; it does not change Status.
- Ingredient identities and forms are exact. Variable units use weight or volume where material.
  Every optional item says what omission loses. Material fresh herbs and aromatic plant parts state
  exact identity, quantity, and raw, cooked, fat-bloomed, or fresh-finish role.
- No unexplained material estimate remains; honest ordinary approximations are allowed.
- Material staged additions are executable; exact subdivisions are required only where amount or
  timing materially controls the result.
- Material ratios identify the controlling weight and source basis; arithmetic, portions, and
  scaling are coherent. A changed ingredient has not silently scaled unrelated components or portion
  count.
- Nutrition applies to main tasks only; a `[non-main]` task is out of scope. For a main task it
  covers the complete served portion. Block outside 700–1,000 kcal, below 35 g protein, or above 40
  g fat. Protein from 35 g to under 40 g, or ordinary uncertainty near 40 g, gets a non-blocking
  note. Every fat excess requires Human Review and is presumptively rejected. Only the matching
  approved nutrition exemption waives a blocking limit. Extra cheese is not used to reach protein
  unless cheese defines the dish.
- Purchase-price Human Review applies above EUR22/kg for boneless, filleted, or peeled meat/seafood;
  above EUR16/kg for bone-in or shell-on meat/seafood; and above EUR15/kg for whole fish. Use the
  purchased form and do not calculate yield. These are escalation triggers, not ceilings; staying
  below one never justifies a worse dish.
- The dish contains no pork or added alcohol; aquatic animals and derivatives are only fish and
  shrimp. A halal substitution replaces function, not only name.
- Equipment, ordered actions, timings, temperatures or pressure settings, release method, stop
  points, and fallbacks are workable. Pressure load uses the complete food-containing vessel and
  roughly two-thirds as the practical ceiling; pot-in-pot assesses the inner food vessel separately
  and outer working water is not dish liquid. Do not reject the established congee load merely for
  exceeding a generic half-full rule.

### 4. The important claims are supported

- One coherent controlling construction is used; incompatible versions are not silently blended.
- Each material source is traceable, classified as Construction or Later validation, and records
  what claim it affects. A differently formed source is not used as a ratio anchor.
- Material ratios, methods, substitutions, and adaptations have exact accessible direct support, an
  explicit close-precedent inference, or an approved test classification.
- Direct support matches the reader-facing source at the exact location. Snippets, summaries,
  inaccessible material, AI digests, and broken or placeholder locators are not direct support.
- Any substitute, including a cut or form, preserves Purpose, defining identity, and lesson; lower
  cost or easier sourcing does not justify a material compromise or bypass Human Review.
- Material composites, source departures, risky adaptations, or reversals of Marco decisions have
  the required approval and recorded rationale. A consequential overwrite explains why the strongest
  plausible reading of the established claim fails.
- Prior-cook evidence comes from the Planning brief's priors; do not read Asana cooking history.
  Priors are informational — only a `Lock` or recorded Decision binds.
- When only Marco can supply a material factual input, use `pending-evidence`, request the exact
  evidence, and resume the interrupted phase after receipt. Use Human Review only when Marco must
  choose, authorize, classify, or accept a material consequence.

### 5. The record and state are honest

- The task body, Planning brief, Decisions, Research basis, Material changes, state block,
  provenance, title markers, and destination agree. State-changing blockers and practical pre-cook
  checks have truthful, actionable markers in their proper places.
- Superseded routes are removed; technical rationale and source disagreements remain below the
  divider rather than burdening the cook's brief.
- Material changes identify date, editor/model, what changed, why, whether the change was material,
  and verification state. No open material change is presented as signed. Each entry uses this exact
  grammar:
  `<date> — <agent> — <model> — <change> — <reason> — <materiality> — <verification state>`, for
  example
  `2026-07-20 — Claude — claude-sonnet-5 — recalculated braise liquid for the pressure conversion — stovetop volume was carried over unchanged — Large — pending-verification`.
  On approval, the tool finalizes a tool-generated change-flow entry's `<verification state>` to
  `verified — <agent>, <model>, <date>`, and it stays finalized after submit; do not hand-edit it.
- `Researched by`, `Self-verified`, and `Verified by` match the current exact content and Status.
- The closing `Schema version` line is present and matches the current `SCHEMA_VERSION`. An older
  value means the task needs migration, not signoff.
- Cook-log entries distinguish Marco-confirmed observations from attributed agent hypotheses;
  unknowns remain unknown. They live outside the task body and never affect signoff.

## Result and correction routing

Keep the report short. State the verdict, then one line per material defect:

```text
<what breaks> — <where> — <Small|Large|Evidence|Human Review> — <required action>
```

Do not restate the task, narrate the pass, or list everything that passed.

- **Small:** preserves the settled construction and only makes execution compliant, including
  freshness-sensitive or per-sitting handling. It may span sections or prevent a meaningful quality
  defect. Fix it, update `Self-verified`, recheck the exact final task, and sign in the same pass.
- **Large:** materially changes identity or route; quantities, ratios, portions, or nutrition; an
  approved decision, lock, exemption, or test; or feasibility, safety, halal, sourcing, or risk. Fix
  every resolvable defect, update `Self-verified`, clear `Verified by`, freeze a new release, and
  leave `Status: pending-verification` for a fresh independent run. The correcting verifier must not
  sign that artefact.
- **Evidence:** set `pending-evidence` only when Marco must supply a factual input the agent cannot
  obtain; state exactly what is needed and why.
- **Human Review:** set `pending-human-review` only when Marco must choose, authorize, classify, or
  accept a material consequence. Preserve the frozen release when resuming Verification without a
  material edit; otherwise fix the resulting material change and start a new cycle.

Sign only the exact final content. Set `Status: ready`, retain the frozen release, and set
`Verified by` to the signing agent, model, and date. On authorized signoff, move a task currently in
the runtime-context Verification Queue to its valid recorded Destination. Do not move a rejected
task, a task in the runtime-context Research Queue, or a task manually positioned outside the
queues. Runtime context is authoritative for project and section identifiers; this protocol's text
is authoritative for workflow semantics.

## Mandatory dish-tool boundaries

Run the Verification boundary check before semantic review, after every Small or Large correction,
and immediately before signing the exact final live task. A Small correction may be signed by the
same verifier only after the corrected task is written, reread, and rechecked. A Large correction
remains `pending-verification` for another fresh independent verifier, who reruns the tool. Every
post-signoff material body edit opens a new Verification cycle. A passing approval result names
`submit` as the required next action; the verifier runs it in the same pass, while signoff and
movement remain separate recoverable operations. A tool pass never replaces semantic or provenance
review. Tool execution failures are tooling failures, not dish Evidence or Human Review blockers. On
tool/protocol disagreement, or any failed or uncertain tool result, stop, leave the task exactly as
the tool left it, and report; never repair it by hand. This protocol wins. See
`dish verification --help` for how to run this boundary check — shell-agent guidance for
Claude/Codex; the Custom GPT follows the Verification Action sequence in
`dish-custom-gpt-instructions.md`, not this help text. This protocol governs when the stage is done,
not how its Actions are called.
