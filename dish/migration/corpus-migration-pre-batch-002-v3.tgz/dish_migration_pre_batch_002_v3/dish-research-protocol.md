# Dish Research Protocol

Construct one canonical Asana dish task from its live Planning brief and hand it to independent
Verification. The cooking brief above the divider must support shopping and cooking without
repository files, prior tasks, research links, or this conversation. Resolve agent-owned research,
arithmetic, source access, and minor/local corrections without escalation. Material means plausible
failure or damage, hard-constraint breach, changed identity/comparison, impractical execution,
contradiction of a Marco decision, or false approval provenance.

## Workflow

### 1. Validate the brief and identify decisions

1. Start from the live Planning brief and task. Open another reference only when a material claim or
   blocker triggers it; cached material is evidence, not live state. Research and Verification use
   `pantry-snapshot.md`, not live pantry queries.

1. Challenge a genuinely incoherent, unsupported, unsafe, or unworkable candidate, Purpose, Lock,
   substitution, or technique before deep construction. A merely preferable route is not enough.

1. For a comparison or experiment, identify one variable, its constants, and an independently
   observable result. Confounded locks, blended outputs, or a design that cannot answer Purpose
   require Human Review before construction.

1. If a material fact cannot be established after bounded Research attempts and only Marco can
   supply it — for example a label, photo, exact product identity, or stock fact needed for
   construction — return only what is missing, why it is required, exactly what Marco must provide,
   and that Research resumes after receipt. Stop. This is `pending-evidence`, not Human Review; do
   not create a partial canonical task or send anything to Verification. Routine cook-time checks
   that a completed brief can carry under `CHECK BEFORE COOKING` are not this case.

   A pre-construction `pending-evidence` or `pending-human-review` Research hold persists through
   `dish_reject`/`reject` on the open `kind: initial` operation before `prepare`: pass
   `--route evidence|human-review`, the reason, and `--resume-status pending-research`. This does
   not reject the operation or touch the live task; it blocks the operation until Marco resolves it
   with `dish-admin supply-evidence` or `dish-admin record-human-decision` (also
   `--resume-status pending-research`), which returns the operation to `prepare_required` so
   Research resumes construction on the same operation. Do not fabricate a canonical task to
   satisfy `prepare`.

1. Once Human Review is required, return only the issue, recommended route, decision-relevant
   consequence, and question; stop research and construction until Marco answers. Record the settled
   route, scope, date, reason, and any accepted test limitation under `Decisions`, then remove
   superseded routes. Do not reopen that scoped decision without a concrete blocker outside it;
   Marco's approval settles authorization, not technical correctness. Persisted authorization for a
   change to a governed Planning fact (`Dish candidate`, `Purpose`, a `Lock`, or an `Exemption`)
   means a `Decisions` entry already recorded on the task in the `Human — Marco:` grammar, naming
   the fact, the settled route, and the date, before the change operation runs. An agent must not
   treat a chat-only or undocumented go-ahead as sufficient; if no such entry exists yet, record it
   as part of the same change.

Human Review is only for Marco's material preference, authorization, classification, or risk
acceptance: credible competing routes; a material composite; reversal of a Decision, Lock, or
Exemption; changed identity or lesson; a disputable identity boundary; meaningful cost/failure risk
(including a purchase-price trigger below or a materially unvalidated adaptation); or bounded
sourcing failure requiring a different locked candidate. Purchase-price Human Review is required
above EUR22/kg for boneless, filleted, or peeled meat/seafood; above EUR16/kg for bone-in or
shell-on meat/seafood; and above EUR15/kg for fish sold whole. The whole-fish rule controls for fish
sold whole; otherwise use the form actually purchased. Do not calculate usable yield. A material
factual input only Marco can supply is `pending-evidence`, not Human Review. Agent-owned evidence
work, source access, arithmetic, routine stock/pre-cook checks, and minor correction are also not
Human Review. For an identity boundary, recommend a classification and consequence instead of
inventing a threshold. In batch work, suppress non-decision findings.

### 2. Choose one route and establish support

- Start with a small representative credible source set. Choose one controlling common or
  authentic-leaning route unless Planning locks another direction. Expand only for a meaningful
  disagreement or evidence gap; never search until a preferred answer gains support or silently
  blend incompatible versions. A material composite requires the Human Review rule above, including
  why a coherent route is inadequate and why the identity/execution risk is worthwhile.
- An established first cook needs direct support for structure, ratios, and method; a differently
  formed source is not a ratio anchor. Direct support requires a literal reading confirmed against
  the exact reader-facing location; snippets, summaries, related pages, AI digests, hidden/stale
  extraction, and broken placeholder citations such as `:contentReference[...]` do not qualify.
  Replace a broken locator before completing Research or Verification.
- Classify consequential construction as direct support, close-precedent inference, or an
  unvalidated test. A related source supports only an explicitly named close-precedent inference.
  When the page cannot be confirmed, use Marco-supplied text he confirms represents it or treat the
  support as missing.
- Normalize material ratios to the controlling weight and record source basis, task weight, scale
  factor, conversion, and result. Mark unchecked estimates `[approx]`; a source opened only after
  construction is `Later validation`.
- Before overwriting an established consequential claim, verify units and arithmetic, reconcile
  sources, Cooking History, Marco decisions, and current task state, and record why the strongest
  plausible existing reading fails. If proof fails, do not overwrite.
- Preserve all eight Planning fields and literal exemption tags. Answer every Research emphasis
  using its stated decision criteria. `WHY COOK IT` is the short plain-language Purpose, omitted
  when the dish is simply wanted as food; detailed support belongs below the divider.
- Apply halal policy before substitutions: no pork or added alcohol; aquatic animals and derivatives
  are only fish and shrimp. Use the relevant specialist reference and replace the prohibited
  ingredient's function, not only its name. Any substitute must preserve the dish's Purpose,
  defining identity, and lesson; lower cost or easier sourcing does not justify a material
  compromise or bypass Human Review. Disclose a substitution as close-enough or a real compromise;
  for a compromise, name what is lost and what to notice.
- For fish, use sufficiently current prices in `halal-seafood.md` or current local sellers. Compare
  usable yield when bone, skin, shell, trim, or product form differs; glaze alone is excluded. Make
  a budget-leaning choice that still serves the dish and lesson, and record the trade-off.

### 3. Construct the dish and write the canonical task

Work in this order; do not write the final brief first and retrofit these decisions afterward.

1. **Resolve sourcing and quantities.** Use `pantry-snapshot.md`. Research credible EU sourcing or
   substitution when availability is unresolved. Reconcile recipe use, snapshot stock, usable
   yield/trim, and package or minimum-purchase quantity. A `[check stock]` item requires Marco's
   physical check or a purchase plan. A defining or specialist ingredient must be sourced, credibly
   replaced, or deliberately removed before Research completes. If bounded attempts find no
   plausible consumer channel or only materially unsuitable/wasteful forms, apply the Human Review
   rule rather than leaving an indefinite sourcing gap. Reconcile each quantity by function, usable
   yield, and portions rather than blanket multiplication.
1. **Design ingredients and execution.** Use exact ingredient forms and quantities measured as they
   will be used; variable units are controlled by weight or volume and count only guides. Explain
   departures from source or stocked form and why each optional item is optional, including what
   omission loses. Treat fresh herbs and aromatic plant parts as flavour variables with exact
   identity, quantity, and raw/cooked/fat-bloomed/fresh-finish role. Choose the cheapest cut or form
   that preserves the dish's function, identity, and lesson; then apply the price threshold. Do not
   use a materially different cheaper option to avoid Human Review. Prefer whole spices ground for
   the dish except those normally stored ground; do not default to premade blends, and name their
   spices unless Marco requests a shortcut or it is his deliberate blend. Bought condiments are
   valid when normally bought or playing that role; weigh a quick from-scratch paste against time
   friction. Match sauce intensity to protein fat/delicacy and avoid freshness-wasting surplus paste
   or ground spice. State executable fallbacks, separately measured staged additions, pressure
   liquid/release, stop points, and equipment limits. Use kitchen-validated `equipment.md` settings
   or justify a departure. Recalculate liquid when converting between stovetop reduction and
   pressure retention; assess whether pressure suits the mechanism.
1. **Set portions, nutrition, and precedent.** Default to three substantial portions, not
   deliberately light or low-carbohydrate servings. Separate durable batch cores from fragile parts
   finished per sitting; repeat sittings only for a real variable. Nutrition targets apply to main
   tasks only; a `[non-main]` task is out of scope. For a main task, record calories, protein, and
   fat per complete portion and construct toward 750-900 kcal, at least 40 g protein, and at most 40
   g fat by scaling the dish, protein, natural starch, or accompaniment where possible. Any result
   above 40 g fat requires Human Review and is presumptively rejected. Keep pasta, risotto, and
   similar dishes light on cheese unless cheese defines them; never use cheese merely to reach
   protein. For comparisons, name one variable, constants, and observable. Prior-cook evidence comes
   from the Planning brief's priors; do not read Asana cooking history. Link proven claims to the
   prior cook the brief names.
1. **Define finish and failure boundaries.** Storage/reheating must preserve the intended result
   across stated sittings, or say what is finished fresh. Give sensory boundaries for the dish and
   critical stages. Add media only when text cannot carry a material visible boundary. A partial
   analogue is valid only when its transferable boundary is explicit. Verify the exact
   logged-out/private media and annotate what to observe, what it supports, and what differs and
   must be ignored.
1. **Write the canonical task.** Use every required section exactly once and an optional section
   only when it carries information. Role classification is binary and comes from the brief's
   `Role`: main is the unmarked default, and only a non-main task carries `[non-main]`, stating
   which kind of non-main it is and why. Role tags are not blockers. Give every system blocker and
   pre-cook dependency its own short title bracket. Put active research, pending evidence, or
   Human-decision work in `Status detail`; a destination defect stays in the title and
   `Destination section`. Pre-cook brackets stay in `CHECK BEFORE COOKING` and do not change task
   state. `Status` is the sole readiness field.

```text
<`[non-main]` when applicable and compact bracket markers> <Dish name> — <plain-English recognition phrase>
<What it is, how it eats, and its meal role.>
WHY COOK IT
<Concrete gap, technique, comparison, seasonal use, or repeat correction. Omit if simply wanted as food.>
## WHAT TO BUY
<Only items to buy, with quantities; write `None - pantry snapshot lists required items in stock`
when nothing is needed.>
## CHECK BEFORE COOKING
<Stock, harvest, thaw, soak, advance-prep, and timing dependencies; exact identity/quantity,
lead time, and fallback or postpone rule. Omit if empty.>
## QUANTITIES
Portions: <n or one sitting; explain a departure from the default 3>
<Complete ingredient list with amounts and exact identities.>
## HOW TO COOK IT
<Executable ordered steps, mise en place, timing, stop points, equipment limits, and fallbacks.>
## WHAT SUCCESS LOOKS LIKE
<Sensory boundaries for the dish and critical intermediate stages; annotated visual when needed.>
## WATCH OUT FOR
<Only failures that could materially damage the dish. Omit if none.>
## STORAGE
<Only for multiple sittings or a real storage/reheating risk. Omit otherwise.>
---
## PROCESS RECORD
Status: pending-research | pending-evidence | pending-human-review | pending-verification | ready
Status detail: None | <one-sentence immediate work, evidence request, or decision>
Resume status: None | pending-research | pending-verification
Verification protocol release: None | <release>
Researched by: <agent> — <model>, <YYYY-MM-DD>
Verified by: None | <agent> — <model>, <YYYY-MM-DD>
Self-verified: None | <agent> — <model>, <YYYY-MM-DD>
### Planning brief
Dish candidate: <selected dish or variant>
Purpose: <learning target, comparison, gap, test, or wanted-as-food reason>
Role: main | non-main — <what kind of non-main and why; omit the dash clause for main>
Priors: None | <prior cook and what it established>
Locks: None | <settled dish-specific outcome or boundary - reason>
Exemptions: None | [nutrition-kcal] [nutrition-protein] [nutrition-fat] — <scope, reason, Marco approval>
Research emphasis: None | <question or comparison, decision criteria, and evidence Research must establish>
Destination section: <non-queue Cooking section name and gid>
### Decisions
Human — Marco: <settled material choice, scope, date, and reason. Omit the whole subheading if none.>
### Research basis
Classification: <Source-backed dish; Halal port of <dish>, human-approved; or Intentional test
dish, human-approved>
<For every materially used, conflicting, or rejected source: traceable locator; Construction or
Later validation; claim/ratio/method/adaptation affected; disagreement, chosen route, reason, and
any non-blocking future test.>
### Material changes
<Date, editor/model, what changed, why, whether the change was material, and whether independently
verified. Omit if none.>
Schema version: <version>
```

Required exactly once: title, recognition line, `WHAT TO BUY`, `QUANTITIES`, `HOW TO COOK IT`,
`WHAT SUCCESS LOOKS LIKE`, `PROCESS RECORD` and its seven fixed state/self-review labels, all eight
Planning fields, `Research basis`, and the closing `Schema version` line. The other displayed
sections are optional when empty. Add no other top-level heading, process-record label, or exemption
tag.

`Verification protocol release`, `Researched by`, `Verified by`, and `Self-verified` are written by
the tool, not by the agent; whatever you supply for these is replaced with authoritative runtime
values. "Exact content" does not mean these four tool-owned fields survive unchanged from a
submitted `file_text` — use the post-write content the tool returns or `read` back, not the
pre-write submission, for identity or verification checks against them. Take `Priors` content only
from the brief's own text — do not open the prior tasks it names.

An Action-based change flow (`dish_start`/`start` with `kind: change`) carries two distinct
controls: `change_level`/`change_reason` on `start` (small vs. large correction), and
`material_classification` on `prepare` (material vs. non-material). Do not conflate them.

`material_classification: material` invalidates existing signoff, generates the `Material changes`
entry from `change_reason`, freezes a new Verification cycle, and requires fresh independent
Verification. Do not author or edit that entry in `file_text`; the tool generates it from
`change_level`/`change_reason` in this grammar:

```text
<date> — <agent> — <model> — <change> — <reason> — <materiality> — <verification state>
```

For example:

```text
2026-07-20 — Claude — claude-sonnet-5 — recalculated braise liquid for the pressure conversion — stovetop volume was carried over unchanged — Large — pending-verification
```

`<materiality>` is `Small` or `Large`. On approval, the tool finalizes the generated entry's
`<verification state>` from `pending-verification` to `verified — <agent>, <model>, <date>`, and
that finalized entry persists after submit. Do not hand-edit this field at any point; the tool owns
it end to end.

`material_classification: non-material` applies the edit directly, preserves the existing
signoff/Status/destination, generates no `Material changes` entry, and skips Verification entirely.
Because it bypasses independent Verification and leaves no audit trail, use it only for an edit that
is not material under this protocol's own definition (plausible failure or damage, hard-constraint
breach, changed identity/comparison, impractical execution, contradiction of a Marco decision, or
false approval provenance — see the opening paragraph). Any edit meeting that definition must use
`material_classification: material` regardless of how small it looks; never choose `non-material` to
avoid reopening Verification.

### 4. Set state, self-review, and hand off

Use the fixed state block exactly as shown above. Every line is always present and uses `None` when
inapplicable; a transition rewrites the complete block. `Researched by` records the original
constructor. `Self-verified` is `None` until an exact candidate has been reviewed end to end by its
latest material editor; afterward it records that editor. `Verified by` remains `None` until
independent signoff. These are the only valid combinations:

| Status                 | Required state fields                                                                                                                                                     | State action                                                                                                                                                       |
| ---------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| `pending-research`     | `Status detail`; release and `Verified by` `None`; `Self-verified` may be `None`                                                                                          | Continue initial agent-owned research, construction, arithmetic, support, or exact-content self-review. Broken or placeholder citations count as missing support.  |
| `pending-evidence`     | Exact evidence request; `Resume status`; preserve release only when resuming Verification; `Verified by: None`; `Self-verified` may be `None` only when resuming Research | Stop for the exact material fact only Marco can supply. If no canonical task exists yet, return only the request; do not create a partial canonical task.          |
| `pending-human-review` | `Status detail`; `Resume status`; preserve the valid `Self-verified` value from the interrupted phase; it may be `None` only when resuming Research                       | Stop on the exact material decision. Preserve the frozen release only when resuming `pending-verification`; otherwise it is `None`.                                |
| `pending-verification` | Frozen protocol release; completed `Self-verified`; `Verified by: None`; detail/resume `None`                                                                             | The exact current content is complete and self-reviewed. It awaits a fresh independent verification run by any agent that did not construct or materially edit it. |
| `ready`                | Frozen protocol release; completed `Self-verified` and `Verified by`; detail/resume `None`                                                                                | A fresh independent run by any agent signed the exact current content. An approved intentional test's still-unknown outcome is not a blocker.                      |

Apply these condition rules once; local policy must not restate their state effects:

| Condition                                                                                 | Action and record                                                                                                                                                                                                                             |
| ----------------------------------------------------------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Initial research, source access, construction, or self-review remains                     | Use `pending-research`; name the exact remaining work in `Status detail`; do not guess.                                                                                                                                                       |
| A material factual gap remains after bounded attempts and only Marco can supply it        | Use `pending-evidence`; request the exact evidence, explain why it is needed, and record the interrupted phase. If no task exists, return only the request. Resume that phase after receipt.                                                  |
| A genuine material decision remains                                                       | Use `pending-human-review`; name the decision and resume phase. Record the resolved route, scope, date, and reason under `Decisions`. Resume the recorded phase when no material edit is needed.                                              |
| A verifier makes a Small correction                                                       | The verifier may fix, self-review, independently recheck the exact final task, and sign in the same pass.                                                                                                                                     |
| A verifier makes a Large but resolvable correction                                        | The verifier fixes it, records the change, updates `Self-verified`, clears `Verified by`, freezes a new protocol release, and leaves `Status: pending-verification` for a fresh independent verifier.                                         |
| A verifier cannot resolve the issue without Marco                                         | Use `pending-evidence` for a missing fact or `pending-human-review` for a choice, authorisation, classification, or accepted risk. Do not bounce the task back to Research.                                                                   |
| A material edit follows signoff                                                           | The editor corrects and self-reviews the exact task, records the edit, clears `Verified by`, freezes a new release, and sets `Status: pending-verification` for fresh independent signoff.                                                    |
| Destination name or gid fails `prepare` (`destination_unresolved`/`destination_mismatch`) | Correct it immediately from the current runtime `sections` response and resubmit; never invent a destination. `prepare` rejects a bad destination structurally at the point of write, so this blocks progress there, not only the final move. |
| A routine pre-cook item remains                                                           | Keep its title bracket and actionable `CHECK BEFORE COOKING` instruction. Do not change any state field.                                                                                                                                      |

Every entry into `pending-verification` freezes the then-current Verification protocol release. The
correcting agent must not sign its own Large correction; a fresh independent run must verify the
corrected artefact. A material edit makes prior signoff stale; do not create a second mirrored
open-change status.

Before handoff, reconcile the Planning brief with the title, cooking brief, quantities, Decisions,
markers, state block, provenance, and material changes. The task lives in the Cooking project named
by the tool runtime context. Move only the runtime-context Research Queue → the runtime-context
Verification Queue, and only after Research/self-review. Later corrections belong to Verification.
Runtime context is authoritative for project and section identifiers; this protocol's text is
authoritative for workflow semantics. After signoff, move only a task currently in Verification
Queue to its valid destination. A task outside both queues is a manual override and is not moved.
Research does not read `dish-verification-protocol.md`.

## Mandatory dish-tool boundaries

Run the Research pre-handoff check against the exact live candidate. Correct Research-owned failures
and write and reread the complete task through the dish tool, then run the handoff transition/check
against the resulting exact `pending-verification` task before any queue move. Any
`Material changes` entry follows section 3's grammar and ownership rule above: write it directly
only outside an Action-based change flow; inside one, the tool generates and owns the entry and
rejects an agent-authored version in `file_text`. A pass is necessary but does not replace Research
judgment or self-review. Tool execution failures are tooling failures, not dish Evidence or Human
Review blockers. On tool/protocol disagreement, or any failed or uncertain tool result, stop, leave
the task exactly as the tool left it, and report; never repair it by hand. This protocol wins. See
`dish research --help` for how to run this boundary check — shell-agent guidance for Claude/Codex;
the Custom GPT follows the Research Action sequence in `dish-custom-gpt-instructions.md`, not this
help text. This protocol governs when the stage is done, not how its Actions are called.

A passing `prepare` result establishes deterministic canonical structure and state only. It does not
establish source credibility, premise validity, nutritional adequacy, halal correctness, or any
other semantic or substantive judgment — those remain Research's and Verification's responsibility
regardless of tool acceptance.
