# Dish Planning Protocol

This governs the compact dish design handed from collaborative planning to research.

## Plan

Planning is the main dish-design and Human Review stage. Produce one coherent proposal covering the
dish, purpose, eating experience, and defining outcomes or boundaries. State the real current
reason: a cuisine or format gap, technique or palate step, comparison or correction,
sourcing/cultivar test, or wanted-as-food. If a candidate is off-priority, say so rather than
inventing strategic value. Keep it short — supporting evidence and citations remain downstream.
Unless Marco explicitly asks for an uncooked dish, `new` or `next` does not exclude repeats; choose
the dish with the most value now.

Defaults:

- Plan for Marco's usual solo use.
- Default to three portions, but separate durable batch cores from fragile components made or
  finished per sitting. A mostly fragile dish may honestly yield one sitting.
- Separate sittings may test a named calibration variable; they must not disguise a storage problem.
- About 800 kcal and 50 g protein per served portion is a Planning aim for a main dish, not an
  acceptance test or a request to calculate nutrition. It does not apply to a non-main dish.
- Do not default to low-carbohydrate or light portions. Flag likely exceptions for Marco; Research
  owns exact construction and calculation.
- Marco prefers pasta, risotto, and similar dishes light on cheese unless cheese defines the dish.
  Do not use extra cheese as a lever to meet the protein aim.
- Keep red meat to roughly one dish per week; flag explicitly when recommending beef or lamb.

Use prior culinary knowledge when plausibly sufficient. Work through obvious credible choices
silently, including familiar halal substitutions or cuts; do not narrate options or ask serial
questions. Search externally only when a material Planning choice depends on an uncertain, niche, or
current fact; do not treat the first result as authority. Front-load genuine design judgments: give
Marco the issue, recommendation, and only the reason or consequence needed for his decision.

Planning does not construct the recipe or settle exact authenticity, ratio, sourcing, equipment,
substitution, or method claims; Research does. Use `Research emphasis` for technical uncertainty.
For an uncommon or technically non-obvious dish or method, include the precedent or source that
informed the choice when known; otherwise mark the premise as unverified for Research. Consult
sister dishes only when progression, comparison, a format gap, or a repeated lesson matters.

## Grounding

Ground the proposal in current project state using only matching sections:

- For an ingredient-first request with no named cuisine, use `planning/index.md`'s cross-cutting
  trigger before opening cuisine docs. When the choice depends on allocating a homegrown herb or
  other ingredient across cuisines, read only the relevant rule in `culinary-planning.md`, then open
  a cuisine doc only after a candidate needs its trajectory or evidence.
- `planning/index.md` to find the one relevant cuisine/cuisine-group doc, then that doc for
  trajectory, traps, purpose, prior cooks, and lessons, following a cited task only when needed.
  Named cuisine: open its one local doc; fish-based, also open `planning/fish.md`. For an unscoped
  fish request, open `planning/fish.md` first and open a cuisine doc only when a candidate needs its
  context or the fish doc yields no actionable direction. For other genuinely unscoped requests, the
  index may select up to two or three plausible local docs. Read a global-tier doc
  (`cuisine-map.md`, `culinary-planning.md`'s cross-cutting section, `dish-classes.md`) only on a
  named cross-cuisine strategic or class-comparison need — a sister-dish/dish-class check or a
  comparative-block question.
- If the local-tier docs above (index + cuisine doc(s) + `planning/fish.md` if applicable) produce
  no actionable candidate — no named gap, no ranked backlog item, nothing to converge on — open the
  relevant global-tier doc(s) (`cuisine-map.md`, `culinary-planning.md`'s cross-cutting section,
  `dish-classes.md`) to find one, rather than stalling or guessing a cuisine to force a fish-based
  (or similarly cross-cutting) request into.
- Use `pantry-snapshot.md` for pantry and fermentation availability; do not query live Asana. A
  `[check stock]` item requires Marco to check the physical stock before cooking, so carry that
  check into the task. Treat an item absent from the snapshot as something to buy.
- Read `produce-reference.md` only when seasonal timing or local-substitute fidelity materially
  affects dish selection or sequencing.
- Check broad feasibility. If a candidate materially depends on an oven, rice cooker, strong wok
  heat, unusual vessel capacity, or generous refrigerator storage, read only the relevant part of
  `equipment.md`, flag the issue, and leave exact adaptation to Research.
- Assume refrigerator space is limited and freezer space is comparatively available. Carry a
  material consequence in `Locks` or `Research emphasis`.
- Planning is the only stage that reads Asana cooking history. When a prior Cooking or Cooking
  History task materially supports the choice, inspect its comments as well as notes and state, and
  carry what matters into the brief as a prior. Research and Verification read the brief, not Asana.
  Read history through the general `asana` CLI; the dish tool does not mediate it.
- Priors are informational, not binding. Research may judge one immaterial and proceed without Human
  Review. A prior Marco discussed and endorsed becomes a `Lock` or a recorded Decision through the
  existing route, and binds from there.
- When auditing a cuisine backlog, include `Eating` and `Planned`. Treat `due_on` as the planned
  cook date and sequencing signal, never as evidence that cooking occurred.
- No pork or added alcohol; aquatic animals and derivatives are only fish and shrimp. If the dish's
  traditional form uses a non-halal ingredient or requires a substitution, read the relevant halal
  file (`halal-alcohol.md`, `halal-meat-substitutions.md`, or `halal-seafood.md`) before finalizing,
  for the function, substitution, cut, and price trade-offs.
- When Planning selects a substitution, disclose it as close-enough or a real compromise; for a
  compromise, name what is lost and what Marco should notice when tasting.

Before proposing an agent-selected or near-term dish, flag material stock, sourcing, seasonality,
equipment, or timing problems. For long-range planning, check basic viability but defer volatile
stock checks.

Do not reopen a named dish absent material evidence. For an open prompt, first form a small,
constraint-compatible comparison set matching the requested breadth, then compare grounded
candidates. One actionable documented candidate may stop further document loading; it does not
replace that comparison. Resolve supported stock, halal, cut, and price choices in the proposal;
send unresolved technical questions to Research with the decision criteria and evidence it must
establish.

## Handoff

Use one canonical task in the Cooking project named by the tool runtime context. Assume the dish
does not already exist; no duplicate search is required.

Create a new task in the runtime-context Research Queue and preselect its non-queue destination
after verification. Never move an existing task outside the runtime-context Research Queue and
Verification Queue; its section is a manual override. Resolve the selected destination's name and
gid by copying them verbatim from the current `sections` (or equivalent runtime `start`/`create`
response) the tool returns for this run — never from memory, a prior task, or an assumed value.
`prepare` validates the destination immediately against Cooking: a nonexistent gid fails with
`destination_unresolved`, and a name/gid pair that does not match fails with `destination_mismatch`.
Correct and resubmit from the current runtime `sections` response before Planning can complete; this
is a normal Planning-owned correction, not a defect that reaches Research or Verification. Write the
brief through the dish tool itself, never through the `asana` CLI or any other route. Runtime
context is authoritative for project and section identifiers; this protocol's text is authoritative
for workflow semantics. Normally select the cuisine or cross-cutting section that owns the dish; for
an unscoped fish dish, use Fish. Use Planned only when Marco explicitly intends to cook the dish
soon, never merely because Planning created it. If no owning section fits and the dish is not
near-term, obtain Human Review rather than forcing an unrelated lane.

Write only:

```text
### Planning brief
Dish candidate: <selected dish or variant>
Purpose: <learning target, comparison, gap, test, or wanted-as-food reason>
Role: main | non-main — <what kind of non-main and why; omit the dash clause for main>
Priors: None | <prior cook and what it established>
Locks: None | <settled dish-specific outcome or boundary - reason>
Exemptions: None | [nutrition-kcal] [nutrition-protein] [nutrition-fat] — <scope, reason, Marco approval>
Research emphasis: None | <uncertain premise, question, or comparison; acceptance/failure boundary;
evidence Research must establish; and which Planning choice failure would reopen>
Destination section: <section name> — <section gid>
```

Planning assigns `Role`. The test is what the dish is, not whether it meets nutrition targets. A
dessert, a small side, or a little test dish is `non-main`, and nutrition targets do not apply. A
real lunch or dinner main that misses a limit stays `main` and takes the matching `[nutrition-*]`
exemption with Marco's approval. Never use `non-main` to avoid a nutrition limit. A `non-main` brief
must say which kind it is and why, because the title tag is what Marco scans to see whether a dish
is a candidate for a meal. Reclassifying main to non-main is an identity claim and belongs to
Planning, not to Research or Verification.

`Dish candidate` and `Purpose` are locks. Other locks fix defining outcomes, not unsupported claims
or construction details. `Research emphasis` fixes a question, not its presumed answer; do not put
an unverified route into `Locks`. Planning may seek advance Human Review when it recognizes a
material lock that Research is likely to challenge; routine locks need no approval.

An exemption waives only its literal named nutrition default and requires Marco's approval for its
scope and reason. Meet every untagged limit unless it distorts the lesson; scrutinize high-fat
exemptions. Material cost or unusual risk may need Human Review but is not an exemption.

Research may change construction inside the locks. If material evidence indicates that a lock is
incoherent, unsupported, unsafe, or unworkable, Research must stop for Human Review before changing
or constructing around it; a merely preferable route is not enough. The existing field governs until
any change is approved. Planning is complete when all eight fields guide Research without
prescribing the recipe. It needs no separate verification.

## Mandatory dish-tool boundary

Before handing the exact live Planning task to Research, run the Planning boundary check through the
dish tool. Correct and rerun failures that Planning owns. A passing tool result establishes
deterministic structural conformance only; it does not establish substantive plan quality or
authorize handoff by itself. Tool execution failures are tooling failures, not dish Evidence or
Human Review blockers. On tool/protocol disagreement, or any failed or uncertain tool result, stop,
leave the task exactly as the tool left it, and report; never repair it by hand. This protocol wins.
See `dish planning --help` for how to run this boundary check — shell-agent guidance for
Claude/Codex; the Custom GPT uses its Dish Actions directly, not this help text.
