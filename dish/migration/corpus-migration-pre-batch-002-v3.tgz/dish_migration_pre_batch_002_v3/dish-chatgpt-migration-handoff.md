# Handoff: prepare the legacy Cooking corpus for a new Dish-managed project

## Objective

Prepare migration artifacts from the existing Asana **Cooking** project into a separate new
Cooking project. The existing project will remain intact as the legacy snapshot. Do not edit,
move, rename, complete, reopen, or otherwise mutate any task in it.

Your job is the token-heavy inspection and document transformation. Do **not** perform the Asana
import. A deterministic migration script will later create new tasks in the new project from your
validated output.

If anything is ambiguous, unsupported, internally contradictory, or absent from the source task,
**stop on that task and ask Marco**. Do not make a plausible guess. Marco will relay technical
questions to Codex when needed.

## Authoritative inputs

- Legacy Asana project: `Cooking`, GID `1215089183018968`.
- Expected inventory: exactly 110 tasks: 7 stay legacy, 4 are copied unmanaged, and 99 are
  transformed for Dish governance.
- Marco is independently reviewing which tasks need Research, need Verification, or may retain
  accepted readiness. Do not override his decisions with your earlier classification.
- Use the final rollout versions of these files, supplied by Marco, as the canonical format and
  workflow authority:
  - `dish-task-schema.json`
  - `dish-planning-protocol.md`
  - `dish-research-protocol.md`
  - `dish-verification-protocol.md`
  - `dish-cooking-protocol.md`

If those exact files are not available in the conversation, stop and request them before producing
canonical documents.

## Fixed disposition

The classification below is settled. Do not reclassify tasks.

### Stay only in the legacy project — 7 tasks

Create no replacement for these tasks:

1. `1215259129474847` — REFERENCE — READ FIRST — Cooking master prompt
2. `1215762601703344` — Milan trip
3. `1215097105113595` — Dried daun salam
4. `1215097330853278` — Candlenuts
5. `1215910933307710` — Repeat Sichuan dry mixed noodles — second calibration
6. `1216473809122819` — Sun-dry shop-bought apricots for tagine comparison
7. `1215097359127070` — Pomegranate molasses track

The six non-reference tasks are completed records. Leave all seven untouched.

### Copy to the new project but leave unmanaged — 4 tasks

These will be created in the new project as ordinary Asana sourcing/infrastructure tasks. Preserve
their names and notes exactly; do not convert them to the Dish schema:

1. `1216473814231134` — Butcher asks — halal cuts to request
2. `1216575066624337` — Fresh eel (anguilla)
3. `1215100222493847` — Whole black urad / urad sabut
4. `1215097887456674` — Niboshi

### Transform for Dish governance — 99 tasks

Every other task in legacy Cooking belongs in this category. Reconcile the inventory before doing
content work: the three categories must total exactly 110 and the governed set must contain exactly
99 unique source GIDs.

## Critical workflow correction

There is no generic **blocked** Dish state and no `verified-but-blocked` state.

The current allowed statuses are:

- `pending-research`
- `pending-evidence`
- `pending-human-review`
- `pending-verification`
- `ready`

Ingredient availability, shopping, season, harvest, soaking, fermentation maturity, timing, and
equipment availability do not by themselves prevent `Status: ready`. Put practical prerequisites
in `WHAT TO BUY` or `CHECK BEFORE COOKING`. They describe whether Marco can cook the dish today;
they do not undo completed governance.

Use `pending-evidence` or `pending-human-review` only for the narrow meanings defined by the current
protocols: an exact material fact only Marco can supply, or an actual unresolved material Human
decision. Never use either as a generic blocker.

The legacy `CAN I COOK IT?` line is not an authority in the new schema. Do not carry it forward as
a second readiness field. Current `Status` is the sole readiness field. Marco's review of Research
and Verification evidence determines the migrated status.

## Transformation rules

### Pre-ingestion holds

Before transformation, preserve source order and apply these non-Dish ingestion controls:

- Every governed task currently in legacy `Planned` is captured in an ordered inventory with
  `ingestion_hold: planned-policy-pending`. Do not transform or import it until Marco decides how
  the near-term shortlist will work.
- Every governed task currently in legacy `Korean` is captured in an ordered inventory with
  `ingestion_hold: korean-deferred`. Preserve source GID, exact name, source order, and notes
  unchanged. Do not reshape or import it.
- Every manifest record must contain `ingestion_hold`, whose value is exactly `null`,
  `planned-policy-pending`, or `korean-deferred`.
- Holds are pre-ingestion controls, not Dish statuses. Do not encode them as canonical Dish state.

### Planning-format tasks after hold release

Legacy Planning tasks use substantially different prose and cannot be reformatted mechanically.
Only after `planned-policy-pending` is released, reconstruct the current eight-field Planning brief
from explicit source facts:

1. Dish candidate
2. Purpose
3. Role
4. Priors
5. Locks
6. Exemptions
7. Research emphasis
8. Destination section

Do not turn an unresolved route into a Lock. Do not invent Priors, exemptions, nutrition waivers,
Human approval, or a Role when the evidence does not support it. If a required field cannot be
filled without judgment, stop on that task and ask Marco.

### Decisions and legacy process history

- Preserve explicit, materially relevant decisions actually made by Marco.
- Current canonical Human decision grammar is `Human — Marco:`. Some legacy tasks say
  `Human — Moinudin`. Do not normalize identity silently; ask Marco once whether all such entries
  are his decisions and record his answer as a corpus-wide rule.
- Use settled dish boundaries to inform Planning `Locks` where appropriate.
- Put agent construction reasoning and source reconciliation in `Research basis`, not `Decisions`.
- Do not copy all `Agent — ...` lines mechanically.
- Do not manufacture Dish audit history, `Material changes`, provenance, independent signoff, or
  durable Verification evidence from legacy narration.
- Do not invent dates, models, contract identifiers, approvals, or reasons.
- When useful legacy information has no safe canonical home, flag it instead of discarding or
  relocating it by guesswork.

### Destination

Propose the destination **section name** from explicit task identity and current placement:

- A task already in a non-queue cuisine/cross-cutting section will normally retain that destination.
- An unscoped fish dish may use Fish, as defined by the Planning protocol.
- A task in Planned, Research Queue, or Verification Queue needs its actual eventual destination;
  the queue or generic holding section is not automatically its destination.
- Planned is a destination only when Marco explicitly intends to cook the dish soon.

Do not invent section GIDs or copy them from memory. The migration tooling will resolve proposed
section names against the new project's live section registry. Flag any destination that is not
clear.

### Research, Verification, and readiness

Marco is reviewing these judgments. Treat his per-task result as authoritative input. Until he has
decided a task, mark its migration result as awaiting Marco review rather than selecting a status
yourself.

In particular:

- A complete executable brief with unaccepted or stale independent Verification is
  `pending-verification`.
- A legacy practical sourcing condition does not turn accepted Verification into a blocked state.
- Notes alone cannot create Dish durable Verification evidence. Record the legacy evidence exactly
  for review, but do not claim that the new Dish system has accepted or imported it.

## Required output

Produce downloadable machine-readable artifacts, not only prose in chat.

### Migration manifest

Create one manifest record per source task with at least:

```json
{
  "source_gid": "decimal Asana task GID",
  "source_name": "exact source task name",
  "disposition": "stay_legacy | copy_unmanaged | copy_governed",
  "ingestion_hold": "null | planned-policy-pending | korean-deferred",
  "proposed_target_name": "exact proposed target name or null",
  "proposed_target_section_name": "section name or null",
  "proposed_status": "allowed Dish status or null",
  "status_authority": "Marco-reviewed | awaiting-Marco-review | not-applicable",
  "document_file": "relative file path or null",
  "ambiguities": [],
  "migration_notes": []
}
```

Use `null` rather than guessing. Maintain exactly one record per source GID.

### Full inventory gate

Produce and reconcile the complete 110-row inventory manifest before further transformation batches.
Documents may be batched only after the full inventory proves the 7/4/99 disposition and identifies
all Planned and Korean holds.

### Task documents

- Do not create transformed documents for records under an ingestion hold.
- For each released `copy_governed` task, create one UTF-8 text or Markdown migration template. Use:

```text
## PROCESS RECORD
{{MIGRATED_DISH_STATE_BLOCK}}
### Planning brief
...
```

  Record exact legacy state and Verification claims and Marco's reviewed classification in the
  manifest. Do not convert legacy narration into canonical Dish evidence. The importer replaces the
  placeholder and validates before upload. Never upload any document containing
  `{{MIGRATED_DISH_STATE_BLOCK}}` or `{{TARGET_SECTION_GID}}`.
- For each `copy_unmanaged` task, preserve the exact source name and notes in the manifest/artifact
  package without normalization.
- Do not create documents for `stay_legacy` tasks.
- Do not include target Asana GIDs; those do not exist until import.

### Exceptions report

Maintain a compact report of every stopped task:

```text
Source GID | Task | Exact ambiguity | Source evidence | Decision needed from Marco
```

Ask questions in small coherent batches, but do not continue transforming an affected task while
its answer is unknown. Continue with unrelated unambiguous tasks when safe.

### Reconciliation report

At completion report:

- source inventory count;
- count and GIDs for each disposition;
- governed documents produced;
- unresolved task count and GIDs;
- duplicate or missing GIDs;
- any source task that changed while you were inspecting it.

## Prohibited actions

- Do not mutate the legacy Cooking project or any source task.
- Do not create or edit target-project tasks; the import script owns writes.
- Do not reclassify the fixed 7/4/99 disposition.
- Do not infer or fabricate readiness, verification, provenance, Human decisions, destination, or
  canonical fields when evidence is insufficient.
- Do not treat availability as workflow state.
- Do not silently discard contradictions.
- Do not claim that a transformed document has become Dish-managed merely because it validates as
  text; Dish durable-state initialization is a separate migration concern.

## Working posture

Accuracy and reversibility matter more than completing all 99 tasks in one uninterrupted pass. When
you encounter an unknown, say exactly what is missing, show the smallest relevant source excerpt,
and ask Marco. He will answer directly or relay the technical question to Codex.
