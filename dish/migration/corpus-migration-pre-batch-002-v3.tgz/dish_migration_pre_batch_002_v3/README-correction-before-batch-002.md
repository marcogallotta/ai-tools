# Corrections completed before Batch 002

- Embedded handoff replaced with the corrected pre-ingestion-hold version.
- Removed the invalid “process Planned last / default Planned destination” corpus rule.
- Produced the complete 110-row inventory manifest before further transformations.
- Added `ingestion_hold` to every record.
- Applied `planned-policy-pending` to 5 governed tasks in legacy Planned.
- Applied `korean-deferred` to all 6 governed tasks in legacy Korean.
- Preserved Canh chua's exact source/target name and retained Eating only as a held proposal.
- Added the released-task durable-state placeholder contract without treating legacy narration as Dish evidence.
- Performed no Asana writes.
