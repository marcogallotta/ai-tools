# Released governed-task migration template contract

Use only after `ingestion_hold` is `null`:

```text
## PROCESS RECORD
{{MIGRATED_DISH_STATE_BLOCK}}
### Planning brief
...
```

The manifest—not the placeholder—records exact legacy state/verification claims and Marco's reviewed classification.

Import safety gates:
- Reject any upload candidate containing `{{MIGRATED_DISH_STATE_BLOCK}}`.
- Reject any upload candidate containing `{{TARGET_SECTION_GID}}`.
- Replace and validate both migration placeholders before any target-project write.
