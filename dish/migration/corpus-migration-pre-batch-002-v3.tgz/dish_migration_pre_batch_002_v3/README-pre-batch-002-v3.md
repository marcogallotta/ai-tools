# Pre-Batch-002 control correction v3

This package applies the final structural corrections before Batch 002.

## Reconciliation

- Total source tasks: 110
- Dispositions: 7 stay legacy, 4 copy unmanaged, 99 copy governed
- Across all 110 records: 99 have `ingestion_hold: null`
- Within the 99 governed tasks:
  - 88 released
  - 5 `planned-policy-pending`
  - 6 `korean-deferred`

## Canh chua

Source GID: `1216522297757193`

Marco-provided migration facts:
- Approved protein: pangasius
- Cooked on: 2026-07-31
- Prawn approval text: stale legacy-protocol residue

The task remains under `planned-policy-pending`. `Eating` is retained only as its proposed destination.

## Batch 002 source freeze

Before a released governed task is transformed, its manifest row must contain:
- exact source notes file
- SHA-256 of those exact UTF-8 notes bytes
- Asana `modified_at`
- `source_capture_status: captured`

No task may receive a template path while any of those fields is missing.

## Offline-only placeholders

Templates may contain:
- `{{MIGRATED_DISH_STATE_BLOCK}}`
- `{{TARGET_SECTION_GID}}`

No upload is permitted until both are resolved and the final document validates.

## Embedded handoff

The handoff was copied unchanged from the structurally approved package.
SHA-256: `bd012d3055d9b9adcc5cdafe6bea4db7180a865a1300352fc8c94d3d47cf7da9`
