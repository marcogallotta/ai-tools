[Rau răm] Canh thịt bò rau răm — minced-beef and Vietnamese coriander soup

A light Vietnamese canh built around loose minced beef, onion, fish sauce, black pepper and rau răm. This is a soup-and-rice meal, not a macro-forced meat bowl.

WHY COOK IT
Test rau răm as the defining fresh finish in a quick Vietnamese soup while preserving the light canh structure supported by Andrea Nguyen’s construction.


## CHECK BEFORE COOKING
- Confirm at least 15g usable rau răm leaves.
- Use ordinary ground chuck or similarly flavoured mince; premium steak cuts are unnecessary.
- Cook rice fresh for each sitting.
- Do not scale beef upward merely to force 50g protein inside the soup.

## QUANTITIES
Portions: 3 substantial soup-and-rice meals.

Soup:
- Ground beef chuck, about 15–20% fat: 450g
- Yellow onion: 150g, thinly sliced
- Neutral oil: 10ml
- Fish sauce: 25ml initially, plus up to 10ml after reduction
- Fine salt: 3g initially, then only as needed
- Water: 1.65L
- Rau răm leaves: 15g, divided into three 5g portions
- Freshly ground black pepper: 1.5g, divided

Rice:
- Jasmine rice: 300g dry total, 100g per sitting

Approximate meal structure per sitting: 150g raw beef allocation, 100g dry rice and one-third of the broth. This is expected to be a substantial carb-forward meal, but may remain below the project’s usual protein aim; that is accepted rather than distorting the canh with an excessive meat load.

## HOW TO COOK IT
1. Cook 100g jasmine rice fresh for each sitting.
2. Heat the oil over medium heat. Soften the onion for about 4 minutes without browning.
3. Add the mince, break it into small loose pieces and cook only until it changes colour; do not form meatballs or brown it dry.
4. Add 25ml fish sauce and 3g salt. Stir for about 1 minute.
5. Add 1.65L water, bring to a boil, skim, then simmer uncovered for about 15 minutes. The broth should reduce modestly while remaining light and drinkable.
6. Taste only after reduction. Add up to 10ml more fish sauce and a small amount of salt if needed.
7. Divide the soup base into three equal portions by cooked weight. Do not add rau răm to stored portions.
8. At each sitting, reheat one portion just to a simmer, switch off the heat, stir in 5g rau răm and finish with black pepper. Serve with that sitting’s rice.

## WHAT SUCCESS LOOKS LIKE
The broth reads as a clear, light canh rather than a thick beef stew. Beef remains loose and juicy; onion is soft but not browned; rau răm is vivid, peppery and freshly wilted.

## WATCH OUT FOR
- Do not restore the previous 850g beef load; it materially distorted the source structure to chase macros.
- Do not add tomato, garlic, sliced steak or an Instant Pot braise.
- Rau răm goes in only after reheating and off direct heat.

## STORAGE
Divide and chill or freeze the soup base without rau răm. Reheat one portion at a time. Cook rice fresh.

---
## PROCESS RECORD
{{MIGRATED_DISH_STATE_BLOCK}}
### Planning brief
Dish candidate: [Rau răm] Canh thịt bò rau răm — minced-beef and Vietnamese coriander soup
Purpose: Test rau răm as the defining fresh finish in a quick Vietnamese soup while preserving the light canh structure supported by Andrea Nguyen’s construction.
Role: main
Priors: None
Locks: the earlier 850g beef construction was not acceptable as a light canh. Resolve the issue now rather than sending it back to an undefined planning stage.
Exemptions: None
Research emphasis: None
Destination section: Verification Queue — {{TARGET_SECTION_GID}}

### Decisions
Human — Marco: the earlier 850g beef construction was not acceptable as a light canh. Resolve the issue now rather than sending it back to an undefined planning stage.

### Research basis
Andrea Nguyen, “Beef and Vietnamese Coriander Soup,” Into the Vietnamese Kitchen, reader-facing reprint at https://www.epicurious.com/recipes/food/views/beef-and-vietnamese-coriander-soup-382941. The source supports ground chuck, onion, fish sauce, salt, about 7 cups water, rau răm and black pepper; onion is softened, beef is kept loose, broth simmers and is skimmed for about 15 minutes, and rau răm is wilted at the end. The source is a shared-meal canh, so this task pairs it with rice and uses a moderate beef increase for three substantial sittings without claiming the revised ratio is source-authentic.

Legacy agent construction/provenance (not Dish evidence):
Agent — GPT: restored a restrained three-meal structure using 450g ground chuck and 300g dry rice total; accepted that the meal may fall below the usual protein aim rather than inflating the beef.

### Material changes
2026-07-30 — Replaced the 850g macro-forced beef load with 450g ground chuck; fixed the task at three soup-and-rice meals; set rice to 100g dry per sitting; retained the source-supported light-broth mechanism; removed unsupported nutrition-gating instructions. Independent verification remains pending.
