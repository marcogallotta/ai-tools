Bang bang chicken — sesame paste and red huajiao

Poached and hand-shredded chicken dressed in a Sichuan guaiwei-style sauce using Chinese sesame paste, chilli oil and fresh red huajiao. Stale green Sichuan pepper is not used.

WHY COOK IT
Cook a coherent sesame-paste-led bang bang chicken with a balanced sweet, sour, savoury, spicy and numbing sauce.


## QUANTITIES
Portions: 3.
- Cooked shredded chicken: 500–600g
- Light soy: 30ml
- Zhenjiang vinegar: begin with 15ml; up to 5ml reserve
- White sugar: begin with 10g; up to 10g reserve
- Chilli oil: 15ml
- Chinese roasted sesame paste: begin with 10g; up to 5g reserve
- Garlic: 1 small clove
- Fresh red huajiao: 1–1.5 tsp, lightly toasted and ground
- Poaching liquid: 15–30ml, only as needed

## HOW TO COOK IT
1. Poach chicken gently with ginger and scallion; do not boil hard.
2. Cool in some poaching liquid, then hand-shred into long irregular strands.
3. Lightly toast red huajiao until fragrant, cool and grind immediately.
4. Whisk soy, 15ml vinegar, 10g sugar, chilli oil, 10g sesame paste and garlic. Add poaching liquid gradually until the sauce coats but is not stiff.
5. Add most of the ground huajiao. Taste, then use the measured vinegar, sugar, sesame-paste and huajiao reserves only as needed.
6. Dress shortly before serving.

## WHAT SUCCESS LOOKS LIKE
Long hand-shreds remain visible beneath a fluid coating. Sesame paste gives body without burying the chicken, chilli oil or vinegar; red huajiao remains aromatic and clearly numbing.

## WATCH OUT FOR
Do not use stale green peppercorn, scorch the red huajiao, make the sauce opaque and pasty, or preserve alternate branches inside this cook.

---
## PROCESS RECORD
{{MIGRATED_DISH_STATE_BLOCK}}
### Planning brief
Dish candidate: Bang bang chicken — sesame paste and red huajiao
Purpose: Cook a coherent sesame-paste-led bang bang chicken with a balanced sweet, sour, savoury, spicy and numbing sauce.
Role: main
Priors: None
Locks: use fresh red huajiao and the sesame-paste construction; remove the non-paste fallback and any obligation to run a future green-pepper-oil comparison.
Exemptions: None
Research emphasis: None
Destination section: Verification Queue — {{TARGET_SECTION_GID}}

### Decisions
Human — Marco: use fresh red huajiao and the sesame-paste construction; remove the non-paste fallback and any obligation to run a future green-pepper-oil comparison.

### Research basis
The Woks of Life supports poached, hand-shredded chicken and the sweet-sour-spicy-numbing sauce family. Omnivore's Cookbook supports the Chinese sesame-paste, chilli-oil, vinegar, sugar, garlic and Sichuan-pepper branch. The task deliberately selects one coherent route rather than retaining parallel variants.
Sources:
- https://thewoksoflife.com/bang-bang-chicken-sichuan/
- https://omnivorescookbook.com/bang-bang-chicken/

### Material changes
2026-07-30 — Removed the non-paste fallback and deferred green-pepper comparison; retained one executable sesame-paste/red-huajiao dish.
