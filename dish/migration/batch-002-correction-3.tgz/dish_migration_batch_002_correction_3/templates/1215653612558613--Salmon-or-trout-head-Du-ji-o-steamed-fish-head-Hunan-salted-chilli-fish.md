[Salmon or trout head] Duòjiāo steamed fish head — Hunan salted-chilli fish

A split salmon or trout head steamed under fermented chopped chilli, garlic, ginger, scallion and restrained douchi. Salmon/trout is an approved local-species adaptation, not traditional equivalence to bighead carp.

WHY COOK IT
Cook a legitimate Hunan duòjiāo fish-head dish using an unusually accessible local ingredient: the fish counter can supply a salmon or trout head free when other fish is purchased, and may leave a generous collar if requested or paid for.


### WHAT TO BUY / ASK FOR
- Ask the fish counter for a salmon or trout head with gills removed and split flat if possible.
- Ask them to leave the collar and attached neck/belly flesh generous; offer to pay for that extra edible trim if needed.
- Do not require an exact 800g head. Accept the available head if it fits the steamer and has worthwhile cheek/collar flesh.
- Scallions, garlic, ginger, duòjiāo and douchi as scaled below.

## CHECK BEFORE COOKING
- Weigh the cleaned split head at home.
- Confirm it fits the steaming plate and covered steamer before seasoning.
- Inspect how much cheek, collar and attached flesh is present; portion count depends on the actual head, not nominal gross weight.
- Taste the live duòjiāo for salinity before setting its dose.
- Postpone rather than substitute an unreviewed species or a lean fillet.

## QUANTITIES
Portions: determine after inspecting the actual head. Default to 1 substantial fresh portion. A very large head with a generous collar may yield 2 smaller portions with rice and a vegetable dish; do not claim 2 portions merely from gross head weight.

Base formula per 800g cleaned fish head; scale linearly to actual weight:
- Salmon or trout head: actual cleaned weight, split flat
- Duòjiāo: 120g per 800g head; increase toward 140g only if the ferment is not aggressively salty
- Garlic: 64g per 800g head, minced
- Douchi: 10g per 800g head, rinsed and chopped
- Ginger: 25g per 800g head, half julienned and half minced
- Scallion whites: 25g per 800g head
- Scallion greens: 15g per 800g head
- Light soy sauce: 0–10ml per 800g head, only after tasting the topping
- White sugar: 2–3g per 800g head, only if required
- Neutral oil: 20ml per 800g head, divided

## HOW TO COOK IT
1. Weigh the cleaned head and scale the topping from the 800g formula.
2. Taste and drain the duòjiāo of only excess free liquid; do not rinse away its fermentation.
3. Place the fish cut-side up over julienned ginger and scallion whites on a heatproof plate.
4. Pre-steam over fully boiling water for 3–5 minutes, just until cloudy liquid is released. Remove the plate and discard that liquid.
5. While it pre-steams, fry minced garlic, minced ginger and douchi in part of the oil until fragrant. Add the duòjiāo and fry until excess moisture evaporates and the aroma intensifies. Add soy or sugar only after tasting.
6. Spread the topping densely and evenly over the fish. Return to the steamer and begin checking after 8 minutes; a larger, thicker head may need longer.
7. Stop when cheek and collar flesh releases cleanly from bone while remaining moist. Rest 2 minutes, add scallion greens and pour over the remaining oil, heated until shimmering.
8. After cooking, record the edible yield and whether the head honestly produced one substantial portion or two smaller portions.

## WHAT SUCCESS LOOKS LIKE
The head lies split and flat beneath a dense structured chilli topping rather than loose watery sauce. Cheek and collar meat remains moist; duòjiāo is clearly dominant but does not erase the oily salmon/trout flesh.

Visual reference — https://www.seriouseats.com/introduction-hunan-chinese-cuisine — Observe split-flat presentation and a dense chilli-and-black-bean topping. Ignore the fish species, restaurant steamer and exact quantity.

## WATCH OUT FOR
Remove all gills and blood clots. Do not infer portions from gross weight alone, skip the first steam and liquid discard, put the topping on raw, add soy blindly or use a fixed total steam time instead of checking the thickest meat.

## STORAGE
Best served immediately. Refrigerate leftovers once cool and reheat gently by steaming; the topping will become saltier on holding.

---
## PROCESS RECORD
{{MIGRATED_DISH_STATE_BLOCK}}
### Planning brief
Dish candidate: [Salmon or trout head] Duòjiāo steamed fish head — Hunan salted-chilli fish
Purpose: Cook a legitimate Hunan duòjiāo fish-head dish using an unusually accessible local ingredient: the fish counter can supply a salmon or trout head free when other fish is purchased, and may leave a generous collar if requested or paid for.
Role: main
Priors: None
Locks: Use salmon or trout head because the traditional Chinese freshwater species is not locally accessible; disclose the substitution. | The fish counter can provide the head free with another fish purchase; ask for a generous collar and offer to pay for the extra collar trim. Actual head size and edible yield are unknowable until collection, so portions must be decided from the received head rather than fixed in advance.
Exemptions: None
Research emphasis: None
Destination section: Hunan — {{TARGET_SECTION_GID}}

### Decisions
Human — Marco: Use salmon or trout head because the traditional Chinese freshwater species is not locally accessible; disclose the substitution.
Human — Marco: The fish counter can provide the head free with another fish purchase; ask for a generous collar and offer to pay for the extra collar trim. Actual head size and edible yield are unknowable until collection, so portions must be decided from the received head rather than fixed in advance.

### Research basis
Intentional test dish, human-approved.
Construction — China Food Recipe, https://www.chinafoodrecipe.com/recipe/hunan-steamed-fish-head-with-chopped-chili-peppers/ — 1000g bighead-carp head, 400g duòjiāo, 80g garlic, 100g ginger, 60g scallion and 7g douchi; directly supports frying the topping and a pre-steam/discard followed by a second steam.
Later validation — Xiachufang, https://m.xiachufang.com/recipe/107666176/ — uses 200g duòjiāo per 1000g fish head, establishing a credible lower-chilli construction. The task retains 150–175g duòjiāo per kg as the bounded project formula.

### Material changes
2026-07-30 — Replaced the false fixed three-portion claim with an actual-yield rule; added the confirmed free-head sourcing route, generous-collar request and linear scaling from the researched 800g formula; reset verification.
