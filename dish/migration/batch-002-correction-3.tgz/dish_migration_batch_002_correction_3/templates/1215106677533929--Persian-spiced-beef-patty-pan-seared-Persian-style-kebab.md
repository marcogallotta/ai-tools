Persian spiced beef patty — pan-seared Persian-style kebab

Fatty ground beef kneaded with thoroughly squeezed onion and spices, shaped as a thin pan disc and cut into strips once set. This is an explicit no-charcoal equipment adaptation, not koobideh equivalence and not a controlled experiment.

WHY COOK IT
Make a practical Persian-style pan kebab while using the core binding rules: fatty meat, very dry grated onion, thorough kneading and chilling.


## WHAT TO BUY
- Ground beef, 20% fat: 550g
- White onion: enough to yield about 140g after grating and squeezing
- Flatbread or rice for serving

## CHECK BEFORE COOKING
- This counts as the week's red-meat dish.
- Weigh the onion after squeezing; expressed liquid is not part of the formula.
- Cook the full batch when making it. Use two pan loads only if needed to avoid crowding.

## QUANTITIES
Portions: 3.
- Ground beef, 20% fat: 550g
- Grated onion, squeezed extremely dry: 140g
- Fine salt: 7g
- Black pepper: 1/2–1 tsp
- Turmeric: 1/2–1 tsp, disclosed household variation
- Sumac: 1 tsp in the mixture plus more for serving, disclosed variation
- Neutral oil: only enough to film the non-stick if required

## HOW TO COOK IT
1. Grate the onion, squeeze very firmly and weigh 140g of the dry pulp.
2. Knead beef, onion, salt and spices for about 5 minutes until smooth, sticky and cohesive.
3. Refrigerate 1 hour.
4. Press the mixture into one or two thin even discs in the 24cm non-stick, depending on pan capacity.
5. Cook over medium-high heat until the underside is set and browned. Cut each disc into strips, turn and finish the second broad face until safely cooked but still juicy.
6. Rest briefly and serve with sumac, bread or rice.

## WHAT SUCCESS LOOKS LIKE
The raw mixture is sticky enough to hold a thin shape with no onion water leaking. In the pan it sets into intact strips with browned broad faces and a juicy centre; it does not crumble like loose mince or steam grey.

## WATCH OUT FOR
Under-squeezed onion and inadequate kneading are the main failure risks. Do not use lean mince. The pan method loses charcoal smoke, skewer texture and live-fire fat rendering; judge this as its own pan-cooked dish.

## STORAGE
Refrigerate cooked leftovers up to 2 days and reheat gently, or freeze promptly.

---
## PROCESS RECORD
{{MIGRATED_DISH_STATE_BLOCK}}
### Planning brief
Dish candidate: Persian spiced beef patty — pan-seared Persian-style kebab
Purpose: Make a practical Persian-style pan kebab while using the core binding rules: fatty meat, very dry grated onion, thorough kneading and chilling.
Role: main
Priors: None
Locks: Keep the recipe but remove the controlled-experiment framing; cook the full batch when made and split into pan loads only for capacity.
Exemptions: None
Research emphasis: None
Destination section: Verification Queue — {{TARGET_SECTION_GID}}

### Decisions
None explicitly recorded as a Human — Marco decision in the legacy source.

### Research basis
Source-backed binding and equipment adaptation.
Construction — Unicorns in the Kitchen, https://www.unicornsinthekitchen.com/kabob-koobideh-recipe/ — supports no breadcrumbs, eggs or fillers; fatty meat; onion weighed after squeezing at one quarter of meat weight; and extensive kneading into a sticky mixture. For 550g meat, one quarter is 137.5g, rounded to 140g.
Turmeric and sumac remain disclosed flavour variations. The pan-disc method is a Human-approved no-charcoal adaptation and is not presented as koobideh equivalence.

Legacy agent construction/provenance (not Dish evidence):
Human — Moinudin, 2026-07-31: Keep the recipe but remove the controlled-experiment framing. Cook the full batch when made; split into pan loads only for capacity.

### Material changes
None explicitly recorded.
