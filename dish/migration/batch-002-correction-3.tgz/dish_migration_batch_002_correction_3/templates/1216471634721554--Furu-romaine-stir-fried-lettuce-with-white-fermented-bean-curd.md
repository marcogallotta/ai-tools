Furu romaine — stir-fried lettuce with white fermented bean curd

A quick vegetable side of romaine stir-fried with garlic and plain white fermented bean curd. Romaine replaces Chinese a-choy or yau mak choy as a disclosed related-lettuce adaptation.

WHY COOK IT
Use white fermented bean curd in a normal cooked vegetable dish and learn the balance between its savoury fermented flavour, salt and the water released by lettuce.


## WHAT TO BUY
- Romaine: 250g

## CHECK BEFORE COOKING
- Dry the lettuce thoroughly.
- Taste the furu before adding soy or brine; cube size and salinity vary.
- Separate thick ribs from leafy tops so they can enter the pan in sequence.

## QUANTITIES
Portions: 1 fresh vegetable-side portion.
- Romaine: 250g
- Plain white WangZhiHe furu: 3/4 cube initially
- Furu brine: 0–10ml, only if needed
- Garlic: 2 cloves, sliced
- Neutral oil: 15ml
- Water: 10–15ml, to loosen the furu
- Sichuan chilli oil: 5ml, optional
- White sugar: a small pinch, only after tasting
- Light soy: 0–5ml, only after tasting

## HOW TO COOK IT
1. Mash the furu with 10–15ml water. Add brine only if required to make a loose sauce; mix in optional chilli oil.
2. Heat the pan well. Add oil and garlic and fry briefly without heavy browning.
3. Add romaine ribs and stir-fry for 20–30 seconds.
4. Add leafy tops and toss until they begin to wilt.
5. Add the furu sauce and toss only until evenly coated.
6. Taste before adding sugar, soy or more brine. Serve immediately.

## WHAT SUCCESS LOOKS LIKE
Ribs retain some crispness, leaves remain green, and the sauce coats without pooling. Furu is distinct but not punishingly salty.

## WATCH OUT FOR
Romaine releases substantial water. Use high heat, keep the cook short and do not add extra seasoning automatically.

---
## PROCESS RECORD
{{MIGRATED_DISH_STATE_BLOCK}}
### Planning brief
Dish candidate: Furu romaine — stir-fried lettuce with white fermented bean curd
Purpose: Use white fermented bean curd in a normal cooked vegetable dish and learn the balance between its savoury fermented flavour, salt and the water released by lettuce.
Role: non-main — side dish; stir-fried romaine is a vegetable side
Priors: None
Locks: keep this as a normal vegetable side; remove the unnecessary homemade-ferment gate and calibration framing.
Exemptions: None
Research emphasis: None
Destination section: Verification Queue — {{TARGET_SECTION_GID}}

### Decisions
Human — Marco: keep this as a normal vegetable side; remove the unnecessary homemade-ferment gate and calibration framing.

### Research basis
Direct recipes converge on 300–400g lettuce, approximately one cube white furu, garlic, optional chilli and a little water. At 250g lettuce, three-quarters of a typical cube is a conservative starting point because brands vary.
Sources:
- https://www.choiyen.com/yen-can-cook-stir-fried-romaine-lettuce-with-fermented-bean-curd-fu-yu-yau-mak/
- https://www.nanyangkitchen.co/recipe/stir-fried-yau-mak-with-fermented-bean-curd/

### Material changes
2026-07-30 — Removed the speculative homemade-ferment prerequisite and reframed the task as one normal vegetable side. The cooking formula remains materially unchanged.
