Canh chua correction — pangasius, stronger tamarind and fried sprouts

Vietnamese sweet-sour soup correction that holds the prior pineapple/tomato/okra structure roughly constant while replacing hake with pangasius, raising tamarind and savoury intensity, and lightly frying the sprouts before service.

WHY COOK IT
The first canh chua cá had a good broth architecture but landed one-sided and too sweet. The correction is to push the broth to sour first, rounded sweet behind it, while using a milder, sauce-receptive fish and a sprout treatment that integrate better on day one.


## WHAT TO BUY
- Pangasius: 600g skinless frozen fillets
- Tomatoes: 350–450g
- Pineapple: about 200g
- Bean sprouts: about 200g
- Scallions

## CHECK BEFORE COOKING
- Pangasius is the approved primary correction; do not substitute cod, branzino or another flaky saltwater white fish.
- Thaw the pangasius fully, drain thoroughly and dry the surface before cutting.
- Sort thick centre sections from thin tapered sections; they enter at different times.
- Keep pineapple roughly similar to the prior cook unless this fruit is radically sweeter.
- Start with less sugar and more tamarind. Adjust sugar only after pineapple and tomato simmer.
- Harvest 20–25 rau-răm leaves or tender tips; postpone if unavailable.
- Lightly fry the bean sprouts; do not repeat the raw/off-heat treatment.

## QUANTITIES
Portions: 3.

Protein:
- Pangasius: 600g skinless fillets, thawed, drained and dried; cut into large 6–8cm pieces, with thin tapered pieces kept separate

Broth:
- Water: 1000ml
- Tamarind paste: start with 45g, dissolved in warm water and strained
- Extra tamarind: 15–25g, dissolved and held back
- Fish sauce: 15ml early, plus 10–20ml held back
- Palm sugar: start with 8–10g, then adjust only after fruit simmers
- Fine salt: none at first

Vegetables:
- Tomato: 350–450g, wedges
- Pineapple: about 200g, bite-size pieces
- Frozen okra: amount available, added from frozen
- Bean sprouts: about 200g
- Scallions: 3–5, whites/light greens for simmering and dark greens for finishing
- Fresh chilli: to taste
- Neutral oil: a small amount for the sprouts

Herbs and aromatics:
- Rau răm: 20–25 leaves or tender tips, added at the end
- Lemongrass leaves or stalk: optional, bruised, infused and removed

## HOW TO COOK IT
1. Dissolve and strain 45g tamarind. Prepare the extra tamarind separately.
2. Add water, starting tamarind, 8–10g palm sugar, 15ml fish sauce and optional bruised lemongrass to the pot. Bring to a simmer.
3. Add tomato, pineapple, scallion whites/light greens and chilli. Simmer for 5–7 minutes.
4. Taste before adding fish. The broth should already read clearly sour, with pineapple sweetness behind it. If sweet-led, add held-back tamarind before more fish sauce or sugar.
5. Add frozen okra and simmer for 4–5 minutes.
6. In a separate pan, lightly fry the bean sprouts over fairly high heat until they take on a little colour and cooked flavour while staying crunchy.
7. Lower the broth to a bare simmer. Add the thick pangasius pieces in one layer where possible. Do not stir. After 1–2 minutes, add the thin tapered pieces.
8. Gently poach until the fish is just opaque and barely separates under light pressure, about 3–6 minutes total depending on thickness. Move pieces only by gently shaking the pot or spooning broth over them.
9. Adjust with held-back fish sauce and tamarind. Pangasius contributes less briny sweetness than prawns, so reassess savouriness rather than automatically increasing fish sauce. Add sugar only if the sourness becomes sharp and thin.
10. Turn off the heat. Add fried sprouts, scallion greens and rau răm. Rest 1 minute.
11. Serve with rice.

## WHAT SUCCESS LOOKS LIKE
The broth remains light and translucent enough that tomato, pineapple, okra and fish stay individually visible. Pangasius pieces remain large and intact, with opaque centres that yield into moist flakes under light pressure rather than shredding through the broth. Lightly fried sprouts retain shape. The sour-first balance is a tasting judgment rather than a visual claim.

Visual reference — https://vickypham.com/blog/vietnamese-sweet-sour-shrimp-soup-pineapple-canh-chua-tom-nau-thom/ — Observe only the light, clear-to-amber broth and the distinct pineapple, tomato and okra components rather than a cloudy or thick stew. This does not validate the pangasius protein, fried sprouts or this task's specific sour/sweet balance.

## WATCH OUT FOR
Do not reduce pineapple automatically, add all sugar up front, boil or stir after adding the fish, or add the bean sprouts raw. If the soup still reads sweet after 45g tamarind, continue adjusting tamarind before blaming the pineapple. Thin fish pieces overcook earlier than thick centre pieces; keep them separate until their later entry.

## STORAGE
The broth and vegetables may improve after resting, but pangasius is best fresh. For multiple sittings, hold uncooked fish separately and poach it fresh in reheated broth where possible. If already cooked, remove and store fish separately from the broth when practical; reheat gently once, because repeated reheating will dry and break it.

---
## PROCESS RECORD
{{MIGRATED_DISH_STATE_BLOCK}}
### Planning brief
Dish candidate: Canh chua correction — pangasius, stronger tamarind and fried sprouts
Purpose: The first canh chua cá had a good broth architecture but landed one-sided and too sweet. The correction is to push the broth to sour first, rounded sweet behind it, while using a milder, sauce-receptive fish and a sprout treatment that integrate better on day one.
Role: main
Priors: Legacy source claims: Intentional correction repeat — no claim that prawns and fried sprouts are the only authentic canh-chua route. Construction — Cooking History task “Canh chua cá — hake, pineapple, okra, bean sprouts,” 1216178669237597 — supplied the actual 1000ml water, approximately 25g tamarind, 20g sugar, 20–25ml fish sauce, tomato, pineapple, okra, sprout and hake baseline plus the observed sweet-forward broth, poor day-one hake integration and disconnected raw sprouts. Construction — Human decisions recorded in this task — approved prawns as the defining protein correction, stronger tamarind while holding pineapple roughly constant, and lightly fried sprouts.
Locks: The first broth was good but too sweet-forward; do not assume the pineapple amount was wrong. | Hake was the wrong fish for immediate service; use prawns because pangasius or catfish is not sourceable, and do not substitute cod or branzino.
Exemptions: None
Research emphasis: After cooking: actual tamarind threshold, whether prawns solve the day-one separation problem, and whether pineapple sweetness requires fruit-specific adjustment.
Destination section: Planned — {{TARGET_SECTION_GID}}

### Decisions
Human — Marco: The first broth was good but too sweet-forward; do not assume the pineapple amount was wrong.
Human — Marco: Hake was the wrong fish for immediate service; use prawns because pangasius or catfish is not sourceable, and do not substitute cod or branzino.
Human — Marco: Lightly fry the bean sprouts because the prior raw/off-heat sprouts tasted bland and disconnected.

### Research basis
Intentional correction repeat — no claim that prawns and fried sprouts are the only authentic canh-chua route.
Construction — Cooking History task “Canh chua cá — hake, pineapple, okra, bean sprouts,” 1216178669237597 — supplied the actual 1000ml water, approximately 25g tamarind, 20g sugar, 20–25ml fish sauce, tomato, pineapple, okra, sprout and hake baseline plus the observed sweet-forward broth, poor day-one hake integration and disconnected raw sprouts.
Construction — Human decisions recorded in this task — approved prawns as the defining protein correction, stronger tamarind while holding pineapple roughly constant, and lightly fried sprouts.
Later validation — Vicky Pham, canh chua tôm: https://vickypham.com/blog/vietnamese-sweet-sour-shrimp-soup-pineapple-canh-chua-tom-nau-thom/ — replaces the earlier blocked Serious Eats citation; confirmed directly, matches this task's protein (prawns) and fruit/veg set (pineapple, tomato, okra) with a light clear broth.
Technical premise: directly supported as a correction hypothesis by the prior cook and Human Review, but not yet validated by a completed prawn cook. Prawns should avoid flaky-fish breakup and bring briny sweetness; stronger tamarind addresses the measured sweet-forward balance; frying sprouts addresses Marco’s observed flavour-integration failure.

Legacy agent construction/provenance (not Dish evidence):
Agent — Codex: Held pineapple roughly constant, increased protein and tamarind, and delayed sweetness adjustment.
Agent — Claude: Corrected the proposed cod/branzino route because it repeats the flaky saltwater-fish failure category recorded in the prior cook.
Agent — ChatGPT: Added a narrow canh-chua analogue for light broth and intact components only.
Agent — GPT-5.6 Thinking: Reopened the prior Cooking History task and rebuilt the source-role record with its exact locator.
Agent — Claude: Verification found QUANTITIES listed 300–350g pineapple, a 50–75% increase over the prior cook's actual ~200g, contradicting this task's own "keep pineapple roughly similar" constraint and the Human decision not to assume the amount was wrong. Corrected to ~200g to match the prior cook. Also replaced the blocked Serious Eats visual citation with a directly-confirmed canh chua tôm source that matches this task's actual protein and produce set.

### Material changes
None explicitly recorded.
