Sabzi khordan — Persian fresh-herb plate meal

A Persian flatbread assembly of fresh herbs, white cheese, walnuts and radish, eaten as composed loghmeh rather than treated as garnish.

WHY COOK IT
Learn Persian raw-herb eating culture directly and use herbs as a substantial meal component.


## WHAT TO BUY
- Scallion: about 20g
- Flat-leaf parsley: one small handful
- Cilantro: one small handful
- Radishes: 3–5
- Soft white cheese: 40–60g
- Flatbread: 1–2 pieces

## CHECK BEFORE COOKING
- Combine the herb shopping with another grocery trip; do not make a dedicated cilantro trip for this small plate.
- Wash early enough for the herbs to dry completely, but do not chop them.

## QUANTITIES
Portions: 1 fresh sitting.
- Scallion: about 20g
- Parsley: one small handful
- Cilantro: one small handful
- Radishes: 3–5
- Walnuts: 20–30g
- Soft white cheese: 40–60g
- Flatbread: 1–2 pieces

Optional additions when available:
- Dill, basil, mint, chives, tarragon, savory or cress

## HOW TO COOK IT
1. Wash and dry the herbs thoroughly. Keep sprigs whole or in large tender pieces.
2. Arrange herbs, radishes, cheese, walnuts and bread in separate abundant piles.
3. Eat by tearing bread and wrapping different combinations of herb, cheese, walnut and radish.

## WHAT SUCCESS LOOKS LIKE
The plate is abundant and dry, with whole sprigs and large leaves rather than chopped salad. Components remain separate so every loghmeh can be composed at the table; herbs read as food, not decoration.

Visual/reference source — https://persianmama.com/sabzi-khordan-fresh-herbs/ — Observe the simple core of scallion, parsley, cilantro and radish, with cheese and flatbread turning it into a rustic meal.

## WATCH OUT FOR
Do not pre-chop, dress or leave washed herbs wet. Mint, dill, basil and chives are legitimate additions, but their absence does not make the simple supermarket core incomplete.

## STORAGE
Assemble immediately before eating. Refrigerate washed herbs separately and dry.

---
## PROCESS RECORD
{{MIGRATED_DISH_STATE_BLOCK}}
### Planning brief
Dish candidate: Sabzi khordan — Persian fresh herb plate meal
Purpose: Learn Persian raw-herb eating culture directly and use herbs as a substantial meal component.
Role: main
Priors: None
Locks: None
Exemptions: None
Research emphasis: None
Destination section: Persian — {{TARGET_SECTION_GID}}

### Decisions
None explicitly recorded as a Human — Marco decision in the legacy source.

### Research basis
Source-backed fresh assembly.
Construction — Persian Mama, https://persianmama.com/sabzi-khordan-fresh-herbs/ — identifies scallions, parsley, cilantro and radishes as the accessible simple core; dill, basil, mint and Persian chives are additions. Feta/white cheese and flatbread support the loghmeh meal structure.

### Material changes
2026-07-16 — Claude — Delta: corrected the task's inverted core/optional herb list and restored scallion.
2026-07-16 — GPT — Verification correction: completed buy/readiness/storage language and signed the contained Delta.
