Bánh xèo — crispy Vietnamese shrimp-and-chicken crepes

Thin, crisp Vietnamese rice-flour crepes with shrimp, chicken, onion, mung beans and bean sprouts, served with lettuce, homegrown mint and cilantro, and nước chấm.

WHY COOK IT
Fill the Vietnamese starch-format gap with a fresh, crisp crepe that depends on batter handling, herbs and assembly timing. The three-sitting plan is for calibration, not leftovers.


## CHECK BEFORE COOKING
- Wait until homegrown mint and cilantro are harvestable.
- Rest batter at least 3 hours, preferably overnight.
- Add scallions only to the portion of batter being cooked that day.
- Prepare mung beans and divide fillings into 3 portions.

## QUANTITIES
Portions: 6 crepes across 3 sittings.

Batter:
- Rice flour: 128g
- All-purpose flour: 43g
- Unsweetened full-fat coconut milk or coconut cream: 200ml
- Water: 400ml
- Turmeric: 1–1.5 tsp
- Fine salt: 1/2 tsp
- Scallions: 3, divided into 3 portions

Filling:
- Shrimp: 300g total
- Chicken breast: 240g total, thinly sliced
- Dried mung beans: 90g, soaked and steamed
- Bean sprouts: 300g total
- Onion: about 3/4 medium onion
- Lettuce, mint and cilantro: enough for 3 fresh plates
- Neutral oil: begin with 1–2 tsp per crepe

Nước chấm:
- Fish sauce: 45ml
- Warm water: 135ml
- White sugar: 30–35g
- Fresh lime or lemon juice: 45ml
- Garlic: 1–2 cloves
- Chilli: optional

## HOW TO COOK IT
1. Day 1: stir one-third of the scallions into that day’s batter, cook 2 crepes and record flow, water, pour amount, pan heat, release and crispness.
2. Refrigerate remaining batter promptly.
3. Day 2: stir thoroughly, add that day’s scallions and make only one measured water adjustment if needed.
4. Day 3: repeat the selected method to confirm it.
5. For each crepe, sear onion, shrimp and chicken; pour a thin batter layer and swirl; add mung beans and sprouts; cover briefly, then uncover and cook until crisp and releasing cleanly. Fold once and serve immediately.

## WHAT SUCCESS LOOKS LIKE
The batter immediately sizzles and swirls into a thin round around the filling. The finished crepe has a lacy-thin golden shell, visibly crisp edges and one contained folded filling layer rather than thick batter burying the filling.

Visual reference — https://www.foodandwine.com/recipes/crispy-vietnamese-crepes-shrimp-pork-and-bean-sprouts — Observe Vietnamese chef Charles Phan’s finished bánh xèo for lacy-thin golden shell, crisp edge, fold and contained filling. Ignore the pork, rice-flour-and-cornstarch batter, mung-bean purée and exact skillet quantities; it does not validate the chicken filling or this coconut-milk calibration.

## WATCH OUT FOR
Chicken breast does not reproduce pork fat. Do not use sweetened coconut milk, add all scallions to stored batter, make several Day-2 changes, flip like a Western pancake or hold cooked crepes.

## STORAGE
Refrigerate batter covered between sittings for about 48 hours. Keep scallions and filling portions separate. Finish herbs and sprouts fresh. Never stack or store finished crepes.

---
## PROCESS RECORD
{{MIGRATED_DISH_STATE_BLOCK}}
### Planning brief
Dish candidate: Bánh xèo — crispy Vietnamese shrimp-and-chicken crepes
Purpose: Fill the Vietnamese starch-format gap with a fresh, crisp crepe that depends on batter handling, herbs and assembly timing. The three-sitting plan is for calibration, not leftovers.
Role: main
Priors: Legacy source references prior related work: QUANTITIES previously had two independent errors: the solids (192g/63g) matched a 9-crepe/0.75x
Locks: Approved chicken-breast filling and storing the batter for up to 48 hours across three sittings.
Exemptions: None
Research emphasis: Practical only: homegrown mint and cilantro must be harvestable.
Destination section: Verification Queue — {{TARGET_SECTION_GID}}

### Decisions
Human — Marco: Approved chicken-breast filling and storing the batter for up to 48 hours across three sittings.

### Research basis
Halal port of bánh xèo, human-approved.
Construction update — Hungry Huy's actual 12-crepe batter is 255g rice flour, 85g all-purpose flour, 800ml water and
397ml coconut cream, rested three hours or overnight. The correct 0.5x (6-crepe) scale is therefore
128g rice flour, 43g all-purpose flour, 400ml water and 200ml coconut milk/cream. The live
QUANTITIES previously had two independent errors: the solids (192g/63g) matched a 9-crepe/0.75x
batch rather than the intended 6-crepe/0.5x batch, and the two liquids were inverted relative to the
source — water is the dominant liquid at this scale, not coconut milk, whereas the prior figures
listed 800ml coconut milk against only 100ml water. Rest overnight; 48 hours is a storage experiment,
not a requirement, and three days should not be default. Cover briefly for filling, uncover to
crisp. Research is complete.
Sources: <https://www.hungryhuy.com/banh-xeo-savory-vietnamese-crepes/>

### Material changes
None explicitly recorded.
