Tabbouleh — small parsley-led portion

A single fresh portion of Lebanese parsley-led tabbouleh with mint, tomato, spring onion, fine bulgur, lemon and olive oil.

WHY COOK IT
Learn the parsley-led balance, herb dryness and single-pass slicing without buying or wasting a banquet-sized quantity.


## QUANTITIES
Portions: 1 small side portion.
- Flat-leaf parsley: 60g before final trimming
- Mint leaves and tender tips: 12–15g
- Firm ripe tomato: 80–100g, small dice
- Spring onion: 8–10g
- Fine bulgur: 3g
- Lemon juice: begin with 10ml; hold a little more for adjustment
- Extra-virgin olive oil: begin with 18ml; hold up to 5ml
- Fine salt: begin with 0.8g
- Mild pepper or black pepper: a small pinch

## HOW TO COOK IT
1. Wash the herbs and dry them completely.
2. Rinse the fine bulgur, drain extremely well and mix it with the diced tomato so it hydrates from tomato juice.
3. Slice the spring onion finely.
4. Stack mint beneath parsley and slice both finely with one pass of a sharp knife; do not process or repeatedly re-chop.
5. Immediately before eating, combine tomato-bulgur, onion and herbs.
6. Add the starting lemon, oil and salt. Toss, wait 2 minutes and adjust only as needed.
7. Eat immediately.

## WHAT SUCCESS LOOKS LIKE
Parsley is the main volume; mint is clearly present but secondary; bulgur appears only as scattered tender grains. The herbs remain distinct and green, with no watery pool.

## WATCH OUT FOR
Do not dress wet herbs, process them or hold the dressed salad.

## STORAGE
Do not store dressed tabbouleh.

---
## PROCESS RECORD
{{MIGRATED_DISH_STATE_BLOCK}}
### Planning brief
Dish candidate: Tabbouleh — small parsley-led portion
Purpose: Learn the parsley-led balance, herb dryness and single-pass slicing without buying or wasting a banquet-sized quantity.
Role: non-main — side; the source explicitly frames a small parsley-led portion
Priors: Legacy source references prior related work: Source-backed Lebanese parsley-led tabbouleh. The previous large formula was reduced to a practical one-person side while preserving the parsley-dominant ratio and minimal bulgur.
Locks: Reject the large shared batch and use a single small portion.
Exemptions: None
Research emphasis: None
Destination section: Verification Queue — {{TARGET_SECTION_GID}}

### Decisions
Human — Marco: Rejected the large shared batch and chose a single small portion.

### Research basis
Source-backed Lebanese parsley-led tabbouleh. The previous large formula was reduced to a practical one-person side while preserving the parsley-dominant ratio and minimal bulgur.

### Material changes
2026-07-31 — GPT — Reconstructed from a five-to-six-serving shared batch to one small fresh portion following Moinudin's decision.
