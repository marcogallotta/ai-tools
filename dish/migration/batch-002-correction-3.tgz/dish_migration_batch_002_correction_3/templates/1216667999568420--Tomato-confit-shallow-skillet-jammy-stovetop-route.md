[CLAUDE VERIFICATION] Tomato confit — shallow-skillet jammy stovetop route
Small peak-season tomatoes slowly collapsed with olive oil and garlic in a wide skillet until glossy, concentrated and spoonable. This is the lower-oil stovetop route; it is not the fully submerged, shape-holding confit form.

WHY COOK IT
Pasta al pomodoro tests fresh, short-cooked tomato character. This tests the opposite end of the same seasonal window: long, low, oil-based concentration in a batchable form suited to the freezer.


## WHAT TO BUY
- Peak ripe small tomatoes: 600g

## CHECK BEFORE COOKING
- Taste at least two tomatoes raw. Avoid mealy or aroma-less fruit; this method can concentrate modest tomatoes but cannot repair bad texture.
- Use the 28cm Fissler stainless pan. The tomatoes should form one layer and the oil should come roughly halfway up them; they are not meant to be submerged.
- Italian garlic and olive oil are recorded in live Pantry.
- Harvest 4 small sprigs common thyme, about 2g, only if aromatic. Thyme is optional because it adds a herbal top note rather than defining the tomato-garlic mechanism; omit it rather than substituting lemon thyme if the common thyme is not ready.
- Have three small freezer-safe containers ready before cooking.

## QUANTITIES
Portions: about 3 condiment/base sittings.
- Small tomatoes: 600g, left whole at 2–3cm; halve any substantially larger fruit
- Extra-virgin olive oil: 120ml
- Italian garlic: 5 cloves, about 20g peeled, lightly crushed but left whole
- Common thyme: 4 small sprigs, about 2g, optional as described above
- Fine salt: 3g initially, with 1g measured reserve after cooking

## HOW TO COOK IT
1. Wash and dry the tomatoes thoroughly. Put them in the cold 28cm Fissler in one layer with the garlic, optional thyme, 3g salt and all 120ml oil.
2. Set over the lowest steady flame. Bring the oil slowly to a soft lazy simmer: occasional small bubbles around the tomatoes and garlic, with no vigorous movement or frying sound.
3. Cook uncovered for 40 minutes, gently rolling or turning the tomatoes every 10 minutes so the pan's direct heat is distributed. If bubbling becomes active at the lowest setting, remove the pan from the burner for 1–2 minutes, then resume; do not accept browning as normal.
4. From 40 minutes, assess every 5 minutes. Continue until most tomatoes are wrinkled and collapsed, garlic is completely soft and pale, and the oil smells sweet and tomato-rich. The expected first-stage range is 40–55 minutes.
5. Press roughly one-third of the tomatoes with the back of a spoon to release pulp into the oil while leaving the rest identifiable. Cook another 5–10 minutes at the same lazy simmer until the mixture is glossy and spoonable rather than watery.
6. Remove the thyme stems. Taste a cooled spoonful and use only as much of the 1g salt reserve as needed.
7. Take the pan off heat. Let it stop steaming, then divide tomatoes, garlic and oil evenly among three shallow containers. Refrigerate or freeze promptly under STORAGE below.

## WHAT SUCCESS LOOKS LIKE
The mixture is wrinkled, collapsed, glossy and spoonable, with some tomatoes still identifiable. Tomato flavour is concentrated and sweet-savory rather than fresh or raw. Garlic is pale, soft and spreadable; it is never browned. Oil is fragrant and red-gold, with no scorched or bitter note. This route intentionally produces a jammy condiment, not pristine whole tomatoes floating in oil.

## WATCH OUT FOR
Do not describe 120ml oil in a 28cm pan as full submersion. Do not let the oil reach an active simmer, brown the garlic, cover the pan and trap vigorous boiling, or cook until the tomato solids fry dry.

## STORAGE
Garlic-and-herb oil is not shelf-stable. Portion in shallow containers and refrigerate at 4°C or below within 2 hours; use refrigerated portions within 4 days. Freeze anything intended for later use in small portions with enough oil to cover the tomato mixture. Do not store at room temperature.

---
## PROCESS RECORD
{{MIGRATED_DISH_STATE_BLOCK}}
### Planning brief
Dish candidate: Tomato confit — shallow-skillet jammy stovetop route
Purpose: Pasta al pomodoro tests fresh, short-cooked tomato character. This tests the opposite end of the same seasonal window: long, low, oil-based concentration in a batchable form suited to the freezer.
Role: non-main — component; tomato confit is a prepared component rather than a full meal
Priors: None
Locks: Use route A, the lower-oil shallow-skillet construction yielding a collapsed, glossy and spoonable result, rather than the oil-heavy fully submerged route.
Exemptions: None
Research emphasis: None
Destination section: Verification Queue — {{TARGET_SECTION_GID}}

### Decisions
Human — Marco: Cook a stovetop tomato confit as one of the additional peak-tomato-season dishes.
Human — Marco: Chose route A, the lower-oil shallow-skillet construction yielding a collapsed, glossy and spoonable result, over the oil-heavy fully submerged route, 2026-07-17.

### Research basis
Classification: Source-backed dish with a Human-selected stovetop route.

Construction — Powell Family Cooking, “Easy Tomato Confit Recipe,” https://www.powellfamilycooking.com/tomato-confit-recipe/ — directly displays 2lb/907g cherry or grape tomatoes, 3/4 cup/approximately 177ml oil, 6–8 garlic cloves and a cold 12-inch skillet. Oil comes about halfway up the tomatoes; the mixture reaches a soft lazy simmer and cooks 40–55 minutes plus 5–10 minutes after pressing some fruit, ending wrinkled, collapsed, glossy and spoonable. Scaling to 600g uses factor 600/907 = 0.662: oil 177ml × 0.662 = 117ml, rounded to 120ml; garlic 6–8 × 0.662 = 4.0–5.3 cloves, set at five. The 28cm Fissler is a close equipment match to the source’s 30.5cm skillet.

Rejected preference alternative — Natasha Pickowicz, “Stovetop tomato confit,” Reform, https://www.reformcph.com/en/discover/stovetop-tomato-confit — directly displays two cups small tomatoes with two cups olive oil, one head garlic and herbs in a small pot, with tomatoes fully submerged and freely bobbing for about 90 minutes. That route is technically credible but materially different in oil use, vessel and shape-holding texture; Marco chose the shallow skillet route instead.

Safety later validation — National Center for Home Food Preservation, “Freezing Garlic-In-Oil,” https://nchfp.uga.edu/how/freeze/vegetable/freezing-garlic-in-oil/ — garlic in oil must be kept at 4°C or below for no more than four days; freeze for longer storage. USDA-FSIS leftover guidance requires refrigeration within two hours and shallow containers for faster cooling.

### Material changes
2026-07-17 — GPT — Reconstruction during initial verification: removed false readiness, rejected the unsupported 600g/250ml/fully-submerged 28cm-pan composite, supplied direct reader-facing stovetop evidence for two credible routes, corrected the garlic-in-oil storage boundary and routed the preference choice to Human Review.
2026-07-17 — GPT — Reconstruction: integrated Marco’s route-A decision, removed the superseded fully submerged route from the executable brief, rebuilt complete quantities, method, success boundaries, shopping and storage for the shallow-skillet version, and reset verification to Claude.
