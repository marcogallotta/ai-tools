Chicken cacciatore with olives, capers, rosemary and sage

Bone-in chicken braised in a tight tomato sauce with soffritto, olives, capers, rosemary, sage and a fresh parsley finish.

WHY COOK IT
Explore a genuinely different briny-herbal branch after earlier successful cacciatore cooks.


## QUANTITIES
- Bone-in chicken pieces: 800–900g
- Onion: 150g
- Carrot: 80g
- Celery: 80g
- Garlic: 1 small clove
- Olive oil: 30ml
- Red wine vinegar: 8ml, for deglazing (halal substitute for the sources' wine)
- Chopped tomato, pelati or passata: 300–350g
- Unsalted stock or water: 75–100ml initially
- Olives: 120–160g
- Capers: 20–25g, drained
- Rosemary: 1 small sprig
- Sage: 3–4 leaves
- Flat-leaf parsley: 10–15g
- Fine salt and black pepper

## HOW TO COOK IT
1. Brown chicken well in uncrowded batches and remove.
2. Cook onion, carrot and celery until soft and lightly golden; add garlic briefly.
3. Add the vinegar to deglaze the pan, scraping up any browned bits, and let it reduce almost completely — this replaces the wine deglaze used in the source recipes.
4. Add tomato, rosemary, sage and 75ml liquid; return chicken.
5. Cover and simmer gently until nearly tender.
6. Add olives partway through and capers for the final 10–15 minutes.
7. Uncover and reduce until sauce clings; add remaining liquid only if tenderness requires it.
8. Remove woody herbs, taste before salting or adding acid, and finish with parsley and pepper.

## WHAT SUCCESS LOOKS LIKE
Chicken retains visible browning in a cohesive clinging tomato sauce. Olives and capers remain distinct, rosemary leads, sage supports and parsley stays bright; no watery red pool surrounds the chicken.

Visual reference — https://www.soniaperonaci.it/pollo-alla-cacciatora/ — Observe browned bone-in chicken, cohesive tomato sauce, whole olives and visible woody herbs. Ignore exact olive quantity, wine/liquid and seasoning ratios; this task adds capers late and substitutes a vinegar deglaze for wine.

## WATCH OUT FOR
Taste olives and capers before salting. Do not use much sage or add lemon automatically.

---
## PROCESS RECORD
{{MIGRATED_DISH_STATE_BLOCK}}
### Planning brief
Dish candidate: Chicken cacciatore with olives, capers, rosemary and sage
Purpose: Explore a genuinely different briny-herbal branch after earlier successful cacciatore cooks.
Role: main
Priors: None
Locks: Choose the tomato, olive, caper, rosemary, sage and parsley branch.
Exemptions: None
Research emphasis: Whether sage improves the rosemary-tomato profile, whether final salinity remains balanced, and whether the vinegar deglaze reads cleanly against the other acids in the dish.
Destination section: Mediterranean — {{TARGET_SECTION_GID}}

### Decisions
Human — Marco: Choose the tomato, olive, caper, rosemary, sage and parsley branch.

### Research basis
Intentional cacciatore branch built from directly relevant Italian precedents.
Construction — GialloZafferano, "Pollo alla Cacciatora": https://ricette.giallozafferano.it/Pollo-alla-cacciatora.html — supplied browned chicken, soffritto, tomato, garlic, rosemary, wine-deglaze and slow braising. Verified directly against full page text; its FAQ explicitly notes olives are a common addition, not in the original recipe.
Construction — Sonia Peronaci, "Pollo alla Cacciatora": https://www.soniaperonaci.it/pollo-alla-cacciatora/ — supplied the tomato, rosemary, sage, olive and wine-deglaze branch. Verified directly against full page text.
Construction — Nocemoscata, olive-caper cacciatore: https://blog.giallozafferano.it/nocemoscata/pollo-alla-cacciatora-olive-capperi/ — supplied a close olive, caper and tomato precedent; also uses wine and vinegar deglaze, no rosemary/sage, and adds capers early rather than late (this task deliberately adds them late).
Construction — Human — Marco decision recorded in this task — selected the combined briny-herbal branch.
Later validation — Sonia Peronaci, re-inspected during the visual audit and again during verification — checked browning, sauce cling, olives and visible herbs only.
Technical premise: directly supported as a composite branch. Late capers, staged salting and the vinegar deglaze control briny concentration and replace wine's acid role without claiming one universal cacciatore formula.

Legacy agent construction/provenance (not Dish evidence):
Agent — Codex: Retained staged salting as the key guardrail.
Agent — GPT-5.6 Thinking: Normalised construction and later-visual source roles.
Agent — Claude: Verified both Sonia Peronaci and GialloZafferano sources directly (full page text supplied by Marco). Both deglaze with red wine before adding tomato — a structural acid/fond-release step, not just liquid volume. Added a red-wine-vinegar deglaze to replace that role, since wine itself is excluded for halal.

### Material changes
None explicitly recorded.
