Pasta al limone — peak-season lemon pasta

A light lemon pasta using zest, restrained juice, butter, Parmigiano and pasta water. The target is a glossy emulsion rather than a cream sauce.

WHY COOK IT
Make a straightforward fresh pasta when good unwaxed lemons are at their peak.


## WHAT TO BUY
- Dry pasta: 140g
- Butter: 25g
- Unwaxed lemon: 1
- Parmigiano Reggiano: 20–25g

## QUANTITIES
Portions: 1 fresh sitting.
- Dry pasta: 140g
- Butter: 25g
- Lemon zest: from 1 unwaxed lemon
- Lemon juice: begin with 12ml
- Parmigiano Reggiano: 20–25g, finely grated
- Reserved pasta water: at least 250ml
- Fine salt and black pepper

## HOW TO COOK IT
1. Cook the pasta until 1–2 minutes short; reserve at least 250ml pasta water.
2. Melt the butter gently and warm the zest without browning.
3. Add the pasta and about 100ml pasta water; toss vigorously until glossy and nearly tender.
4. Remove from fierce heat. Add Parmigiano gradually, loosening with pasta water as needed.
5. Add the starting lemon juice, toss and taste. Add more only if needed.
6. Finish with black pepper and extra zest if useful.

## WHAT SUCCESS LOOKS LIKE
A thin, glossy emulsion coats every strand with no oil pool, watery runoff or cheese clumps. Lemon aroma leads and the acidity is bright rather than harsh.

## WATCH OUT FOR
Do not add cheese over fierce heat, add all the juice before the emulsion forms or use cream.

## STORAGE
None. Eat immediately.

---
## PROCESS RECORD
{{MIGRATED_DISH_STATE_BLOCK}}
### Planning brief
Dish candidate: Pasta al limone — peak-season lemon pasta
Purpose: Make a straightforward fresh pasta when good unwaxed lemons are at their peak.
Role: main
Priors: None
Locks: Wait for peak lemon season and use the standard 140g dry-pasta portion. No further experiment or branch is needed.
Exemptions: None
Research emphasis: None
Destination section: Mediterranean — {{TARGET_SECTION_GID}}

### Decisions
Human — Marco: Wait for peak lemon season and use the standard 140g dry-pasta portion. No further experiment or branch is needed.

### Research basis
Source-backed pasta al limone.
Construction — Serious Eats, Pasta al Limone — supports butter, zest, pasta water, cheese and late lemon juice.
Construction — La Cucina Italiana, Frank Prisinzano spaghetti al limone — corroborates butter, lemon and Parmigiano without cream.

### Material changes
None explicitly recorded.
