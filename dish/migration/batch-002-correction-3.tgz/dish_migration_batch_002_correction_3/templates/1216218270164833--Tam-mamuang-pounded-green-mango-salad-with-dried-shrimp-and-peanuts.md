Tam mamuang — pounded green mango salad with dried shrimp and peanuts

A crunchy Thai pounded salad using firm green mango, dried shrimp and roasted peanuts. The dressing ingredients are pounded before the mango is lightly bruised, making this tam-style rather than yam-style.

WHY COOK IT
Make a complete green-mango tam with savoury dried shrimp, roasted peanuts and a bright sour-salty-hot dressing.


## WHAT TO BUY
None. The approved homemade dried-shrimp batch is in stock; this dish uses 15g.

## QUANTITIES
Portions: one fresh side salad.
- Green mango: 300g, peeled and fine-julienned
- Dried shrimp: 15g, briefly rinsed and patted dry
- Roasted peanuts: 20g, divided
- Garlic: 1 small clove
- Thai chillies: 1–2
- Palm sugar: 7g
- Lime juice: 13ml
- Fish sauce: 20ml
- Optional cherry tomatoes: 80g, halved

## HOW TO COOK IT
1. Pound garlic and chilli, then add dried shrimp and half the peanuts and pound coarsely rather than to a paste.
2. Add palm sugar and work until mostly dissolved.
3. Add lime juice and fish sauce; taste for a prominently sour, salty-hot balance with controlled sweetness.
4. Add shredded green mango and optional tomatoes. Lightly pound and toss only enough to bruise and coat them.
5. Finish with remaining peanuts and serve immediately.

## WHAT SUCCESS LOOKS LIKE
Mango stays crisp and sharply tart. Long strands remain separate and visibly coated rather than crushed into pulp; dried shrimp and coarse peanut pieces stay identifiable. The dressing is bright, salty, sour and hot rather than syrupy.

## WATCH OUT FOR
Do not use a ripe or soft mango, let the dressed salad sit, or grind dried shrimp or peanuts into paste.

---
## PROCESS RECORD
{{MIGRATED_DISH_STATE_BLOCK}}
### Planning brief
Dish candidate: Tam mamuang — pounded green mango salad with dried shrimp and peanuts
Purpose: Make a complete green-mango tam with savoury dried shrimp, roasted peanuts and a bright sour-salty-hot dressing.
Role: non-main — salad side; the green-mango salad is not a full meal candidate
Priors: None
Locks: approved using the homemade dried-shrimp batch; 15g is required and no fresh purchase is needed.
Exemptions: None
Research emphasis: None
Destination section: Verification Queue — {{TARGET_SECTION_GID}}

### Decisions
Human — Marco: approved using the homemade dried-shrimp batch; 15g is required and no fresh purchase is needed.

### Research basis
Source-backed dish. Saveur’s som tum mamuang provides the direct pounded green-mango construction. Normalising its approximately 680g mango formula to 300g gives the task’s 20ml fish sauce, 13ml lime juice and approximately 7g palm sugar. The pounding order and coarse shrimp/peanut treatment are retained.
Source: https://www.saveur.com/article/Recipes/Thai-Green-Mango-Salad-Som-Tum-Mamuang/

Legacy agent construction/provenance (not Dish evidence):
Human — Moinudin, 2026-07-30: keep this as a normal dish and remove unnecessary comparison framing against the earlier plain mango salad.

### Material changes
None explicitly recorded.
