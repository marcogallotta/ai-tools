Muhammara — charred red pepper and walnut dip

A small Aleppo-style mezze dip of charred red pepper, toasted walnuts, breadcrumbs, pomegranate molasses, cumin and chilli. The first run uses sweet paprika plus Kashmiri chilli as a disclosed substitute for Aleppo pepper.

WHY COOK IT
Learn muhammara's pepper-walnut-breadcrumb structure and pomegranate molasses as the sweet-sour driver. A later Aleppo-pepper repeat can isolate the substitution loss.


## WHAT TO BUY
- One large red bell pepper, about 250g

## CHECK BEFORE COOKING
Confirm frozen pomegranate molasses is thawed. Confirm walnuts, sweet paprika and Kashmiri chilli are fresh.

## QUANTITIES
One small tasting batch.
- Red bell pepper: 1 large, about 250g
- Walnuts: 55g, toasted
- Fresh breadcrumbs: 15g
- Extra-virgin olive oil: 20ml in the dip plus 5ml to finish
- Pomegranate molasses: begin with 10ml; hold up to 5ml
- Lemon juice: begin with 5ml; hold up to 5ml
- Cumin seed: 1/2 tsp, toasted and ground
- Sweet paprika: 2 tsp
- Kashmiri chilli: begin with 1/4 tsp
- Garlic: 1 small clove
- Fine salt: begin with 1.5g

## HOW TO COOK IT
1. Char the whole pepper directly over the gas flame until blackened and soft, about 6-10 minutes. Cover 10 minutes, peel, deseed and drain thoroughly.
2. Toast walnuts and cumin separately.
3. Pulse pepper, walnuts, breadcrumbs, garlic, 10ml molasses, 5ml lemon, cumin, paprika, Kashmiri chilli, salt and 20ml oil to a cohesive but slightly textured paste.
4. Taste before using the held molasses, lemon or chilli. Adjust in small steps.
5. Finish with 5ml olive oil.

## WHAT SUCCESS LOOKS LIKE
Pepper remains clear; walnut gives body and slight bitterness; breadcrumb binds without pastiness; molasses is evident but not syrupy. The dip holds shallow ridges and remains slightly textured.
Visual reference: https://www.lemonde.fr/en/summer-reads/article/2025/08/16/syrian-muhammara-haitham-karajay-s-recipe_6744426_183.html - observe the charred peeled peppers and slightly textured paste. Ignore that source's onion and tahini branch.

### ADAPTATION
Sweet paprika plus Kashmiri chilli gives colour and mild warmth but does not reproduce Aleppo pepper's fruity, tangy character.

## STORAGE
Refrigerate covered for 4-5 days. Freeze excess if it will not be eaten in that window.

---
## PROCESS RECORD
{{MIGRATED_DISH_STATE_BLOCK}}
### Planning brief
Dish candidate: Muhammara — roasted red pepper and walnut dip
Purpose: Learn muhammara's pepper-walnut-breadcrumb structure and pomegranate molasses as the sweet-sour driver. A later Aleppo-pepper repeat can isolate the substitution loss.
Role: non-main — dip; muhammara is a dip rather than a full meal candidate
Priors: None
Locks: Make one small batch with sweet paprika plus Kashmiri chilli, then repeat with Aleppo pepper while holding other quantities constant.
Exemptions: None
Research emphasis: Record the final molasses and lemon stop points for the later Aleppo comparison.
Destination section: Seasonal — {{TARGET_SECTION_GID}}

### Decisions
Human — Marco: Make one small batch with sweet paprika plus Kashmiri chilli, then repeat with Aleppo pepper while holding other quantities constant.

### Research basis
Human-approved chilli substitution in a source-backed muhammara structure.
Construction — Guardian waste-not muhammara: https://www.theguardian.com/food/2021/aug/28/how-to-turn-old-bell-peppers-into-muhummara-recipe-zero-waste-not — supplied a high-walnut, low-bread branch but uses sautéed diced pepper and much more molasses.
Later validation — Syrian chef Haitham Karajay/Le Monde: https://www.lemonde.fr/en/summer-reads/article/2025/08/16/syrian-muhammara-haitham-karajay-s-recipe_6744426_183.html — supports open-flame roasting, walnuts, breadcrumbs, molasses, cumin, Aleppo pepper and textured processing; its onion and tahini are not used.
Later validation — The Kitchn: https://www.thekitchn.com/muhammara-recipe-23244814 — independently supports direct gas-flame charring and the pepper-walnut-breadcrumb-molasses structure.
Later validation — Bon Appetit: https://www.bonappetit.com/recipe/muhammara-recipe — supports roughly 40g walnuts, 14g breadcrumbs, 10ml oil and 10ml molasses per large pepper.
Source disagreement: walnut, breadcrumb and molasses ratios vary widely. This small batch uses a bounded high-walnut branch with staged molasses and lemon rather than claiming one canonical formula.

Legacy agent construction/provenance (not Dish evidence):
Agent — Codex: Rebuilt the formula from multiple close charred-pepper sources and retained staged acid/molasses adjustment.

### Material changes
None explicitly recorded.
