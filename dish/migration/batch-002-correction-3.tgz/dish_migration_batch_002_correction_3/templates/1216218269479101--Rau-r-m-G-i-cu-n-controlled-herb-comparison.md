[Rau răm] Gỏi cuốn — controlled herb comparison

Vietnamese fresh rolls with shrimp, poached chicken breast, vermicelli, lettuce, cucumber, blanched bean sprouts and rau răm, served with a light hoisin-and-fresh-ground-peanut sauce.

WHY COOK IT
Compare rau răm directly with the mint-and-cilantro sibling while holding every other component and method constant.


## CHECK BEFORE COOKING
- Harvest about 15g rau răm per sitting; postpone if unavailable.
- Prepare bean sprouts ahead if home-growing.
- Batch proteins and sauce only; cook noodles and roll fresh.

## QUANTITIES
Portions: 3 substantial fresh sittings, about 6 rolls each.

Totals:
- Shrimp: 450g
- Chicken breast: 300g
- Dry rice vermicelli: 180g
- Rice paper: about 18 usable sheets plus spares

Per sitting:
- Shrimp: 150g
- Chicken breast: 100g
- Rice vermicelli: 60g dry
- Rice paper: 6 sheets
- Lettuce: 6 leaves
- Cucumber: about 80g
- Bean sprouts: about 40g, blanched for 10–15 seconds
- Rau răm: about 15g

Shared sauce:
- Hoisin: 45–50ml
- Roasted peanuts: 20g, finely ground
- Water: 50–70ml
- Garlic: 1 small clove
- Chilli: optional
- White sugar: only if needed
- Added oil: none

## HOW TO COOK IT
1. Poach chicken gently to a safe endpoint, cool, slice and portion.
2. Cook shrimp just opaque, cool and portion.
3. Simmer hoisin, 50ml water and garlic briefly; stir in ground peanut and loosen only as needed. Portion the sauce.
4. Keep vegetables and rau răm dry and separate.
5. Each sitting, cook 60g noodles fresh, soften wrappers briefly and assemble immediately.

## WHAT SUCCESS LOOKS LIKE
The physical rolls and sauce perform identically to the mint-and-cilantro sibling, leaving the herb effect legible. Wrappers are translucent and taut rather than split, gummy or loose; fillings form an even cylinder without overfilling.

Visual reference — http://web.archive.org/web/20260116090032/https://www.seriouseats.com/vietnamese-rice-paper-roll-platter-technique-11885063 — Observe rice paper moistened lightly rather than soaked, fillings placed in the lower third with side margins, and the wrapper tightened as it rolls. This validates hydration, placement and tight-cylinder boundaries. Ignore the source's variable proteins, sauces and herbs; it does not validate the chicken-for-pork substitution or the controlled-comparison quantities.

## WATCH OUT FOR
Do not vary sauce, protein, vegetables, noodle quantity or wrapper method between siblings; do not pre-roll or over-soak wrappers. Shrimp plus chicken breast is a halal adaptation and chicken does not reproduce pork belly.

## STORAGE
Batch proteins and sauce only. Cook noodles and roll fresh.

---
## PROCESS RECORD
{{MIGRATED_DISH_STATE_BLOCK}}
### Planning brief
Dish candidate: [Rau răm] Gỏi cuốn — controlled herb comparison
Purpose: Compare rau răm directly with the mint-and-cilantro sibling while holding every other component and method constant.
Role: non-main — comparison; the controlled herb comparison is not a meal candidate
Priors: None
Locks: Approved shrimp and chicken filling and a three-sitting controlled comparison of rau-răm against mint/cilantro. Peppermint was used in the past cooks; a peppermint-versus-spearmint control remains a separate, non-blocking open question.
Exemptions: None
Research emphasis: Practical only: rau răm and the control herbs must be harvestable.
Destination section: Verification Queue — {{TARGET_SECTION_GID}}

### Decisions
Human — Marco: Approved shrimp and chicken filling and a three-sitting controlled comparison of rau-răm against mint/cilantro. Peppermint was used in the past cooks; a peppermint-versus-spearmint control remains a separate, non-blocking open question.

### Research basis
Intentional test dish, human-approved.
Construction update — This task is an approved controlled comparison, not a claim that chicken reproduces pork-belly gỏi
cuốn. Its mint/cilantro sibling (`1216218493768382`) now matches it exactly in shrimp, chicken,
noodles, wrapper, vegetables, sauce and three-sitting structure; only the herbs differ. Published
gỏi-cuốn practice permits varied fillings, including shrimp and chicken, and commonly serves a
garlic, hoisin/tương and peanut sauce. The Serious Eats technique source directly supports brief
wrapper hydration and tight lower-third assembly. The live URL is dead/paywalled; the Wayback
snapshot dated 2026-01-16 above is the accessible locator carrying the same content.

Research conclusion: the comparison design itself is the construction rationale and Marco has
approved it. It is sufficiently researched to run. The cook should record wrapper brand, actual
number of usable rolls, and the herb result without changing any other component. Harvestability is
readiness only.
Sources: <http://web.archive.org/web/20260116090032/https://www.seriouseats.com/vietnamese-rice-paper-roll-platter-technique-11885063>

### Material changes
None explicitly recorded.
