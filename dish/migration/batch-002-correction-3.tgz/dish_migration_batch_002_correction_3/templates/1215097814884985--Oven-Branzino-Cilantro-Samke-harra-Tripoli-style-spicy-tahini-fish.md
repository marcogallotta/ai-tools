[Oven] Samke harra — Tripoli-style spicy tahini fish

Deferred Levant dish for a future kitchen with an oven.

Planning brief:
- Preferred fish: one small whole branzino, roughly 350–450g.
- Defining structure: whole roasted fish with a spicy tahini-lemon sauce containing garlic, chilli, cumin and fresh cilantro, finished with toasted pine nuts.
- Do not research, verify or adapt this to stovetop equipment now.
- Reopen only when an oven is available; then construct the canonical recipe from direct samke harra sources.

Blocker: oven unavailable.

legacy process-record heading
Stage: Planning — deferred
Human review: Moinudin, complete
Verification: Not applicable while deferred

Human decision — Moinudin: Mark this explicitly as oven-blocked, keep it in the Levant section for later, and do not spend research or verification work on it now.

---
## PROCESS RECORD
{{MIGRATED_DISH_STATE_BLOCK}}
### Planning brief
Dish candidate: [Oven] [Branzino] [Cilantro] Samke harra — Tripoli-style spicy tahini fish
Purpose: Preserve a deferred oven-only Tripoli-style samke harra candidate for reconstruction from direct sources when an oven becomes available.
Role: main
Priors: None
Locks: Mark this explicitly as oven-blocked, keep it in the Levant section for later, and do not spend research or verification work on it now.
Exemptions: None
Research emphasis: None
Destination section: Levant — {{TARGET_SECTION_GID}}

### Decisions
None explicitly recorded as a Human — Marco decision in the legacy source.

### Research basis
No explicit legacy Research basis captured.

### Material changes
None explicitly recorded.
