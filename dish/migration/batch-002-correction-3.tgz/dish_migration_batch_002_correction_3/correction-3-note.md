# Batch 002 correction 3

All 99 templates were regenerated so the canonical `---` line is immediately followed by `## PROCESS RECORD`.

Legacy structural-marker text was neutralized only in these source GIDs:

- `1215097814884985`
- `1215104415372074`
- `1215104415372138`
- `1215757125278571`
- `1216218385656254`

No Planning brief, Decisions, Research basis, Material changes, placeholder, or destination content was otherwise changed.

The preserved legacy state blocks in `1215757125278571` and `1216218385656254` were indented as literal legacy prose so the batch validator does not treat their old `Status:` lines as current Dish state.

The real parser audit also required demoting unsupported legacy `##` body headings to `###` in these GIDs, without changing heading wording or body content:

- `1215097333030243`
- `1215097998700112`
- `1215106595916373`
- `1215653612558613`
- `1215756929399043`
- `1216470869914544`
- `1216471601619985`
- `1216471816507601`
- `1216484382799072`
