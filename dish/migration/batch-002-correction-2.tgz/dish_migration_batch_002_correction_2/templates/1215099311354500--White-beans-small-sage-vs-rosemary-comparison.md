White beans — small sage versus rosemary comparison

One small neutral white-bean base split into two herb-oil finishes: lightly crisp sage and gently infused rosemary.

WHY COOK IT
Compare how sage and rosemary behave in olive oil against the same bean base at low cost.


## QUANTITIES
Two small tasting bowls.

Bean base:
- Cooked white beans: 200g drained
- Bean liquor, stock or water: 50–70ml as needed
- Fine salt and black pepper

Sage finish:
- Olive oil: 8–10ml
- Fresh sage: 3–4 leaves
- Garlic: a very small lightly crushed piece

Rosemary finish:
- Olive oil: 8–10ml
- Fresh rosemary: one small sprig
- Garlic: a very small lightly crushed piece

## HOW TO COOK IT
1. Warm the beans with enough liquid to become creamy while remaining mostly intact. Season, then split evenly.
2. Sage branch: heat oil gently with sage and garlic until fragrant and the leaves are lightly crisp. Remove garlic before it browns; spoon over one bowl.
3. Rosemary branch: infuse oil very gently with rosemary and garlic for several minutes. Remove the solids before they become harsh; spoon over the other bowl.
4. Taste side by side before adding any lemon.

## WHAT SUCCESS LOOKS LIKE
Both bowls have the same bean texture. Sage reads leafy and savoury with lightly crisp leaves; rosemary reads cleanly piney without bitterness or medicinal harshness.

## WATCH OUT FOR
Do not scorch garlic, fry rosemary hard, purée the beans or let lemon dominate.

---

## PROCESS RECORD
{{MIGRATED_DISH_STATE_BLOCK}}
### Planning brief
Dish candidate: White beans — small sage vs rosemary comparison
Purpose: Compare how sage and rosemary behave in olive oil against the same bean base at low cost.
Role: non-main — comparison; the small sage-versus-rosemary bean comparison isolates one variable
Priors: None
Locks: Retain the comparison but reduce it to about 200g cooked beans total with 8–10ml oil per branch.
Exemptions: None
Research emphasis: None
Destination section: Verification Queue — {{TARGET_SECTION_GID}}

### Decisions
Human — Marco: Retain the comparison but reduce it to about 200g cooked beans total with 8–10ml oil per branch.

### Research basis
Both sage-and-bean and rosemary-and-bean combinations are established. This is a bounded sensory comparison, not an authenticity claim.

### Material changes
None explicitly recorded.
