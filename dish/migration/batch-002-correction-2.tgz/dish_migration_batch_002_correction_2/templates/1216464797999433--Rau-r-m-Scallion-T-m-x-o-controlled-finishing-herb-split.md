[Rau răm] [Scallion] Tôm xào — controlled finishing-herb split

Quick garlic-and-fish-sauce shrimp with a Human-approved 2+1 finishing split: two scallion portions and one rau-răm portion. This is a composed Vietnamese-style comparison, not a claim of a standard named traditional dish.

WHY COOK IT
Test rau răm in a hot application while holding the shrimp, sauce, rice and cooking method constant.


## WHAT TO BUY
- Peeled, deveined shrimp: 600g
- Scallions: 2
- Jasmine rice: 450g dry if not already on hand

Garlic is in stock according to the pantry snapshot; confirm at least 50g remains. Rau răm must be harvestable.

## CHECK BEFORE COOKING
- Harvest 10–15g rau răm.
- Confirm two scallions and 450g dry jasmine rice.
- Mix fish sauce, sugar and pepper for the shared base.
- The herb split stays together as one planned comparison, but each portion receives its herb only at that portion’s actual serving time.

## QUANTITIES
Portions: 3.

Shared shrimp base:
- Shrimp: 600g
- Garlic: 50g, minced
- Fish sauce: 30ml
- White sugar: 3.5g
- Black pepper: 2g
- Neutral oil: 50ml

Finishing:
- Scallion portions (2): 1 chopped scallion per portion
- Rau-răm portion (1): 10–15g torn rau răm

Rice:
- Jasmine rice: 450g dry total, 150g per portion, cooked fresh per sitting

## HOW TO COOK IT
1. Heat the wok strongly. Add oil and fry garlic for 15–20 seconds without browning.
2. Add shrimp in two batches if needed and sear until about halfway cooked.
3. Turn, add the premixed fish sauce, sugar and pepper, and cook only until barely opaque.
4. If the sauce needs reduction, remove the shrimp, reduce the liquid briefly, then return the shrimp only to coat.
5. Remove from heat and divide the unherbed shrimp base into three equal portions by weight.
6. For the first sitting, reheat one portion only if necessary, remove from heat, and fold in its assigned herb for 10–15 seconds.
7. Refrigerate the other two portions without herbs. At each later sitting, reheat one portion gently, remove from heat, and add either one chopped scallion or the rau răm according to the fixed 2+1 assignment.
8. Cook 150g dry rice fresh for each sitting.

## WHAT SUCCESS LOOKS LIKE
Shrimp remain juicy and lightly glazed. Each herb is added at the same final off-heat stage, so the comparison is between fresh scallion and fresh rau răm rather than between fresh and stored herbs.

## WATCH OUT FOR
- Do not add herbs to portions that will be stored.
- Do not reduce sauce around fully cooked shrimp.
- Do not change the shrimp, sauce or rice between portions.
- Rau răm is an intentional test variable, not a documented traditional shrimp pairing.

## STORAGE
Store the two later shrimp-base portions unherbed and separately labelled. Reheat gently once; add the assigned herb only after reheating and off heat.

---

## PROCESS RECORD
{{MIGRATED_DISH_STATE_BLOCK}}
### Planning brief
Dish candidate: [Rau răm] [Scallion] Tôm xào — controlled finishing-herb split
Purpose: Test rau răm in a hot application while holding the shrimp, sauce, rice and cooking method constant.
Role: non-main — technique comparison; the controlled finishing-herb split isolates one variable
Priors: None
Locks: approved one shared three-portion garlic-shrimp base with a 2+1 scallion/rau-răm split and confirmed that the comparison remains one task.
Exemptions: None
Research emphasis: None
Destination section: Verification Queue — {{TARGET_SECTION_GID}}

### Decisions
Human — Marco: approved one shared three-portion garlic-shrimp base with a 2+1 scallion/rau-răm split and confirmed that the comparison remains one task.

### Research basis
A Vietnamese garlic-shrimp construction supports the 600g shrimp, 50g garlic, 30ml fish sauce, 3.5g sugar, 2g pepper and 50ml oil base, with scallion as a supported finish. Rau răm remains the Human-approved experimental variable. Keeping later portions unherbed prevents storage degradation from becoming a second variable.

Legacy agent construction/provenance (not Dish evidence):
Agent — GPT: corrected the control design so all three herbs are added fresh at actual service; removed the earlier instruction to store already-scallion-finished shrimp.

### Material changes
2026-07-30 — Preserved the approved 2+1 split but changed storage and execution: divide the base unherbed, then add each assigned herb fresh after reheating at the sitting when that portion is eaten.
