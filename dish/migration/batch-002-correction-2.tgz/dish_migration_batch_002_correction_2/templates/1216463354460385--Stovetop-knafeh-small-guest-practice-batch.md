Stovetop knafeh — small guest-practice batch

A no-oven kataifi cheese pastry cooked in a pan, with a crisp ghee-coated shell, mozzarella-ricotta filling and cool orange-blossom syrup.

WHY COOK IT
Rehearse pan browning, kataifi fat distribution, cheese containment, inversion and syrup timing before guest service.


## WHAT TO BUY
- Kataifi dough: 200g
- Low-moisture mozzarella: 200g
- Full-fat ricotta: 100g
- Orange blossom water: small bottle; need up to 8ml
- Pistachios: 15g, optional

## QUANTITIES
One 18–20cm knafeh, 4–6 small servings.
- Kataifi dough: 200g
- Ghee or clarified butter: 85–90g
- Low-moisture mozzarella: 200g
- Full-fat ricotta: 100g, well drained
- Fine salt: optional pinch
- White sugar: 180g
- Water: 110ml
- Lemon juice: 6ml
- Orange blossom water: start with 5ml; up to 8ml
- Pistachios: 15g, optional

## HOW TO COOK IT
1. Simmer sugar, water and lemon for 5–7 minutes. Cool fully, then add orange blossom water.
2. Mix mozzarella and drained ricotta.
3. Separate kataifi and coat evenly with ghee.
4. Press two-thirds into the base and 2–3cm up the sides.
5. Add cheese inside a 1.5cm border, cover with remaining kataifi and press to seal.
6. Cook over the lowest reliable heat, rotating frequently, until the first side is deep golden, roughly 18–28 minutes.
7. Invert onto a wider plate, slide back and cook the second side for roughly 8–12 minutes.
8. Add cool syrup gradually, beginning with one-third.

## WHAT SUCCESS LOOKS LIKE
Both faces are evenly deep golden and crisp. Cheese remains contained and stretchy; syrup moistens without destroying exterior crispness or pooling.

Visual reference — https://bakewithzoha.com/palestinian-knafeh/ — Observe ghee-coated and firmly compressed kataifi, cheese containment, a crisp golden shell, melted cheese and gradual syrup application. Ignore oven method, colouring, fresh mozzarella, traditional sweet cheese and large batch.

## WATCH OUT FOR
Do not use wet ricotta, high heat, hot syrup on hot pastry or all the syrup automatically.

---

## PROCESS RECORD
{{MIGRATED_DISH_STATE_BLOCK}}
### Planning brief
Dish candidate: Stovetop knafeh — small guest-practice batch
Purpose: Rehearse pan browning, kataifi fat distribution, cheese containment, inversion and syrup timing before guest service.
Role: non-main — dessert; the small guest-practice batch is not a meal candidate
Priors: None
Locks: Confirmed mozzarella-and-ricotta filling with the no-oven pan-inversion method. | Approved the current 18–20cm guest-practice batch unchanged.
Exemptions: None
Research emphasis: None
Destination section: Verification Queue — {{TARGET_SECTION_GID}}

### Decisions
Human — Marco: Confirmed mozzarella-and-ricotta filling with the no-oven pan-inversion method.
Human — Marco: Approved the current 18–20cm guest-practice batch unchanged.

### Research basis
Human-approved stovetop adaptation.
Construction — Food Network, https://www.foodnetwork.com/recipes/food-network-kitchen/kunefe-11933578 — supports buttered kataifi pressed into a pan, enclosed cheese, browning, inversion and syrup.
Construction — Feel Good Foodie, https://feelgoodfoodie.net/recipe/knafeh/ — supports kataifi handling, cheese containment and syrup timing.
Visual validation — Bake With Zoha, https://bakewithzoha.com/palestinian-knafeh/ — supports compressed kataifi, golden shell and gradual syrup application.

### Material changes
None explicitly recorded.
