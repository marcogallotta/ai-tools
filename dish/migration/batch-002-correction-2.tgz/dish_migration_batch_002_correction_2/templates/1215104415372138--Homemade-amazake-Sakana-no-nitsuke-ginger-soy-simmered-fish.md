[Homemade amazake] Sakana no nitsuke — ginger-soy simmered fish

Deferred planning brief for an alcohol-free Japanese fish simmer using Marco's homemade amazake. Amazake is available, so sourcing is no longer the blocker; the unresolved decision is the actual simmering formula.

INTENT
Build a nitsuke-inspired fish simmer that preserves the supported Japanese technique while openly adapting the sake-and-mirin seasoning structure.

KEEP
- Firm skin-on fish
- Brief pre-salting
- 15–20 second blanch and cold rinse
- Single-layer simmer
- Drop lid
- Staged soy addition and basting
- Cooling briefly in the broth

UNRESOLVED FORMULA
Homemade amazake may supply sweetness, koji character and body, but it is not a direct replacement for sake or mirin. Before execution, taste and record its sweetness, thickness and acidity, then construct one small portion around those properties. Do not reuse the former water-soy-sugar formula or assume a fixed amazake dose.

PROCESS RECORD
Stage: Planning
Human review: Marco — use homemade amazake as the adaptation route
Research: Not started; intentionally deferred
Verification: Not applicable until reconstructed

---

## PROCESS RECORD
{{MIGRATED_DISH_STATE_BLOCK}}
### Planning brief
Dish candidate: [Homemade amazake] Sakana no nitsuke — ginger-soy simmered fish
Purpose: Build an alcohol-free nitsuke-inspired fish simmer around the measured properties of Marco’s homemade amazake while preserving the supported Japanese simmering technique.
Role: main
Priors: None
Locks: Use homemade amazake as the adaptation route.
Exemptions: None
Research emphasis: None
Destination section: Fish — {{TARGET_SECTION_GID}}

### Decisions
None explicitly recorded as a Human — Marco decision in the legacy source.

### Research basis
No explicit legacy Research basis captured.

### Material changes
None explicitly recorded.
