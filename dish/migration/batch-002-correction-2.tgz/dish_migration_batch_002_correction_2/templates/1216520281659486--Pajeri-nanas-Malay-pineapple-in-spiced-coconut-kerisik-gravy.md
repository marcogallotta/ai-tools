Pajeri nanas — Malay pineapple in spiced coconut-kerisik gravy

Pineapple cooked with aromatics, warm spices, curry powder, coconut milk and kerisik. This is a later Indo/Malay backlog dish, not a use-up task for frozen fruit.

WHY COOK IT
Learn pineapple as the main ingredient in a rich spiced coconut-and-kerisik gravy, distinct from its role in light tamarind soup.


## QUANTITIES
Three side portions with rice and another dish.
- Pineapple: 500–600g chunks
- Coconut milk: 200–250ml
- Water: 100–150ml as needed
- Shallot or onion: 100g
- Garlic: 8g
- Ginger: 10g
- Fresh red chilli: 1–2; green chilli optional
- Curry powder: 12–18g, mixed with water to a paste
- Cinnamon: 1 small stick
- Star anise: 1
- Cloves: 2–3
- Cardamom: 2–3 pods, optional
- Curry leaves: 1 sprig, optional
- Kerisik: 20–30g
- Fine salt: start with 4g
- White sugar: start with 0–8g according to fruit
- Neutral oil: 25ml

## HOW TO COOK IT
1. If making kerisik, toast grated coconut slowly until deep golden, then grind or pound to an oily paste.
2. Pound or blend shallot, garlic, ginger and chilli.
3. Fry whole spices and curry leaves in oil.
4. Add aromatics and cook until raw smell fades.
5. Add curry-powder paste and fry until cooked and oil begins showing.
6. Add pineapple and coat for 5–10 minutes.
7. Add coconut milk and enough water for a spoonable gravy; simmer gently.
8. Stir in kerisik and simmer briefly to thicken.
9. Adjust salt, sugar and chilli; keep the result savoury and sweet-sour rather than dessert-sweet.

## WHAT SUCCESS LOOKS LIKE
Pineapple remains the clearly dominant ingredient in distinct chunks. A brown-gold coconut-kerisik gravy coats while still settling around the fruit; it is neither watery nor dry paste.

Visual reference — https://www.ajinomoto.com.my/recipes/pineapple-pajeri — Observe distinct pineapple chunks in cohesive brown-gold coconut-kerisik gravy. Ignore branded seasoning and exact ratios.

## WATCH OUT FOR
Do not skip cooking the curry paste, boil coconut hard, sweeten before tasting the fruit or add belacan or dried shrimp automatically. Keep the first baseline vegetarian unless halal suitability is settled.

## STORAGE
Refrigerate 2–3 days and reheat gently.

---

## PROCESS RECORD
{{MIGRATED_DISH_STATE_BLOCK}}
### Planning brief
Dish candidate: Pajeri nanas — Malay pineapple in spiced coconut-kerisik gravy
Purpose: Learn pineapple as the main ingredient in a rich spiced coconut-and-kerisik gravy, distinct from its role in light tamarind soup.
Role: non-main — side dish; pineapple in coconut-kerisik gravy is a supporting dish
Priors: None
Locks: Add pajeri nanas to the Indo/Malay backlog independently of leftover frozen pineapple.
Exemptions: None
Research emphasis: Fresh versus frozen performance, kerisik quantity and whether the vegetarian baseline needs any additional halal umami.
Destination section: Indonesia/Malaysia — {{TARGET_SECTION_GID}}

### Decisions
Human — Marco: Add pajeri nanas to the Indo/Malay backlog independently of leftover frozen pineapple.

### Research basis
Source-backed Malay/Indonesian pineapple curry with a human-approved vegetarian first baseline.
Construction — Jackie M, “Pajeri Nenas”: https://jackiem.com.au/2026/05/20/how-to-cook-pajeri-nenas-pineapple-curry/ — supplied pineapple, spices, curry paste, coconut cream and kerisik structure.
Construction — Ajinomoto Malaysia, “Pineapple Pajeri”: https://www.ajinomoto.com.my/recipes/pineapple-pajeri — supplied curry leaves, whole spices, curry powder, pineapple, coconut milk and kerisik.
Construction — Cook Me Indonesian, “Pacri Nanas”: https://www.cookmeindonesian.com/pacri-nanas-malay-pineapple-curry-vegan/ — corroborated Malay/Indonesian pineapple curry with aromatics, chilli and warm spice.
Construction — Roti n Rice, pineapple curry: https://www.rotinrice.com/pineapple-curry/ — corroborated pineapple mellowed in coconut milk as a Malaysian side.
Construction — Human — Marco decision recorded in this task — selected it as an independent backlog dish rather than a leftover-use task.
Later validation — Ajinomoto Malaysia, re-inspected during the visual audit — checked pineapple integrity and cohesive gravy only; branded seasoning was excluded.
Technical premise: directly supported. Exact sugar and water are intentionally fruit-dependent, while the vegetarian baseline keeps the pineapple and kerisik lesson legible.

Legacy agent construction/provenance (not Dish evidence):
Agent — Codex: Framed it around pineapple in a rich coconut-kerisik gravy and excluded belacan or dried shrimp from the baseline unless halal suitability is settled.
Agent — GPT-5.6 Thinking: Normalised construction and later-validation source roles.
Agent — Claude: Verification reopened the Ajinomoto source directly; confirms whole-spice tempering, curry-powder paste and the pineapple/coconut milk/kerisik structure. The source's own dried-prawn addition is correctly left as an open question rather than silently included or excluded. No issues found.

### Material changes
None explicitly recorded.
