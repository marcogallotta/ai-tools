[Homemade miso] Saba misoni — mackerel simmered in miso

A future homemade-miso application dish. The recipe should be rebuilt around the actual salinity, sweetness, age and aroma of Moinudin's homemade miso rather than treated as a generic less-sweet repeat.


## PLANNING BRIEF
- Use mackerel simmered with ginger in a miso-based sauce.
- Homemade miso is mandatory; commercial miso is not the baseline.
- Do not preserve the current 70–90g miso and 15–25g sugar ranges as canonical until the homemade miso is tasted and characterised.
- Rebuild the sauce around the actual miso, then decide whether sugar, soy or acid are needed.
- Keep the dish in the Fish section and out of Research and Verification queues until the homemade-miso lane is defined.

---

## PROCESS RECORD
{{MIGRATED_DISH_STATE_BLOCK}}
### Planning brief
Dish candidate: [Homemade miso] Saba misoni — mackerel simmered in miso
Purpose: Build a future mackerel-and-ginger miso simmer around the measured salinity, sweetness, age and aroma of Marco’s homemade miso rather than preserving a generic formula.
Role: main
Priors: None
Locks: This belongs in a homemade-miso lane, not as a generic correction repeat.
Exemptions: None
Research emphasis: None
Destination section: Fish — {{TARGET_SECTION_GID}}

### Decisions
Human — Marco: This belongs in a homemade-miso lane, not as a generic correction repeat.

### Research basis
No explicit legacy Research basis captured.

### Material changes
None explicitly recorded.
