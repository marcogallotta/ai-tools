Maa ki dal — whole black urad

Whole black urad cooked until fully tender, partly mashed and gently simmered into natural creaminess without relying on heavy dairy.

WHY COOK IT
Learn the whole-urad starch and skin system rather than substituting split urad.


## WHAT TO BUY
- Whole black urad: 180g
- Onion: 150g
- Tomato: 200g
- Garam masala: optional

## QUANTITIES
Portions: 3.
- Whole black urad: 180g
- Soak: 8–12 hours
- Pressure-cook water: start around 700–800ml
- Onion: 150g
- Tomato: 200g
- Ginger: 15g
- Garlic: optional 10g
- Ghee: 25–35ml
- Cumin seed: 1 tsp
- Hing: pinch
- Turmeric: optional 1/4 tsp
- Kashmiri chilli: 1 tsp
- Fine salt: start with 7g
- Own garam masala: optional 1/2 tsp late

## HOW TO COOK IT
1. Soak, drain and rinse whole urad.
2. Pressure-cook with measured water until fully soft; add time rather than stopping with tough skins.
3. Mash or stir a portion to release starch while keeping some beans intact.
4. Make a modest onion-tomato-ghee base with cumin, hing, ginger, garlic and chilli.
5. Combine and simmer gently, adding hot water as needed, until thick, creamy and flowing.
6. Adjust salt and optional garam masala; rest before judging.

## WHAT SUCCESS LOOKS LIKE
Skins are fully tender. Some beans remain visible while others break down into a naturally creamy body that flows slowly from a ladle and settles rather than standing as paste or showing a watery moat.

## WATCH OUT FOR
Do not substitute split urad, reuse split-urad water ratios, make dairy the main lesson or stop with tough skins.

---

## PROCESS RECORD
{{MIGRATED_DISH_STATE_BLOCK}}
### Planning brief
Dish candidate: Maa ki dal — whole black urad
Purpose: Learn the whole-urad starch and skin system rather than substituting split urad.
Role: main
Priors: None
Locks: Keep the dish, but it may remain blocked indefinitely because whole black urad is not currently available and may not be sourced.
Exemptions: None
Research emphasis: Whether whole black urad will ever be sourced; then soak time, pressure time and water adjustment.
Destination section: Subcontinent — {{TARGET_SECTION_GID}}

### Decisions
Human — Marco: Keep the dish, but it may remain blocked indefinitely because whole black urad is not currently available and may not be sourced.

### Research basis
Construction — Dassana Amit/Veg Recipes of India, “Maa ki Dal”: https://www.vegrecipesofindia.com/maa-ki-dal-kaali-dal/ — supports whole black urad, thorough softening, partial mashing and simmering to a creamy but flowing consistency.

Legacy agent construction/provenance (not Dish evidence):
Agent — GPT-5.6 Thinking: Removed experimental and calorie-target framing; retained the three-portion whole-urad recipe as a low-priority blocked dish.

### Material changes
None explicitly recorded.
