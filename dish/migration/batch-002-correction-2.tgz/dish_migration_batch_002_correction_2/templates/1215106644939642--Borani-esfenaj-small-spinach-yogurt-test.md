Borani esfenaj — small spinach-yogurt test

A small Persian spinach-and-yogurt side sharpened with garlic and lemon, with an optional restrained dried-mint oil at serving.

WHY COOK IT
Taste the basic spinach-yogurt-garlic balance at low commitment before deciding whether to scale it up.


## WHAT TO BUY
- Fresh spinach: about 200g, or enough frozen leaf spinach to yield 60–80g after thawing and squeezing
- Thick full-fat yogurt: 100g

## CHECK BEFORE COOKING
- Use genuinely thick yogurt.
- Cool and squeeze the spinach extremely dry before mixing.
- Make mint oil only at serving, if using.

## QUANTITIES
Portions: 1 tasting portion.
- Cooked, very well-squeezed spinach: 60–80g
- Thick full-fat yogurt: 100g
- Garlic: about 1/2 small clove, finely crushed
- Fresh lemon juice: start with 2–3ml
- Fine salt: start with a small pinch
- Black pepper: optional
- Optional mint oil: 3ml olive oil plus a small pinch dried mint

## HOW TO COOK IT
1. Wilt fresh spinach or thaw frozen spinach. Cool fully, squeeze extremely dry and chop finely.
2. Mix 60g squeezed spinach with yogurt, garlic, lemon and salt.
3. Rest chilled for 20 minutes, then taste.
4. If the yogurt still dominates, fold in more squeezed spinach up to about 80g.
5. If using mint oil, warm the oil, remove from direct heat, stir in the mint and spoon over only at service.

## WHAT SUCCESS LOOKS LIKE
Spinach and yogurt are both clearly present. The mixture holds soft spoon ridges with no watery moat; garlic is noticeable but not harsh, and lemon brightens without making it sour.

## WATCH OUT FOR
Do not mix warm or wet spinach into yogurt, use thin yogurt, or increase garlic before the rested taste.

## STORAGE
Best eaten the same day. Refrigerate briefly if needed.

---

## PROCESS RECORD
{{MIGRATED_DISH_STATE_BLOCK}}
### Planning brief
Dish candidate: Borani esfenaj — small spinach-yogurt test
Purpose: Taste the basic spinach-yogurt-garlic balance at low commitment before deciding whether to scale it up.
Role: non-main — test side; the small spinach-yogurt test is explicitly bounded
Priors: None
Locks: Replace the excessive 500g-yogurt batch with a 100g-yogurt tasting portion; scale up only after tasting.
Exemptions: None
Research emphasis: None
Destination section: Verification Queue — {{TARGET_SECTION_GID}}

### Decisions
None explicitly recorded as a Human — Marco decision in the legacy source.

### Research basis
Small Human-approved tasting version of a source-backed spinach borani family.
Construction — Claudia Roden, “Borani-e Esfenaj,” Epicurious — supports squeezed spinach mixed with thick yogurt, raw garlic, lemon and oil.
Construction — Andy Baraghani, “Spinach-Yogurt Dip With Sizzled Mint,” Bon Appétit — supports a separate dried-mint oil finish.
The exact small ratio is a practical tasting scale selected by Human decision, not a claim of a canonical Persian proportion.

Legacy agent construction/provenance (not Dish evidence):
Human — Moinudin, 2026-07-31: Replace the excessive 500g-yogurt batch with a 100g-yogurt tasting portion. Scale up only after tasting.

### Material changes
None explicitly recorded.
