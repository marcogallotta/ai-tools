[Homemade miso] Saikyo-yaki-style fish — one-portion pan adaptation

One portion of firm white fish marinated in homemade white miso and zero-alcohol homemade koji amazake, wiped nearly clean and pan-cooked gently. This is an explicit Saikyo-yaki-style alcohol-free adaptation, not traditional equivalence.

WHY COOK IT
Learn how Marco's homemade white miso behaves in a sweet fish marinade without risking a three-portion batch.


QUANTITIES
Portions: 1.
- Firm white fish: 180–220g
- Homemade white miso: begin with 35g; up to 45g only if mild
- Homemade zero-alcohol koji amazake: begin with 12g; up to 20g to make a spreadable paste and moderate salinity
- Sugar: 0–3g only after tasting the mixture
- Neutral oil: up to 5ml
- Fine salt: optional trace for a 10-minute surface cure only if the miso is unusually mild

HOW TO COOK IT
1. Taste the miso and amazake separately, then together. Record salinity, sweetness and thickness.
2. If useful, lightly salt the fish for 10 minutes, then pat completely dry.
3. Mix 35g miso with 12g amazake. Add more amazake only until spreadable; add sugar only if genuinely needed.
4. Coat the fish lightly and refrigerate 6–12 hours.
5. Wipe off nearly all visible paste.
6. Pan-cook gently in lightly oiled non-stick over medium-low heat, presentation-side first. Cover briefly only if thickness requires it.
7. Stop when just opaque and gently flaking; the exterior should be golden, not blackened.

SUCCESS
Seasoned-through fish with clear sweet fermented depth, a moist interior and a clean golden exterior without a wet burnt-miso crust.

PROCESS RECORD
Stage: Planning
Human review: Marco — one portion; homemade miso and homemade amazake route
Research: Deferred until the miso and amazake are tasted
Verification: Not applicable until reconstructed

---

## PROCESS RECORD
{{MIGRATED_DISH_STATE_BLOCK}}
### Planning brief
Dish candidate: [Homemade miso] Saikyo-yaki-style fish — one-portion pan adaptation
Purpose: Learn how Marco's homemade white miso behaves in a sweet fish marinade without risking a three-portion batch.
Role: non-main — single-portion test; the source explicitly frames a one-portion pan adaptation
Priors: None
Locks: None
Exemptions: None
Research emphasis: None
Destination section: Fish — {{TARGET_SECTION_GID}}

### Decisions
None explicitly recorded as a Human — Marco decision in the legacy source.

### Research basis
No explicit legacy Research basis captured.

### Material changes
None explicitly recorded.
