[Dill] Gaeng om gai — pla-ra-forward chicken herb soup

A light Isan chicken herb soup using dill as the defining fresh herb, with pla ra deliberately pushed above the earlier baseline as the single calibration variable.

WHY COOK IT
Test whether approximately 25–28ml pla ra gives a clearer fermented backbone without overwhelming dill in a one-sitting chicken-breast adaptation.


## WHAT TO BUY
- Chicken breast: 200g
- Zucchini: 80–120g
- Fresh dill: 10g, only if not harvestable
- Scallion: 15–25g

## CHECK BEFORE COOKING
- Live Pantry state records dill as too young right now.
- Homemade khao khua, Mae Boonlam pla ra, frozen lemongrass, galangal and makrut leaves are in Pantry.

## QUANTITIES
Portions: 1 fresh sitting.
- Chicken breast: 200g, bite-size slices
- Shallot: 30–40g
- Garlic: 8–12g
- Lemongrass tender inner section: 8–12g
- Galangal: 4–6g
- Fresh chilli: 1/2–1
- Water or unsalted light chicken stock: 350–400ml
- Mae Boonlam pla ra: start with 20ml; increase toward 25–28ml after tasting
- Makrut lime leaf: 1
- Zucchini: 80–120g
- Khao khua: 3–6g [approx]
- Fresh dill: 10g
- Scallion: 15–25g

## HOW TO COOK IT
1. Pound shallot, garlic, lemongrass, galangal and chilli to a coarse paste.
2. Cook the paste briefly with a splash of liquid until its raw edge softens.
3. Add the remaining liquid, makrut leaf and 20ml pla ra; simmer 3–5 minutes.
4. Add chicken and poach gently. Add zucchini when the chicken is partly cooked.
5. When both are just done, taste and increase pla ra in small measured additions toward 25–28ml.
6. Turn off the heat. Stir in khao khua, then dill and scallion; steep for 30–60 seconds and serve.

## WHAT SUCCESS LOOKS LIKE
The broth stays light and water-based, not coconut-thickened. Dill remains defining; pla ra is unmistakable but does not bury it. Chicken stays tender, vegetables distinct and toasted rice a background nuttiness rather than gritty thickener.

Visual reference — https://www.seriouseats.com/gaeng-om-gai-isan-style-herbal-curry-5192883 — Observe the light broth, coarse paste, distinct vegetables and abundant dill folded in after cooking. Ignore chicken thigh, its larger vegetable set and its exact source ratios.

## WATCH OUT FOR
The controlling source uses chicken thigh and cooks its paste with the chicken before adding stock; this task's breast-poaching sequence is a deliberate lean-protein adaptation to avoid overcooking. It also omits the source's cilantro. Do not present either choice as the canonical method, precook and remove the chicken, or boil the dill.

## STORAGE
Eat immediately; the fresh-herb finish does not hold well.

---

## PROCESS RECORD
{{MIGRATED_DISH_STATE_BLOCK}}
### Planning brief
Dish candidate: [Dill] Gaeng om gai — pla-ra-forward chicken herb soup
Purpose: Test whether approximately 25–28ml pla ra gives a clearer fermented backbone without overwhelming dill in a one-sitting chicken-breast adaptation.
Role: main
Priors: None
Locks: Push pla ra toward approximately 25–28ml and remove the rau-răm branch.
Exemptions: None
Research emphasis: None
Destination section: Isan/Lao — {{TARGET_SECTION_GID}}

### Decisions
Human — Marco: Push pla ra toward approximately 25–28ml and remove the rau-răm branch.

### Research basis
Intentional calibration dish, human-approved.
Construction — Serious Eats, https://www.seriouseats.com/gaeng-om-gai-isan-style-herbal-curry-5192883 — for 450g thigh uses a coarse lemongrass-shallot-garlic-chilli paste, about 710ml stock, 45ml pla ra, 15ml fish sauce, 15g khao khua, 50g dill and 60g scallions; confirms the light non-coconut structure and off-heat herb/rice finish.
Scaling those defining quantities to 200g gives approximately 316ml stock, 20ml pla ra, 6.7g khao khua, 22g dill and 27g scallion. This task starts at the exact scaled pla-ra level and intentionally pushes it; the reduced dill amount is a practical small-batch choice and must be judged by aroma.
Later validation — Eating Thai Food, https://www.eatingthaifood.com/toasted-rice-powder-recipe/ — supports freshly toasted rice powder and coarse grinding.

### Material changes
2026-07-16 — Claude — Delta: restored khao khua to the executable recipe and reconciled the approved pla-ra start/target.
2026-07-16 — GPT — Verification correction: reopened the controlling source, corrected the adaptation disclosure and live dill blocker, and signed the contained Delta.
