Phở bò — Vietnamese beef noodle soup

Halal beef-bone broth with charred onion and ginger, restrained warm spices, pressure-cooked chuck, flat rice noodles, sprouts and fresh garnishes.

WHY COOK IT
Add a major Vietnamese beef-noodle-soup reference point after phở gà, testing halal beef bones, spice restraint, broth clarity and pressure-cooker execution.


## CHECK BEFORE COOKING
- Start mung-bean sprouts about 3 days ahead if home-growing.
- Use 1.35kg affordable mixed halal soup bones and 750g beef chuck.
- Do not exceed the Instant Pot max-fill line.
- Cook noodles and prepare garnishes fresh per bowl.
- This counts as the week’s red-meat dish.

## QUANTITIES
Portions: 3 substantial bowls.
- Mixed halal beef soup bones: 1.35kg
- Beef chuck: 750g, in 1–2 large pieces
- Onion: 1 medium, halved and charred
- Ginger: 40g, charred
- Star anise: 2
- Cloves: 2
- Fennel seed: 1/2 tsp
- Coriander seed: 1 tsp
- Black peppercorns: 8–10
- Cassia: 1 piece, 2–3cm
- Cao guo: 1/2 large pod, lightly cracked
- Water: only to the Instant Pot max-fill line
- Target final strained broth: 2.1L
- Yellow rock sugar: 10g
- Fine salt: start with 4g
- Fish sauce: start with 20–30ml

Per bowl:
- Dry bánh phở: 150g
- Broth: 700ml
- Cooked chuck: one-third
- Mung-bean sprouts: about 50g
- Scallion, chilli, lime juice and optional Thai basil

## HOW TO COOK IT
1. Parboil bones and chuck for 2–3 minutes; rinse them and the pot.
2. Char onion and ginger. Lightly toast spices.
3. Load solids and the spice sachet; add water only to max fill.
4. Pressure-cook on high for 45 minutes.
5. Natural release for 15–20 minutes, then vent gradually.
6. Remove chuck, rest and chill until sliceable.
7. Strain and measure the broth. Top up to 2.1L if short.
8. Add sugar, 4g salt and 20–30ml fish sauce; adjust gradually.
9. Cook noodles fresh and assemble each bowl.

## WHAT SUCCESS LOOKS LIKE
The broth is visibly clear amber, beef-forward and clean-tasting, with restrained spice. Chuck is tender but sliceable; cao guo supplies background depth without becoming separately dominant. Flat noodles and sliced beef remain distinct and fresh garnishes stay above the broth until service.

Visual reference — https://www.seriouseats.com/vietnamese-recipes-8681536 — Observe the Phở Saigon bowl for clear amber broth, separately legible noodles and beef, and fresh garnish assembly. Ignore its five beef cuts, southern garnish abundance and stovetop stock method; it does not validate this task’s pressure cycle, cao-guo dose or measured final volume.

## WATCH OUT FOR
Do not exceed max fill, season before measuring final broth volume, leave natural release open-ended, use a whole large cao-guo pod, batch-cook noodles or add lime to stored broth.

---

## PROCESS RECORD
{{MIGRATED_DISH_STATE_BLOCK}}
### Planning brief
Dish candidate: Phở bò — Vietnamese beef noodle soup
Purpose: Add a major Vietnamese beef-noodle-soup reference point after phở gà, testing halal beef bones, spice restraint, broth clarity and pressure-cooker execution.
Role: main
Priors: None
Locks: Corrected the incident record: he has reviewed this dish many times; an agent bug incorrectly auto-flagged it as rejected despite his real approval. Approved as-is: 1.35 kg mixed beef bones plus 750 g chuck, a 45-minute Instant Pot cycle, and a per-bowl scale of 700 ml broth plus 150 g noodles.
Exemptions: None
Research emphasis: None
Destination section: Vietnamese — {{TARGET_SECTION_GID}}

### Decisions
Human — Marco: Corrected the incident record: he has reviewed this dish many times; an agent bug incorrectly auto-flagged it as rejected despite his real approval. Approved as-is: 1.35 kg mixed beef bones plus 750 g chuck, a 45-minute Instant Pot cycle, and a per-bowl scale of 700 ml broth plus 150 g noodles.

### Research basis
Intentional test dish, human-approved.
Construction update — A direct pressure-cooker construction uses 907g beef bones, 454g brisket, 2.37L water, charred onion
and ginger, star anise, clove and cinnamon, then cooks under pressure for 50 minutes. It seasons only
afterward and uses 300g noodles for four bowls. This validates the shared bone/meat pressure cycle,
45–50-minute range, post-strain seasoning and fresh assembly.
Sources: <https://www.food.com/recipe/pressure-cooker-vietnamese-pho-bo-403391>

The task's 1.35kg bones and 750g chuck in a 2.1L final broth are intentionally more concentrated;
Marco has separately approved that load and the very large 700ml-broth/150g-noodle bowl. Cao guo is
a recognised phở spice variant, but half a large pod should remain a restrained calibration and be
removed if separately identifiable. Research is sufficient to execute the approved formula. The
main verification point is whether chuck remains sliceable after 45 minutes; chill before slicing
and record the result rather than blocking the cook for more paper research.

The task's 1.8:1 bones:meat ratio (1.35kg:750g) is confirmed as legitimate variation rather than an
error: credible sources range from about 1.33:1 (RecipeTin Eats) to 2:1 or higher (the cited Food.com
source at roughly 2:1, and Vicky Pham runs bonier still). 1.8:1 sits inside this real spread. No
change to the ratio itself.

### Material changes
None explicitly recorded.
