Tunisian powdered mloukhia with beef

Powdered jute leaf cooked slowly with oil, hot water, garlic, warm spices and beef until dark, glossy and thick enough to eat with bread. This is the Tunisian powdered preparation, not Egyptian or Levantine fresh-leaf molokhia soup.

WHY COOK IT
Learn the Maghreb oil-and-powder emulsion, very long simmer, darkening, bitterness control, beef integration and bread-coating texture.


## WHAT TO BUY
- Beef chuck or stewing beef: 750g
- Sturdy white bread, if needed

## CHECK BEFORE COOKING
- Mloukhia powder is already available.
- Use a large pot because the mixture can foam early.
- This counts as the week’s red-meat dish.
- Set aside a long, low-cook window.

## QUANTITIES
Portions: 4, or 3 very substantial portions.
- Mloukhia powder: 100g
- Olive oil: 100ml; hold up to 30ml extra only if the cold powder-oil paste will not disperse smoothly
- Hot water: begin with 1.5L; keep up to 500ml more available
- Beef: 750g, cut into 4–5cm pieces
- Tomato paste: 20g
- Garlic: 20g
- Ground coriander: 2 tsp
- Ground caraway: 1 tsp
- Harissa: 10–15g
- Bay leaves: 2
- Fine salt: begin with 8g and adjust late
- Black pepper: 1/2 tsp
- Dried mint: optional 1 tsp late

## HOW TO COOK IT
1. Off heat, whisk the powder into 100ml oil until smooth. Add held oil only if the paste is too dry to hydrate evenly.
2. Add hot water gradually while whisking.
3. Bring up slowly, then reduce to the gentlest reliable simmer.
4. Simmer for about 2 hours, stirring from the bottom periodically, until the raw-powder aroma softens and the sauce darkens.
5. Add beef, tomato paste, garlic, coriander, caraway, harissa and bay.
6. Simmer for another 2–3 hours, adding hot water only as needed, until the beef is tender and the sauce dark, glossy and bread-coating.
7. Salt near the end. Add dried mint only if tasting shows it helps.
8. Rest before serving when practical.

## WHAT SUCCESS LOOKS LIKE
The mixture transitions from green and viscous to very dark green-brown, glossy and bread-coating, with oil beginning to surface. There is no raw powder taste, lumping or scorched bitterness, and the beef is spoon-tender.

Visual sourcing gap — no retained free Tunisian powdered-mloukhia source clearly demonstrates the full darkening and oil-surfacing transition. Generic leaf-molokhia media and unlabeled regional images are too remote. Photograph the initial oil-powder paste, the two-hour stage and the final surface.

## WATCH OUT FOR
Do not confuse this with leaf molokhia, scorch the bottom, add all salt early or assume the initial water amount is final.

## STORAGE
Refrigerate up to 3 days. The dish should improve after resting; loosen carefully on reheating.

---

## PROCESS RECORD
{{MIGRATED_DISH_STATE_BLOCK}}
### Planning brief
Dish candidate: Tunisian powdered mloukhia with beef
Purpose: Learn the Maghreb oil-and-powder emulsion, very long simmer, darkening, bitterness control, beef integration and bread-coating texture.
Role: main
Priors: None
Locks: Lock the first mloukhia dish as the Tunisian powdered beef preparation.
Exemptions: None
Research emphasis: None
Destination section: Maghreb — {{TARGET_SECTION_GID}}

### Decisions
Human — Marco: Lock the first mloukhia dish as the Tunisian powdered beef preparation.

### Research basis
Source-backed dish.
Construction update — Both Tunisian sources agree on 100g mloukhia powder, 100ml oil, 750g beef, cold oil-powder dispersion, gradual boiling-water addition and a very long gentle cook to a dark glossy endpoint. Start at 100ml oil rather than the obsolete 150–180ml range. The two sources disagree on pre-beef powder simmer time before adding beef (~1h vs ~3h); this task uses 2h as an untested midpoint, to be adjusted after a first cook.
Sources: <https://ileauxepices.com/blog/2015/01/22/recette-molokheya-tunisienne/wpid7320/>, <https://www.tunisie.fr/recette-mloukhia-tunisienne-feuille-de-corete-en-poudre/>

Legacy agent construction/provenance (not Dish evidence):
Agent — Codex: Reconciled the construction update with the recorded Human Review result and removed stale pending/rejected branches from the process record.
Agent — Claude: Verification found both sources actually state 750g flat, not a "700–750g range" as previously written; corrected beef to 750g. The two sources also disagree on the pre-beef powder simmer time (~1h vs ~3h); this task's 2h is a disclosed midpoint pending a cook to calibrate, not an error.

### Material changes
None explicitly recorded.
