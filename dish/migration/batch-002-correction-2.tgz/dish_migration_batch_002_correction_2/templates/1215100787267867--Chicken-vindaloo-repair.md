Chicken vindaloo repair
Chicken vindaloo repair — wet vinegar-spice paste correction

Bone-in chicken cooked in a loose vinegar, chilli, garlic and whole-spice paste. Acid is structural and the paste must move in oil rather than crust onto the meat.

WHY COOK IT
Correct the failed dry-rub direction and establish vindaloo as a wet acid-led braise.


## QUANTITIES
- Bone-in chicken thighs: 600g
- Dry rice: 400g total
- Dried red chilli: 12g, soaked
- Apple-cider vinegar: 80ml
- Garlic: 20g
- Ginger: 10g
- Cumin: 2 tsp
- Coriander: 1 tsp
- Black pepper: 1 tsp
- Brown mustard seed: 1 tsp
- Cloves: 4
- Cassia: 2cm
- Turmeric: 1/2 tsp
- White sugar: 6g
- Fine salt: begin with 7g
- Neutral oil: 35ml
- Water: 120–180ml as needed

## HOW TO COOK IT
1. Grind chilli, vinegar, garlic, ginger and spices into a wet loose paste, adding water if it behaves like dry rub.
2. Coat chicken and rest 30–60 minutes.
3. Cook chicken and paste together over medium heat so the paste loosens and fries without crusting.
4. Add sugar, salt and 120ml water; cover and simmer until nearly tender.
5. Uncover and reduce until sauce clings but remains visibly sauced.
6. Taste for vinegar structure before further adjustment.

## WHAT SUCCESS LOOKS LIKE
Raw paste is smooth, visibly wet and spreadable rather than crumbly. Finished chicken is surrounded by a cohesive red sauce that still moves from a spoon; there is no dry spice crust, scorched paste or bare oily chicken.

Visual reference — https://www.indianhealthyrecipes.com/chicken-vindaloo/ — Observe chillies soaked with vinegar and ground to smooth wet paste, chicken coated in it and a visibly sauced final curry. Ignore onion, tomato, boneless chicken, exact paste thickness and water ratio.

## WATCH OUT FOR
Do not fry a dry paste at high heat, add excessive liquid or let chilli obscure the vinegar structure.

---

## PROCESS RECORD
{{MIGRATED_DISH_STATE_BLOCK}}
### Planning brief
Dish candidate: Chicken vindaloo repair
Purpose: Correct the failed dry-rub direction and establish vindaloo as a wet acid-led braise.
Role: main
Priors: Legacy source claims: Intentional correction repeat of source-backed chicken vindaloo. Construction — Cooking History task "DONE — Chicken vindaloo failure / acid-led rerun needed," 1215099973504762 — supplied the 600g bone-in-chicken scale, dry-paste failure, need for a loose wet vinegar paste, lower starting heat, apple-cider-vinegar choice and roughly four-to-five-clove garlic target. Verified directly during this pass. Technical premise: directly supported as a correction. The onion-free, tomato-free formula is a project repair built around the prior failure rather than a claim that the external source uses the same structure.
Locks: None
Exemptions: None
Research emphasis: Whether the wet-paste correction fixes the failure and lands the preferred vinegar intensity.
Destination section: Subcontinent — {{TARGET_SECTION_GID}}

### Decisions
None explicitly recorded as a Human — Marco decision in the legacy source.

### Research basis
Intentional correction repeat of source-backed chicken vindaloo.
Construction — Cooking History task "DONE — Chicken vindaloo failure / acid-led rerun needed," 1215099973504762 — supplied the 600g bone-in-chicken scale, dry-paste failure, need for a loose wet vinegar paste, lower starting heat, apple-cider-vinegar choice and roughly four-to-five-clove garlic target. Verified directly during this pass.
Construction — Swasthi Shreekanth/Indian Healthy Recipes, chicken vindaloo: https://www.indianhealthyrecipes.com/chicken-vindaloo/ — supplied vinegar-soaked chillies, garlic and spices ground to a wet paste and a sauced final dish. Verified directly against full page text.
Later validation — the same Swasthi page, re-inspected during the visual audit and again during verification — checked wet-paste and visibly sauced boundaries only.
Technical premise: directly supported as a correction. The onion-free, tomato-free formula is a project repair built around the prior failure rather than a claim that the external source uses the same structure.

Legacy agent construction/provenance (not Dish evidence):
Agent — Codex: Kept this as a wet vinegar-spice-paste correction rather than a generic curry repeat.
Agent — GPT-5.6 Thinking: Recovered the exact prior failure and corrected the unsupported "Marco, complete" field to Not required.
Agent — Claude: Verified directly against Cooking History 1215099973504762 and the Indian Healthy Recipes source. Cooking History matches precisely (600g bone-in thigh, apple cider vinegar, ~4-5 cloves garlic, wet loose paste, lower heat, dry rice for 3 portions). Source confirms wet-paste structure; the task's exclusion of the source's onion/tomato is correctly and explicitly flagged, and matches Marco's own recorded preference. No findings, no changes made.

### Material changes
None explicitly recorded.
