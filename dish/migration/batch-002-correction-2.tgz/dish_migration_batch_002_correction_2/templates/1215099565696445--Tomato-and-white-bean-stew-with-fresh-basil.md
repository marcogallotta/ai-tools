Tomato and white-bean stew with fresh basil

A simple tomato and white-bean stew finished with fresh Genovese basil after reheating.

WHY COOK IT
Use good basil in a straightforward bean dish where its fresh aroma remains clear.


## QUANTITIES
Portions: 3.
- Cooked white beans: 600g drained
- Tomato or passata: 500g
- Onion: 150g
- Garlic: 8g
- Olive oil: 30ml
- Water or bean liquor: about 200ml
- Fresh Genovese basil: about 7–10g per serving
- Fine salt and black pepper
- Lemon juice: optional, only after tasting

## HOW TO COOK IT
1. Soften onion in olive oil; add garlic briefly.
2. Add tomato and cook until cohesive.
3. Add beans and enough liquid for a thick stew. Simmer 15–20 minutes.
4. Divide the batchable base into three portions.
5. Reheat one portion gently for each sitting. Turn off the heat and fold in 7–10g torn fresh basil immediately before serving.
6. Taste before adding optional lemon.

## WHAT SUCCESS LOOKS LIKE
The stew is cohesive and tomato-rich, with beans partly intact in a creamy body. Fresh basil remains green and aromatic.

## WATCH OUT FOR
Do not add the basil to the stored batch, bruise it far ahead or add lemon automatically.

## STORAGE
Refrigerate or freeze the bean-and-tomato base without basil. Add fresh basil only at service.

---

## PROCESS RECORD
{{MIGRATED_DISH_STATE_BLOCK}}
### Planning brief
Dish candidate: Tomato and white-bean stew with fresh basil
Purpose: Use good basil in a straightforward bean dish where its fresh aroma remains clear.
Role: main
Priors: None
Locks: Remove the agent-created cooked-versus-fresh basil experiment. Keep a normal tomato-and-white-bean stew finished only with fresh basil.
Exemptions: None
Research emphasis: None
Destination section: Verification Queue — {{TARGET_SECTION_GID}}

### Decisions
Human — Marco: Remove the agent-created cooked-versus-fresh basil experiment. Keep a normal tomato-and-white-bean stew finished only with fresh basil.

### Research basis
Source-backed tomato, white-bean and late-basil combination. No claim is made for a controlled basil-timing experiment.

### Material changes
None explicitly recorded.
