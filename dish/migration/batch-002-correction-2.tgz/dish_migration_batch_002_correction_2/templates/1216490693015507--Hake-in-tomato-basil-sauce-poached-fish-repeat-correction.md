Hake in tomato-basil sauce — poached-fish repeat and correction

A quick tomato-basil poach for a single thin hake fillet, served with pasta pomodoro if wanted. This is a calibration repeat, not a new dish.

WHY COOK IT
The first cook was slightly too salty and likely slightly overcooked. This repeat tests the direct correction from the Cooking History record: season the sauce only, keep the tomato at a bare tremble and shorten the fish cook.


## WHAT TO BUY
- Hake fillet, thin, about 100g, fresh

## CHECK BEFORE COOKING
- Genovese basil: harvest check. If unavailable, buy a small bunch or postpone; this dish is partly a basil-in-white-fish calibration.
- Passata: check actual amount before starting.

## QUANTITIES
Portions: one sitting, matching the first cook’s scale.
- Hake fillet: 100g, thin
- Passata: 120–150g, loosened with 15–30ml water if thick
- Fresh basil: small handful, added off heat
- Fine salt: season the sauce lightly only; do not pre-salt the fish separately
- Optional side: dry pasta for pasta pomodoro, cooked separately

## HOW TO COOK IT
1. Warm passata gently in a small pan; loosen with water if needed. Season lightly and taste.
2. Add the fish. Sauce should come partway up the fillet, not fully drown it.
3. Cover and cook at a bare tremble, not an active simmer, for 3–4 minutes for a thin 100g fillet.
4. Remove from heat and rest covered for 2 minutes.
5. Off heat, tuck basil under and around the fish, not only on top.

## WHAT SUCCESS LOOKS LIKE
Fish is just cooked through, moist and not falling apart. Sauce is properly seasoned without separate fish salting, and basil reads as fresh tomato-basil aroma rather than garnish.

## WATCH OUT FOR
Tomato transfers heat aggressively. Bubbling sauce or double-salting is the known failure mode from the first cook.

---

## PROCESS RECORD
{{MIGRATED_DISH_STATE_BLOCK}}
### Planning brief
Dish candidate: Hake in tomato-basil sauce — poached-fish repeat/correction
Purpose: The first cook was slightly too salty and likely slightly overcooked. This repeat tests the direct correction from the Cooking History record: season the sauce only, keep the tomato at a bare tremble and shorten the fish cook.
Role: main
Priors: Legacy source claims: Construction — Cooking History task “Hake in tomato-basil sauce,” 1215099676766456, prior cook record — supplied the one-fillet scale, 120–150g passata, sauce-only salting, 3–4-minute bare-tremble cook, 2-minute off-heat rest and basil placement correction. Technical premise: directly supported by the prior cook’s post-cook diagnosis. This is a controlled correction of an observed salt and doneness failure, not a claim that the method is canonical Italian practice.
Locks: None
Exemptions: None
Research emphasis: Whether the corrected heat and salt fix the dish, and whether pasta pomodoro should remain the default pairing.
Destination section: Planned — {{TARGET_SECTION_GID}}

### Decisions
None explicitly recorded as a Human — Marco decision in the legacy source.

### Research basis
Intentional test dish — no traditional or source-backed identity claimed.
Construction — Cooking History task “Hake in tomato-basil sauce,” 1215099676766456, prior cook record — supplied the one-fillet scale, 120–150g passata, sauce-only salting, 3–4-minute bare-tremble cook, 2-minute off-heat rest and basil placement correction.
Technical premise: directly supported by the prior cook’s post-cook diagnosis. This is a controlled correction of an observed salt and doneness failure, not a claim that the method is canonical Italian practice.

Legacy agent construction/provenance (not Dish evidence):
Agent — Codex: Kept this as a one-sitting repeat because the prior failure was a narrow technique calibration and scaling would add noise.
Agent — GPT-5.6 Thinking: Reopened the prior-cook record, confirmed that the quantities and corrections are copied from its recorded diagnosis, and rewrote the research basis to distinguish construction evidence from general corroboration.

### Material changes
None explicitly recorded.
