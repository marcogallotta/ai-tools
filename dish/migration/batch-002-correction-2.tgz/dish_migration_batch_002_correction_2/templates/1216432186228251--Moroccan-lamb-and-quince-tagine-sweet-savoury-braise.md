Moroccan lamb-and-quince tagine — sweet-savoury braise

Lamb shoulder pressure-braised with onion, ginger, turmeric, coriander and cinnamon, then finished with quince cooked separately in butter, honey and lemon so the fruit remains aromatic and intact.

WHY COOK IT
Target fresh quince at peak season and learn a Moroccan sweet-savoury meat-and-fruit structure in which tart, tannic, perfumed quince can stand up to lamb.


## WHAT TO BUY
- Lamb shoulder: 1kg, bone-in or boneless, cut into 3–4cm chunks
- Quince: 2 medium, about 600–700g raw
- Lemon: 1 if absent

## CHECK BEFORE COOKING
- This counts as the week’s red-meat dish.
- Pressure cooking retains liquid; do not copy a stovetop-braise volume.
- Do not pressure-cook the quince with the lamb.
- If using bone-in shoulder, record the bone weight where practical.

## QUANTITIES
Portions: 3. Batchable braise core - fine to cook once for three sittings; quince finish holds acceptably per the task's STORAGE section.

Lamb:
- Lamb shoulder: 1kg
- Onion: 225g
- Garlic: 10–15g
- Neutral oil: 20ml, plus only what browning needs
- Turmeric: 1 tsp
- Fresh ginger: 1 tsp, finely grated
- Coriander seed: 1 tsp, toasted and ground
- Ceylon cinnamon: 1 stick
- Fine salt: begin with 7g, then adjust
- Water or unsalted stock: 175ml; use 150ml only if onions are very juicy and up to 200ml only if scorching risk requires it

Quince:
- Quince: 600–700g raw, peeled, cored and cut into thick wedges
- Butter: 30g
- Honey: 15ml
- Ground Ceylon cinnamon: 1 tsp
- Lemon juice: 20–25ml
- Thin lemon slices: a few, with minimal pith
- Water: 30ml initially

Estimated [approx]: 1kg lamb shoulder / 3 (cooked yield ~70%) gives roughly 683 kcal / 57g protein per portion from lamb alone; quince/butter/honey adds roughly 210 kcal; onion/oil aromatics add roughly 110 kcal. Total before accompaniment: approximately 1000 kcal / ~58g protein per portion - already at or above the ~800kcal/50g target; flatbread/couscous is a genuine surplus, consistent with CLAUDE.md's athlete/adequate-carbs stance.

## HOW TO COOK IT
1. Brown lamb in uncrowded batches and remove.
2. Soften onion, then add garlic, turmeric, ginger, coriander and cinnamon until fragrant.
3. Deglaze with the measured liquid, scrape the base clean and return lamb.
4. Pressure-cook on high for 35 minutes, then allow 15 minutes natural release. If still resistant, cook another 5–10 minutes.
5. Meanwhile, melt butter in a wide pan, coat the quince, then add honey, cinnamon, lemon and 30ml water. Cover briefly to begin softening, then uncover and turn carefully until glossy, browned at the edges and tender while holding shape.
6. Remove the cinnamon stick. Reduce the lamb sauce uncovered if needed and season fully on the savoury side.
7. Fold in the quince and only enough of its pan liquid to integrate the sweet-sour note. Do not boil hard after combining.
8. Serve with warm flatbread or ~100g cooked couscous (~55g dry) per portion.

## WHAT SUCCESS LOOKS LIKE
Lamb yields easily in a concentrated savoury sauce. Quince wedges are fragrant, glossy, browned at the edges and intact rather than dissolved; honey rounds tartness without making the dish dessert-like.

Visual reference — https://www.theguardian.com/food/2022/oct/17/fragrant-lamb-and-quince-tagine-thomasina-miers-recipe — Observe separately browned quince retaining wedge shape beside tender lamb in a concentrated but spoonable sauce. Ignore lamb neck, tomatoes, chickpeas, carrots and ras el hanout; the image does not validate this task’s pressure-cooker shoulder formula.

## WATCH OUT FOR
Do not use a generic ras el hanout, copy stovetop liquid into the Instant Pot, overcook the quince or reduce the honey until sticky or bitter.

## STORAGE
Store lamb and quince separately when practical. Refrigerate up to 3 days; freeze lamb and sauce if needed, but refrigerate rather than freeze the quince.

---

## PROCESS RECORD
{{MIGRATED_DISH_STATE_BLOCK}}
### Planning brief
Dish candidate: Moroccan lamb-and-quince tagine — sweet-savoury braise
Purpose: Target fresh quince at peak season and learn a Moroccan sweet-savoury meat-and-fruit structure in which tart, tannic, perfumed quince can stand up to lamb.
Role: main
Priors: None
Locks: Use lamb shoulder rather than beef and keep quince as the balancing fruit. | Keep this task despite the general warning against reactive fruit tagines because quince has independent October seasonality and lamb-balance value.
Exemptions: None
Research emphasis: Practical only: quince must be in season and lamb approved for the week's red-meat slot.
Destination section: Verification Queue — {{TARGET_SECTION_GID}}

### Decisions
Human — Marco: Use lamb shoulder rather than beef and keep quince as the balancing fruit.
Human — Marco: Keep this task despite the general warning against reactive fruit tagines because quince has independent October seasonality and lamb-balance value.

### Research basis
Source-backed dish.
Construction update — Direct recipes support shoulder, onion, ginger/cinnamon/saffron-style seasoning, separately browned
quince and a late fruit phase. Brown onion/lamb, bloom spices, pressure-cook with minimal liquid,
then add separately browned quince for an uncovered finish. A documented ratio is about 650g quince
per 1kg lamb. Do not pressure-cook quince with the meat. Research is sufficient.
Sources: <https://www.abc.net.au/news/2009-05-15/moroccan-lamb-tagine-with-quince/8916416>,
<https://www.theguardian.com/food/2022/oct/17/fragrant-lamb-and-quince-tagine-thomasina-miers-recipe>

Legacy agent construction/provenance (not Dish evidence):
Agent — Codex: Reconciled the construction update with the recorded Human Review result and removed stale pending/rejected branches from the process record.

### Material changes
None explicitly recorded.
