[whole chicken 1.8–2kg] Dong’an chicken — Hunan vinegar-and-ginger chicken
A sour-hot Hunan chicken dish led by clear rice vinegar and fine-shredded ginger, with fresh and dried chilli and peppercorn as supporting heat. A poached skin-on half-bird is cut into bone-in pieces and finished in a light, starch-glossed sauce.

WHY COOK IT
Learn Hunan sour-hot flavour as distinct from Sichuan mala and fermented duòjiāo dishes.


## WHAT TO BUY
- Whole chicken: 1.8–2kg dressed weight
- Fresh red chilli: 1, about 15g
- Scallions: 3
- Ginger: only enough to bring live stock to 40g

## CHECK BEFORE COOKING
- Split the raw bird bilaterally through the breastbone. Use one half—one breast, one leg quarter and one wing, skin-on and bone-in—and freeze the untouched raw half promptly.
- The working half should weigh 900–1000g. If it falls outside that range, postpone and rescale deliberately rather than improvising.
- Confirm at least 25ml clear rice vinegar, 4g dried chilli, 1g red Sichuan peppercorn, 10ml light soy, cornstarch and sesame oil from live stock.
- Use a probe. The poach intentionally leaves the chicken only about three-quarters cooked; the final simmer must bring the thickest breast and leg meat to at least 74°C before serving.

## QUANTITIES
Portions: 3.
- Chicken half: 900–1000g raw, skin-on and bone-in
- Ginger: 40g, divided—20g bruised for poaching and 20g fine julienne
- Fresh red chilli: about 15g, deseeded if required and cut into fine slivers
- Dried red chillies: about 4g, cut into short sections
- Red Sichuan peppercorn: 1g, lightly crushed
- Scallions: 3, one bruised for poaching and two cut into 4cm slivers
- Garlic: 8g, sliced
- Clear rice vinegar: 25ml, added during cooking
- Light soy sauce: 10ml
- White sugar: 5g
- Reserved poaching liquid: 100ml total, measured as 15ml plus 85ml
- Neutral oil: 40ml
- Cornstarch slurry: 4g cornstarch plus 12ml cold water
- Toasted sesame oil: 4ml, off heat

## HOW TO COOK IT
1. Bring enough water to cover the chicken half to a boil with the bruised ginger and one bruised scallion. Add the chicken, return to a boil, skim, then lower to a gentle poach. Begin checking at 10 minutes and remove when the half is about three-quarters cooked, not when safe to eat; reserve the poaching liquid.
2. Cool only until safe to handle. Separate at the joints and cleave the breast and rib sections into bite-size bone-in pieces with decisive cuts. Remove loose bone fragments while keeping the skin attached.
3. Heat the oil in the wok. Fry peppercorn and dried chilli briefly, then add fresh chilli, garlic and ginger julienne. Keep the ginger fragrant and pale rather than browned or dry.
4. Splash 15ml poaching liquid around the wok edge. This replaces the source recipes’ Shaoxing-wine entry point only as moisture; it does not replace the lost fermented aroma.
5. Add chicken, soy, sugar and all 25ml vinegar. Add the remaining 85ml poaching liquid, bring to a brisk simmer and cook 4–6 minutes, turning the pieces, until the thickest breast and leg meat reaches at least 74°C.
6. Stir the slurry again and add only enough to give the liquid a light glossy body. Fold in scallion slivers.
7. Remove from heat and stir in sesame oil. Serve immediately.

## WHAT SUCCESS LOOKS LIKE
Clear vinegar leads and ginger is unmistakable. Skin remains attached to moist chicken; the fresh and dried chilli stays secondary. The sauce forms a thin glossy film and a small amount of free seasoned liquid rather than a thick glaze.

Visual reference — https://www.seriouseats.com/introduction-hunan-chinese-cuisine — Observe only the Dong’an chicken image’s thin chicken pieces, abundant ginger and chilli, and lightly brothy gloss. Ignore its unrecorded quantities and restaurant execution.

## WATCH OUT FOR
Do not treat the partial poach as a safe endpoint, rely on clear juices instead of a probe, leave loose bone splinters, brown the ginger hard, use dark vinegar, or add a second off-heat vinegar dose. The published constructions add the vinegar during cooking.

## STORAGE
Refrigerate promptly for up to 3 days. Reheat gently to 74°C; add only a few fresh drops of rice vinegar after tasting if reheating has dulled the acid.

---

## PROCESS RECORD
{{MIGRATED_DISH_STATE_BLOCK}}
### Planning brief
Dish candidate: Dong’an chicken — Hunan vinegar-and-ginger chicken
Purpose: Learn Hunan sour-hot flavour as distinct from Sichuan mala and fermented duòjiāo dishes.
Role: main
Priors: None
Locks: Use one bone-in half from a whole chicken around 1.8–2kg rather than the previous deboned-thigh plan; freeze the untouched raw half for another dish.
Exemptions: None
Research emphasis: None
Destination section: Hunan — {{TARGET_SECTION_GID}}

### Decisions
Human — Marco: Use one bone-in half from a whole chicken around 1.8–2kg rather than the previous deboned-thigh plan; freeze the untouched raw half for another dish.

### Research basis
Source-backed Dong’an chicken with a human-approved bone-in final-piece adaptation.

Construction — What To Cook Today, “Dong’an Chicken,” https://whattocooktoday.com/dongan-chicken.html — attributes its formula to Fuchsia Dunlop’s Revolutionary Chinese Cookbook. For 1247g chicken it uses 30ml clear rice vinegar, 60ml oil, 3/4 tsp starch, up to 120ml stock, split ginger, fresh and dried chilli, peppercorn and sesame oil. It poaches for 10 minutes to about three-quarters cooked, debones, adds all vinegar during the wok phase and thickens lightly.

Construction — China Sichuan Food, “Chinese Hunan Chicken – Donan Chicken,” https://www.chinasichuanfood.com/chinese-hunan-chicken-donan-chicken/ — for 300g chicken uses 5ml vinegar, 10ml soy, about 2g sugar, garlic, 240ml stock and a starch finish. It independently supports the soy-sugar-garlic branch, an approximately 80%-cooked poach and final simmer.

Construction — Clovegarden, “Dong’an Chicken,” https://www.clovegarden.com/recipes/cmc_chkvin1.html — for 1588g chicken uses 45ml clear rice vinegar, 45ml oil, 120ml stock, starch and sesame oil; it poaches to about three-quarters cooked and adds the vinegar in the cooking liquid before thickening.

Vinegar normalization: the three direct formulas provide approximately 16.7ml/kg, 24.1ml/kg and 28.3ml/kg. This task’s 25ml for a 900–1000g half equals 25–27.8ml/kg and sits inside the reconciled range. The prior 40ml equalled 40–44ml/kg and was unsupported. The source recipes debone before the wok; retaining bone-in pieces is Marco’s approved adaptation and adds cleaving and final-temperature risks that are now explicit.

Alcohol adaptation — all three constructions use cooking wine. It is omitted under the halal rule. A 15ml stock splash preserves moisture at that entry point but not fermented aroma.

Later validation — USDA FSIS safe-temperature guidance, https://www.fsis.usda.gov/food-safety/safe-food-handling-and-preparation/food-safety-basics/safe-temperature-chart — supports 74°C/165°F for all poultry as the final safety endpoint, not as a replacement for the sources’ partial-poach texture target.

### Material changes
2026-07-17 — GPT — Delta. Corrected the false Clovegarden vinegar normalization and reduced vinegar from 40ml to 25ml; removed the unsupported mandatory off-heat vinegar stage; reduced ginger from 60g to 40g; restored the fresh-chilli component; added partial-poach versus final-safe-temperature gates, bone-fragment control, actual shopping/readiness and the alcohol-loss disclosure. Reopened all directly affected sources and verified the contained Delta.
2026-07-17 — Claude — Local. GPT's above signoff was an invalid same-family self-verification (a Delta requires the opposite family). Reopened all three construction sources (What To Cook Today, China Sichuan Food, Clovegarden) against raw HTML: vinegar normalization (24.1/16.7/28.3 ml/kg), poaching doneness, vinegar-added-during-cooking, and the wine-omitted-for-halal claim all confirmed accurate. No content change.
