Miso soup — homemade miso comparison block
Miso soup — homemade miso comparison block

A focused Japanese soup block using the vegetable-heavy miso-less base already on hand as a controlled vehicle for comparing homemade misos: two differently aged white misos, young red miso and small white/red blends.

WHY COOK IT
Learn the actual behaviour of the homemade misos in soup: sweetness, salt, aroma, body, ageing difference, red-versus-white balance and dose per portion. This is not basic miso-soup literacy; the purpose is turning the homemade ferments into a reliable cooking building block.


## CHECK BEFORE COOKING
- Existing base: about 3 portions of vegetable-heavy miso-less soup with some tofu.
- Homemade misos: two differently aged white misos, young red miso and small white/red batches if useful.
- Do not add amazake, shoyu koji or shio koji casually; each is a separate variable.
- Do not hard-boil after miso is added.

## QUANTITIES
Per test portion:
- Miso-less soup base: 250–300ml
- Homemade white miso: start with 15g, then 20g, then 25g if needed
- Homemade red miso: start with 10g, then 15g, then 20g if needed
- Mixed test: start with 15g white plus 5g red per 250–300ml
- Optional amazake: 5–10ml only in a later test if roundness and body are missing
- Optional shoyu koji: 3–5ml only in a later test if salt or soy depth is missing

## HOW TO COOK IT
1. Heat one portion of the miso-less base gently until hot.
2. Pull a small ladle of liquid into a bowl and dissolve the miso fully before returning it to the pot or serving bowl.
3. Keep the soup below a hard boil after adding miso.
4. Taste immediately, then again after 2 minutes.
5. Record the miso, grams per portion, salt, sweetness, body, aroma and whether the vegetable-heavy base masks or exposes differences.
6. Repeat with only one variable changed: white-miso age, red-miso dose or white/red blend.

## WHAT SUCCESS LOOKS LIKE
The miso is evenly dispersed into the broth with no undissolved lumps or hard-boil separation, while tofu and vegetables remain intact. The broth may be lightly cloudy, especially with coarser homemade miso, though the cited source's own broth is clear rather than cloudy — treat cloudiness as a homemade-miso variable to observe, not a confirmed boundary. The soup tastes integrated rather than like vegetable soup with miso stirred in; differences between the homemade misos are clear enough to repeat.

Visual reference — https://www.justonecookbook.com/homemade-miso-soup/ — Observe miso dissolved separately into hot broth and a finished soup with intact tofu and wakame. Ignore the source's dashi, miso brand and topping formula; this task deliberately uses an existing vegetable-heavy base.

## WATCH OUT FOR
Do not compare several additions at once. Amazake changes body, roundness, aroma, dilution, perceived salt and sweetness together; shoyu koji and shio koji are separate variables.

---

## PROCESS RECORD
{{MIGRATED_DISH_STATE_BLOCK}}
### Planning brief
Dish candidate: Miso soup — homemade miso comparison block
Purpose: Learn the actual behaviour of the homemade misos in soup: sweetness, salt, aroma, body, ageing difference, red-versus-white balance and dose per portion. This is not basic miso-soup literacy; the purpose is turning the homemade ferments into a reliable cooking building block.
Role: non-main — comparison block; the task isolates homemade-miso performance
Priors: None
Locks: Use the existing three portions of vegetable-heavy miso-less soup with tofu to compare the homemade misos. | The available comparison set is two differently aged white misos, young red miso and small white/red batches; amazake, shoyu koji, shio koji and bare koji rice are also available but are not baseline additions.
Exemptions: None
Research emphasis: Which homemade miso or blend works best in the existing base.
Destination section: Japanese — {{TARGET_SECTION_GID}}

### Decisions
Human — Marco: Use the existing three portions of vegetable-heavy miso-less soup with tofu to compare the homemade misos.
Human — Marco: The available comparison set is two differently aged white misos, young red miso and small white/red batches; amazake, shoyu koji, shio koji and bare koji rice are also available but are not baseline additions.

### Research basis
Intentional test dish — no traditional or source-backed identity claimed for the existing vegetable-base comparison.
Construction — culinary-experience.md, Japanese confirmed learnings — established that dashi, miso and shio-koji are already functional skills, so this task should test the homemade misos rather than teach basic soup. Verified directly during this pass.
Construction — culinary-planning.md, Japanese active track — established the miso-strength test and that amazake changes body, roundness, aroma, dilution, perceived salt and sweetness together. Verified directly during this pass — matches verbatim.
Construction — Just One Cookbook, "Homemade Miso Soup": https://www.justonecookbook.com/homemade-miso-soup/ — informed dissolving miso into hot broth and the broad dashi/miso/tofu structure. Verified directly against full page text.
Construction — Just One Cookbook, "Easy Miso Soup": https://www.justonecookbook.com/10-minute-meal-easy-miso-soup/ — informed the no-hard-boil rule after miso and late tofu/wakame handling.
Construction — Japanese Cooking 101, "Miso Soup": https://japanesecooking101.com/miso-soup-recipe/ — corroborated low-heat miso dissolution and the simple dashi/tofu/scallion structure.
Construction — Just Hungry, "Japanese Cooking 101 Lesson 1a": https://justhungry.com/handbook/cooking-courses/japanese-cooking-101-lesson-1a-making-miso-soup-clear-soup — supplied the rough one-tablespoon-per-250ml orientation and the instruction to start low because misos differ.
Construction — Just One Cookbook, "Types of Miso": https://www.justonecookbook.com/miso/ — informed the broad white-versus-red expectations used to design the dose ladders.
Later validation — Just One Cookbook, "Homemade Miso Soup," re-inspected 2026-07-14 and again during verification — checked separate dissolution, soft cloudiness claim (now softened) and intact tofu/wakame only; its stock and toppings were not transferred.
Technical premise: directly supported as a controlled comparison. Holding the existing base and method constant while changing only miso identity or dose makes salt, sweetness, aroma and body differences interpretable.

Legacy agent construction/provenance (not Dish evidence):
Agent — Codex: Structured this as a controlled homemade-miso comparison and kept multi-variable ferment additions out of the baseline.
Agent — GPT-5.6 Thinking: Rebuilt the source record under the current construction-versus-validation format.
Agent — Claude: Softened the "softly cloudy broth" claim — the cited Just One Cookbook source describes the finished broth as clear rather than cloudy (aside from possible koji particles depending on miso type); homemade unfiltered miso may behave differently, but this isn't source-confirmed, so the wording now reflects that as an open observation rather than an asserted boundary.

### Material changes
None explicitly recorded.
