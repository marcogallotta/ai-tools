[7-day cure] Smoked cured beef with chillies and douchi — halal Hunan-style adaptation
Fatty beef is refrigerated in a measured salt cure, dried, briefly tea-smoked for flavour, fully steamed, chilled and sliced thinly for a dry chilli-and-douchi stir-fry. It is not shelf-stable larou and must never be represented as equivalent.

WHY COOK IT
Test whether beef fat can carry the cured, smoky and fermented flavours of Hunan preserved-meat dishes within a safe halal home process.


## WHAT TO BUY
- Beef plate or navel: 900g in one fatty boneless slab, approximately 3cm thick; fatty boneless short rib is the fallback
- Fresh chillies: 250g
- Leek or garlic shoots: 120g
- Garlic: 15g

## CHECK BEFORE COOKING
- Buy a slab close to 3cm at its thickest flat cross-section. Do not accept a materially thicker piece without recalculating the cure schedule.
- Cure for 7 complete days at 2–4°C. This is the conservative route Marco approved after the source conflict was reopened.
- Use a non-vacuum zip-lock bag or covered non-reactive container for this salt-only cure, turning daily. Do not vacuum-pack without a correctly calculated nitrite cure.
- Confirm live douchi stock of at least 20g.
- After drying, the smoking and steaming stages are one uninterrupted cook: move the beef directly from the smoker to the steamer.
- Use strong ventilation, a stable lidded steel wok or pot, a rack that keeps meat above the smoke mixture and a probe thermometer.
- This counts as the week’s red-meat dish, counted in the week it is eaten.

## QUANTITIES
Portions: 3.

Cure:
- Beef plate, navel or fatty boneless short rib: 900g, approximately 3cm thick
- Fine salt: 22.5g, exactly 2.5% of meat weight
- White sugar: 5g
- Red Sichuan peppercorn: 1g, toasted and ground
- Five-spice powder: 1g

Smoke:
- Black tea: 20g
- Uncooked rice: 40g
- White or brown sugar: 20g

Stir-fry:
- Cooked smoked beef: complete measured yield, expected roughly 600–700g
- Fresh chillies: 250g, sliced
- Leek or garlic shoots: 120g, sliced
- Garlic: 15g, coarsely crushed
- Douchi: 20g, rinsed briefly and chopped
- Neutral oil: 15ml
- Light soy sauce: up to 10ml only after tasting

## HOW TO COOK IT
1. Weigh the prepared beef and measure the full thickest cross-section. Proceed only if it is approximately 3cm; otherwise stop and recalculate rather than improvising.
2. Mix salt, sugar, peppercorn and five-spice. Rub over every surface, enclose in the non-vacuum refrigerated container and cure for 7 complete days, turning daily.
3. At the end of the cure, check that colour and texture are reasonably uniform through a small central inspection cut before proceeding. If the centre is plainly unlike the outer meat, stop rather than assuming completion.
4. Rinse very briefly, pat completely dry and refrigerate uncovered on a rack for 24 hours to form a dry, slightly tacky surface.
5. Line a stable steel wok or pot with foil, add tea, rice and sugar, fit the rack and cover tightly. Heat until the mixture begins producing smoke, place the beef on the rack, reduce the heat and smoke for 8–10 minutes with strong ventilation. Do not leave it unattended.
6. Transfer immediately to a prepared steamer. Steam until the centre reaches at least 63°C and remains there through a 3-minute rest; 68–70°C is the working texture target for firmer slicing. Cool rapidly, then refrigerate until thoroughly firm.
7. Weigh the cooked slab and slice very thinly across the grain, keeping attached fat with the lean.
8. Heat the wok, add beef in uncrowded batches and render until edges brown; remove while the lean remains pliable.
9. Add oil only if the rendered fat is insufficient. Char the fresh chillies, leek or garlic shoots and garlic until aromatic and lightly blistered.
10. Return beef with the douchi. Toss until dry and fragrant. Taste before adding any soy; add it in small measured increments only if needed.

## WHAT SUCCESS LOOKS LIKE
The chilled slab is evenly seasoned through its centre and firm enough to slice thinly, with attached fat that turns translucent and renders at the edges. Smoke is distinct but not acrid. The final stir-fry is dry, with separately legible cured beef, blistered chilli and douchi rather than a wet sauce.

Visual sourcing gap — long-cured pork larou imagery cannot validate beef fat architecture, cure penetration or this refrigerated fully cooked process. Photograph the cured cross-section, ten representative chilled slices, rendered beef before seasoning and the finished stir-fry.

## WATCH OUT FOR
Do not shorten the approved 7-day schedule, use a thicker slab without recalculating, vacuum-pack a salt-only cure, let the refrigerator exceed 4°C, proceed past an obviously uneven centre, pause between smoking and steaming, treat smoke as the safety cook, smoke unattended, or present the result as shelf-stable preservation.

## STORAGE
After smoking and steaming, cool rapidly and refrigerate up to 3 days or freeze measured portions. Stir-fried leftovers keep up to 2 days.

---

## PROCESS RECORD
{{MIGRATED_DISH_STATE_BLOCK}}
### Planning brief
Dish candidate: Smoked cured beef with chillies and douchi — halal Hunan-style adaptation
Purpose: Test whether beef fat can carry the cured, smoky and fermented flavours of Hunan preserved-meat dishes within a safe halal home process.
Role: main
Priors: None
Locks: Use halal beef instead of pork and state explicitly that the result is neither equivalent to nor shelf-stable Hunan larou. | Use an approximately 3cm-thick slab and cure for 7 complete days, choosing the conservative side of the cited source’s internally inconsistent thickness guidance, 2026-07-17.
Exemptions: None
Research emphasis: None
Destination section: Hunan — {{TARGET_SECTION_GID}}

### Decisions
Human — Marco: Use halal beef instead of pork and state explicitly that the result is neither equivalent to nor shelf-stable Hunan larou.
Human — Marco: Use an approximately 3cm-thick slab and cure for 7 complete days, choosing the conservative side of the cited source’s internally inconsistent thickness guidance, 2026-07-17.

### Research basis
Intentional halal adaptation, human-approved; no equivalence to shelf-stable Hunan larou is claimed.

Construction — The Curesmith, “Calculator for Dry EQ Cure,” https://thecuresmith.com/calculator-dry-eq-cure/ — supports 2.5% salt for a salt-only EQ cure, 2–4°C refrigeration, daily turning and verifying penetration before proceeding. Its reader-facing material is internally inconsistent on thickness: the explanatory section says a flat slab cures inward from both faces so effective distance is half the total thickness, while the calculator instructions tell the user to enter the full thickest measurement and apply `(thickness in cm ÷ 0.635) + 2 days`. Entering the approved 3cm full measurement gives 6.72 days, rounded to 7. Marco selected that conservative route. The source also warns that vacuum EQ curing should include an accurately calculated nitrite cure; this task therefore uses a non-vacuum salt-only container.

Construction — USDA FSIS, “Safe Minimum Internal Temperature Chart,” https://www.fsis.usda.gov/food-safety/safe-food-handling-and-preparation/food-safety-basics/safe-temperature-chart — whole-muscle beef requires at least 63°C/145°F followed by a three-minute rest. This is the final cooking safety floor, not evidence of cure penetration or shelf stability.

Construction — Food Network Kitchen, “Tea-Smoked Chicken,” https://www.foodnetwork.com/recipes/food-network-kitchen/tea-smoked-chicken-recipe-1928362 — directly supports the lidded foil-lined vessel, rack, rice/black-tea/sugar smoke mixture and short smoke. This task uses smoke only for flavour and immediately steams to a measured beef endpoint.

Construction — Red House Spice, “Hunan Pork Stir-fry,” https://redhousespice.com/hunan-pork/ — 200g fatty pork, 150g fresh chilli, five garlic cloves, one tablespoon douchi and soy; it renders and removes the meat, chars chilli and garlic, then returns the meat with douchi and soy. The task transfers that order to cured beef. Its 250g chilli against an expected 600–700g cooked beef yield is deliberately less chilli-heavy because cured smoked beef is more concentrated than fresh pork belly; this is a close-precedent inference, not a source-exact ratio.

Later validation — The Mala Market, “Cured Pork Belly Stir-fry (Chao Larou),” https://blog.themalamarket.com/cured-pork-belly-stir-fry-chao-larou/ — supports thinly sliced cured fatty meat being rendered before vegetables and sauce, but uses pork larou and doubanjiang rather than this task’s beef and douchi and cannot validate the cure.

Technical premise: the stir-fry order and brief smoke are close-precedent supported. The conservative 3cm/7-day cure route is Human-approved; the reconstructed whole task remains pending independent Claude verification.

### Material changes
2026-07-17 — GPT — Reconstruction. Reopened the cure calculator, corrected the unsupported five-day route, blocked execution and added cure-container, smoke-to-steam and temperature controls.
2026-07-17 — GPT — Delta after Human Review. Recorded Marco’s approximately 3cm/7-day decision, reconciled the source’s conflicting full-thickness and half-thickness language, restored Stage: Researched and retained the requirement for independent Claude whole-task verification.
2026-07-17 — Claude — Reconstruction verification, no content change. Reopened the cure calculator against raw HTML: confirmed a genuine conflict between its calculator input instructions ("measure at the thickest point of the cut") and its explanatory prose (half-thickness for flat cuts) — the approved 3cm/7-day route is the correct conservative reading. Salt % (2.5%) and 2-4°C also confirmed. Reopened Red House Spice and The Mala Market against raw HTML: both match as cited. FSIS safe-temperature chart and Food Network tea-smoked chicken remain inaccessible (403 via direct fetch and curl); both support generic/non-controlling claims (standard 63°C/145°F+3min beef floor; generic foil/rack/tea-rice-sugar smoke setup), not a ratio or defining-identity claim — recorded as an access gap, not a blocker.
