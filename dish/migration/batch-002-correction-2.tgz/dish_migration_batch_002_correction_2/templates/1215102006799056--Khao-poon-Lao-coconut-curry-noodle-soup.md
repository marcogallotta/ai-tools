Khao poon — Lao coconut curry noodle soup

Lao coconut chicken curry soup served over rice vermicelli with banana blossom, bean sprouts, cabbage and fresh herbs. The approved version uses a homemade dried-chilli, galangal, garlic and shallot paste with pla ra; fingerroot is the one disclosed omission.

WHY COOK IT
Learn the Lao coconut noodle-soup system: poached chicken pounded into curry paste, coconut-fat blooming, fermented seasoning and fresh per-bowl noodles and vegetables.


## WHAT TO BUY
- Chicken breast: 340g
- Coconut milk: 450ml
- Rice vermicelli: 170g dry
- Shallots: about 90ml roughly chopped
- Garlic: 4 cloves
- Scallions: about 25g
- Banana blossom, bean sprouts and cabbage or lettuce for three bowls
- Fresh lime and chosen herbs for serving

## CHECK BEFORE COOKING
- Confirm home-sun-dried bird's-eye chillies and Mae Boonlam pla ra.
- Fingerroot is intentionally omitted. Do not substitute jarred Thai curry paste.
- Prepare noodles and raw garnishes fresh for each sitting; only the curry base is batchable.

## QUANTITIES
Portions: 3. Protein runs roughly 24-26g/portion (340g raw chicken breast / 3), well under the ~50g
target — this is a noodle-soup format carrying protein in finely pounded shreds through a starch- and
broth-forward bowl rather than a stacked-protein dish; not increased here to preserve the tested
paste-to-chicken ratio.
- Chicken breast: 340g
- Water for poaching: enough to cover; reserve 225ml clear poaching broth
- Coconut milk: 450ml, divided equally
- Neutral oil: only if the coconut milk will not separate enough to bloom the paste, up to 10ml

Homemade paste:
- Home-dried bird's-eye chillies: 5–6
- Galangal: 3 thin slices
- Garlic: 4 cloves
- Shallots: 90ml, roughly chopped
- Fingerroot: omitted; see WATCH OUT FOR

Seasoning:
- Mae Boonlam pla ra: 22ml
- Fish sauce: 22ml
- White sugar: 4–5g [approx]
- Fine salt: begin with 4g [approx], then rely on tasting after the salty ferments
- Makrut lime leaves: 3, torn
- Scallions: about 25g, sliced

Per-bowl assembly:
- Rice vermicelli: about 57g dry
- Banana blossom
- Bean sprouts
- Shredded cabbage or lettuce
- Rau răm and mint; cilantro optional
- Lime and fresh chilli

## HOW TO COOK IT
1. Gently poach the chicken in enough water to cover until just cooked. Remove it and reserve 225ml clear broth.
2. Pound the dried chillies, galangal, garlic and shallots to a smooth paste. Pound the cooked chicken into that paste until finely shredded and integrated.
3. Cook 225ml coconut milk in a pot until it thickens and visible oil begins to separate. If the product will not split, add only enough neutral oil to fry the paste rather than boiling indefinitely.
4. Add the chicken-paste mixture and fry until fragrant and the raw shallot smell is gone.
5. Add the remaining 225ml coconut milk, 225ml reserved broth, pla ra, fish sauce, sugar, starting salt and makrut leaves. Simmer gently for 15–20 minutes.
6. Taste for fermented salt and curry concentration. Add scallions near the end.
7. Cool and store the curry base in three portions. At each sitting cook vermicelli fresh, reheat one portion of curry gently and assemble with raw vegetables, herbs, lime and chilli.

## WHAT SUCCESS LOOKS LIKE
The curry is orange-red, coconut-rich and fermented-savoury but remains pourable. Finely pounded chicken is distributed through the broth rather than appearing as dry shreds. Fresh noodles, shoots, sprouts, cabbage and herbs remain separately legible in the bowl.

Visual reference — https://hungryinthailand.com/khao-poon-recipe/ — Observe the orange-red pourable broth and separate-garnish assembly. Its ingredient and method sequence is also the controlling construction.

## WATCH OUT FOR
Fingerroot is a real compromise, not a trivial omission: the soup loses a distinctive earthy medicinal aromatic note. Do not replace the homemade paste with jarred Thai curry paste, omit pounding the chicken into the paste, or pre-cook all noodles for storage.

## STORAGE
Refrigerate the curry base up to 3 days. Store noodles, raw vegetables, herbs and lime separately and prepare them fresh.

---

## PROCESS RECORD
{{MIGRATED_DISH_STATE_BLOCK}}
### Planning brief
Dish candidate: Khao poon — Lao coconut curry noodle soup
Purpose: Learn the Lao coconut noodle-soup system: poached chicken pounded into curry paste, coconut-fat blooming, fermented seasoning and fresh per-bowl noodles and vegetables.
Role: main
Priors: None
Locks: Make the paste fully from scratch with home-sun-dried chillies and pla ra; do not use jarred paste. | Omit fingerroot for the first cook and record what is lost.
Exemptions: None
Research emphasis: None
Destination section: Isan/Lao — {{TARGET_SECTION_GID}}

### Decisions
Human — Marco: Make the paste fully from scratch with home-sun-dried chillies and pla ra; do not use jarred paste.
Human — Marco: Omit fingerroot for the first cook and record what is lost.

### Research basis
Intentional test dish, human-approved.
Construction — Hungry in Thailand, https://hungryinthailand.com/khao-poon-recipe/ — four-serving formula: 454g chicken breast, 600ml coconut milk, 300ml reserved chicken broth, 7 dried chillies, 4 galangal slices, 5 garlic cloves, 1/2 cup shallots, 2 tbsp fingerroot, 30ml fish sauce, 30ml fermented fish sauce and 227g dry vermicelli. It poaches the chicken, pounds the cooked chicken into the paste, blooms the paste in half the coconut milk and then adds the remaining coconut milk, broth and seasonings.
The task is scaled by 0.75 to three portions; small spice-count rounding and starting sugar/salt are marked approximate.

### Material changes
2026-07-16 — Claude — Delta: corrected major serving-scale errors but retained an executable method that did not match the cited source.
2026-07-16 — GPT — Reconstruction: removed unsupported lemongrass and duplicate aromatic systems, restored the source's pounded-chicken and split-coconut method, made the three-portion scale internally coherent and reset whole-task verification to Claude.
2026-07-17 — Claude — Local: added the contract-required protein-shortfall disclosure under Portions (~24-26g/portion vs. the ~50g target); no other field affected.
