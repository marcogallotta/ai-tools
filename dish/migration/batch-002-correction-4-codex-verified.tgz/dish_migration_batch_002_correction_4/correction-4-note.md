# Correction 4

All 99 templates were repaired in one pass for Dish schema version 2.

- Preserved the 99 source GIDs, source-note snapshots, dispositions, destination names, and both unresolved migration placeholders.
- Added source-supported recognition formatting, or an explicit legacy-source absence marker where recognition was absent.
- Aligned title formatting with the existing Planning brief Role without changing Role judgments.
- Added truthful absence markers for required recipe sections and missing `Portions:` values.
- Added a schema-approved Research basis classification supported by the existing task content.
- Retained only genuine `Human — Marco:` entries in Decisions.
- Moved non-Human legacy process narration and invalid legacy material-change narration into clearly labeled legacy Research basis provenance; no Dish Research, Verification, Human authority, or canonical audit history was invented.
- Kept empty canonical Decisions and Material changes headings where no legal entries exist, satisfying the deterministic batch validator without fabricating content.

Acceptance results:

- Supplied `parse_task_document`: 99/99 parsed.
- Supplied `validate_task_document`, schema version 2: 99/99 with zero findings.
- Supplied `validate_batch_002.py`: 99/99 passed.
- Placeholder integrity: 99/99 for each placeholder.
- Source-note byte fidelity: 99/99.
- Blocked GIDs: none.
