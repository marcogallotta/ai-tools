# Codex independent verification

Codex independently checked the downloaded correction-4 archive after ChatGPT's pass.

The deterministic parser, schema validator, migration validator, source-note fidelity checks,
placeholder checks, and importer prepare-only path all passed for 99/99 templates. A semantic
authority audit then found four explicit source decisions still serialized in Research basis as
`Human — Moinudin, <date>:` lines. Marco's settled corpus-wide identity rule says Moinudin means
Marco. Those four lines were mechanically normalized to `Human — Marco:` and moved into Decisions,
without changing their dates or decision text:

- `1215106644939642` — Borani esfenaj
- `1215106677533929` — Persian spiced beef patty
- `1216218270164833` — Tam mamuang
- `1216474303602472` — Joojeh

No other template content, source note, source GID, destination name, placeholder, assignment, or
state was changed. Manifest template hashes were updated for these four files. All acceptance gates
were rerun after the correction.
