[non-main] Mont Blanc / Montebianco — two no-oven verrines
two no-oven verrines
A small seasonal chestnut dessert served in two glasses, with chestnut vermicelli or cream and lightly sweetened whipped cream. The traditional meringue base is deliberately omitted.

WHY COOK IT
Use fresh seasonal chestnuts and practise chestnut smoothness, ricer behaviour and restrained cream balance.
## WHAT TO BUY
- Whole fresh chestnuts: enough to yield about 150g cooked and peeled
- Whipping cream: 100ml
- Cocoa or dark chocolate: optional
## QUANTITIES
Portions: [Not specified in legacy source.]
Two 120–160ml glasses.
- Cooked peeled chestnuts: 150g
- Milk: 60–90ml as needed
- White sugar: 10–18g
- Vanilla: optional
- Fine salt: pinch
- Cocoa or dark chocolate: optional
- Whipping cream: 100ml
- White sugar for cream: 5–8g or less if chestnuts are sweet
## HOW TO COOK IT
1. Cook and peel fresh chestnuts. Warm them with enough milk to soften, then blend or mash completely smooth.
2. Sweeten lightly, add salt and adjust until suitable for a ricer or piping bag.
3. Whip cream to soft-medium peaks.
4. Assemble restrained layers in two glasses.
5. Chill briefly only if needed.
## WHAT SUCCESS LOOKS LIKE
Chestnut remains dominant. Purée forms defined strands or a deliberate smooth layer rather than dry crumbs or a wet puddle. Cream lightens rather than buries it.

Visual reference — https://yourguardianchef.com/simple-mont-blanc-dessert/ — Observe chestnuts simmered in milk, mashed and passed into vermicelli, then topped with cream. Ignore baked meringue, large batch and stiff cream.
## WATCH OUT FOR
Do not over-sweeten, force decorative extrusion through unsuitable purée or add a heavy cream cap.
---
## PROCESS RECORD
{{MIGRATED_DISH_STATE_BLOCK}}
### Planning brief
Dish candidate: Mont Blanc / Montebianco — two no-oven verrines
Purpose: Use fresh seasonal chestnuts and practise chestnut smoothness, ricer behaviour and restrained cream balance.
Role: non-main — dessert; two verrines are not a meal candidate
Priors: None
Locks: Use fresh whole chestnuts cooked from scratch. | Make the no-meringue verrine version. | Reduce the rehearsal to two glasses.
Exemptions: None
Research emphasis: None
Destination section: Desserts — {{TARGET_SECTION_GID}}
### Decisions
Human — Marco: Use fresh whole chestnuts cooked from scratch.
Human — Marco: Make the no-meringue verrine version.
Human — Marco: Reduce the rehearsal to two glasses.
### Research basis
Classification: Source-backed dish
Human-approved seasonal adaptation.
Construction — Institute of Culinary Education, https://www.ice.edu/blog/mont-blanc-dessert — supports the chestnut-and-whipped-cream identity and traditional meringue context.
Construction — Epicurious, https://www.epicurious.com/recipes/food/views/mont-blanc — supports chestnut purée and cream structure.
Visual/process reference — Your Guardian Chef, https://yourguardianchef.com/simple-mont-blanc-dessert/ — supports simmering chestnuts in milk and forming vermicelli.
### Material changes
