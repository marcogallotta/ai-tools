Rendang — Indonesian/Malay dry coconut-spice beef curry
Indonesian/Malay dry coconut-spice beef curry
Rendang is the benchmark Indo/Malay dry coconut-spice reduction and should be learned as its own system, not folded into wet curry.

WHY COOK IT
Learn the complete open reduction through wet curry and kalio to the dark, dry, oil-separated final coating.
## WHAT TO BUY
[Not specified in legacy source.]
## CHECK BEFORE COOKING
- Target cool weather around October 2026; the full open reduction is the point of the task.
- Confirm candlenuts, daun salam, galangal, lemongrass, makrut leaves, coconut milk and whole spices,
  plus desiccated or fresh grated coconut for kerisik.
## QUANTITIES
Portions: 3 substantial portions.
- Beef chuck: 600g, 4–5cm cubes
- Coconut milk: 480ml
- Water: start with 350–450ml; add hot water only if beef tightens before tender
- Shallots: 150g
- Garlic: 30g
- Italian long red chilli: 60g
- Candlenuts: 6; macadamia fallback
- Fresh ginger: 10g
- Galangal: 10g
- Turmeric powder: 1/2–3/4 tsp
- Coriander seed: 1 tsp
- Cumin seed: 1/2 tsp
- Black pepper: 1 tsp
- Lemongrass: 2 stalks
- Makrut lime leaves: 3
- Daun salam: 3 if in stock; otherwise omit
- Cinnamon: 1 small piece
- Green cardamom: 2 pods
- Cloves: 2
- Star anise: 1
- Tamarind paste: 12g
- Fine salt: start with 8g, adjust near the end
- Kerisik coconut: 4–6 tbsp desiccated or fresh grated coconut, dry-toasted and pounded
## HOW TO COOK IT
1. Dry-toast the kerisik coconut in a dry pan over low-medium heat, stirring constantly, until deep brown and fragrant; do not rush or scorch. Pound or grind to an oily, paste-like texture and set aside.
2. Blend shallot, garlic, chilli, candlenut, ginger, galangal, turmeric, coriander, cumin and pepper to a smooth bumbu.
3. Fry the bumbu patiently until the raw smell is gone and oil begins to show.
4. Add beef and coat thoroughly.
5. Add coconut milk, water, whole aromatics, tamarind and salt.
6. Simmer uncovered very gently, stirring periodically. Add hot water only if needed before the beef is tender.
7. Continue through wet-curry and kalio stages until liquid evaporates, coconut oil separates and the bumbu begins frying around the beef, stirring more frequently as it thickens. Adjust salt once concentration is nearly complete.
8. Stir the prepared kerisik through the whole batch during the late reduction, before the final dark, dry and clinging stage. Continue frying gently until it is fully incorporated, nuttier and deeper in colour, with almost no free liquid remaining.
## WHAT SUCCESS LOOKS LIKE
Beef is tender. At the kalio checkpoint, the sauce has reduced substantially and a visible puddle of coconut oil has separated, but loose sauce remains. Continue until almost no free liquid remains and the darkened, kerisik-enriched bumbu clings densely to each beef piece; separated oil is visible without the spices or coconut tasting burnt.

Visual reference — https://www.rotinrice.com/beef-rendang/ — Observe the coarse-oatmeal bumbu texture, kerisik stirred in near the end, and final dark, nearly dry coating. This validates the bumbu texture, kerisik step and final coating only; do not adopt its exact spice-weight ratios, which are not normalized to this task's beef weight.
## WATCH OUT FOR
Fresh turmeric leaf is unavailable and omitted, losing grassy-citrus aroma. Tamarind replaces asam kandis or gelugur in acid function but not aroma. Omit daun salam if unavailable; do not substitute Mediterranean bay. Do not pressure-tenderise, begin with the prior 1.2L total liquid, stop at kalio and call it rendang, force high heat in the final stage, or scorch the kerisik while toasting.
---
## PROCESS RECORD
{{MIGRATED_DISH_STATE_BLOCK}}
### Planning brief
Dish candidate: Rendang — Indonesian/Malay dry coconut-spice beef curry
Purpose: Learn the complete open reduction through wet curry and kalio to the dark, dry, oil-separated final coating.
Role: main
Priors: None
Locks: Approved full open-stovetop reduction. Use tamarind for asam kandis/gelugur, and omit daun salam and turmeric leaf if unavailable; disclose these substitutions. | Use kerisik throughout the entire batch. The split kerisik-versus-no-kerisik comparison was not approved and has been removed, 2026-07-30.
Exemptions: None
Research emphasis: Practical only: the full open reduction is deferred to the cool-weather cooking window.
Destination section: Indonesia/Malaysia — {{TARGET_SECTION_GID}}
### Decisions
Human — Marco: Approved full open-stovetop reduction. Use tamarind for asam kandis/gelugur, and omit daun salam and turmeric leaf if unavailable; disclose these substitutions.
Human — Marco: Use kerisik throughout the entire batch. The split kerisik-versus-no-kerisik comparison was not approved and has been removed, 2026-07-30.
### Research basis
Classification: Source-backed dish
Source-backed dish with Human-approved local substitutions.
Construction update — The defining method is open reduction: beef and aromatic paste cook in coconut milk until water evaporates, coconut fat releases and the meat fries in that fat to a dark dry coating. Pressure may tenderise first, but must be followed by long uncovered reduction; a sealed-only method is wrong.
Later validation — Roti n Rice, https://www.rotinrice.com/beef-rendang/ — confirms candlenut or macadamia fallback, ground coriander and cumin in the bumbu, and kerisik as a defining late-stage finishing step. Turmeric powder in the bumbu is plausible and standard but not independently confirmed by a directly fetched source; retained as a minor unverified inclusion.
Sources: https://rasamalaysia.com/beef-rendang-recipe-rendang-daging/ ; https://www.rotinrice.com/beef-rendang/
Legacy agent construction/provenance (not Dish evidence):
Agent — Codex: Reconciled the construction update with the recorded Human Review result and removed stale pending/rejected branches from the process record.
Agent — Claude: Verification found the sole original source omits kerisik and did not support candlenut/coriander/cumin in the bumbu; re-sourced via rotinrice.com, which confirms candlenut, coriander and cumin and treats kerisik as a defining structural finishing step.
Legacy material-change narration (not canonical Dish audit history and not Dish evidence):
2026-07-30 — GPT-5.6 Thinking — Removed the unapproved split-batch kerisik comparison and restored one coherent whole-batch kerisik finish. Fresh verification required.
### Material changes
