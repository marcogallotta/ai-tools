Whole branzino with lemon-parsley pan juices — [Recognition not specified in legacy source.]
[Recognition not specified in legacy source.]
A single small whole branzino, pan-cooked with a light flour dusting and finished with lemon, olive oil and parsley.

WHY COOK IT
Cook a clean, delicate whole-fish dish without olives, capers, butter or strong herbs.
## WHAT TO BUY
[Not specified in legacy source.]
## QUANTITIES
Portions: 1.
- Whole branzino / spigola: 350–450g, gutted and scaled
- Fine salt: about 1% of cleaned fish weight
- Plain flour: 8–10g, for a very light dusting
- Olive oil: 15–20ml
- Lemon zest: from 1/4–1/2 lemon
- Lemon juice: start with 5–8ml; add more only after tasting
- Fresh parsley: 5–8g, chopped shortly before serving
## HOW TO COOK IT
1. Score the fish lightly. Salt for about 10 minutes, then pat very dry.
2. Dust lightly with flour and shake off the excess.
3. Pan-cook over medium-high heat until the first side browns and releases cleanly.
4. Turn once and finish more gently.
5. Stop when the flesh at the thickest point separates cleanly from the bone but remains juicy.
6. Remove the fish. Off fierce heat, add the zest and starting lemon juice to the pan juices and olive oil.
7. Spoon over the fish and finish with parsley.
## WHAT SUCCESS LOOKS LIKE
The skin is lightly crisp and evenly browned without a heavy crust. The fish remains intact and juicy at the bone. Lemon-parsley juices gloss rather than flood it.
## WATCH OUT FOR
Do not flour heavily, overcook the centre or add more lemon before tasting.
---
## PROCESS RECORD
{{MIGRATED_DISH_STATE_BLOCK}}
### Planning brief
Dish candidate: Whole branzino with lemon-parsley pan juices
Purpose: Cook a clean, delicate whole-fish dish without olives, capers, butter or strong herbs.
Role: main
Priors: Legacy source references prior related work: The dish retains the previously researched whole-branzino pan method and lemon-parsley finish. Quantities were reduced proportionally to one fish.
Locks: Reduce the task to one 350–450g whole branzino for one portion and remove baseline/calibration framing.
Exemptions: None
Research emphasis: None
Destination section: Verification Queue — {{TARGET_SECTION_GID}}
### Decisions
Human — Marco: Reduce the task to one 350–450g whole branzino for one portion and remove baseline/calibration framing.
### Research basis
Classification: Source-backed dish
The dish retains the previously researched whole-branzino pan method and lemon-parsley finish. Quantities were reduced proportionally to one fish.
### Material changes
