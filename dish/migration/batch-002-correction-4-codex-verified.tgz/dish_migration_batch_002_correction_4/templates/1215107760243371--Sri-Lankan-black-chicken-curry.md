Sri Lankan black chicken curry — from-scratch roasted-spice reconstruction
from-scratch roasted-spice reconstruction
Bone-in chicken cooked in a dark, dryish Sri Lankan curry with curry leaves, blackened chilli and a dish-size homemade roasted curry powder. No coconut milk.

WHY COOK IT
Use the limited frozen curry leaves deliberately and learn a Sri Lankan black-curry system distinct from North Indian bhuna, korma and Chettinad.
## WHAT TO BUY
- Bone-in chicken pieces: 900g
- Onion: about 100g
- Green chillies: 2
- Coconut oil: 50ml, preferred; neutral oil is a disclosed fallback
- Pandan leaf: optional quality upgrade
## CHECK BEFORE COOKING
- Frozen curry leaves are available but limited; use about 20 leaves plus 3–4 for the spice mix.
- Grind only the dish-size spice quantity below, not a standing stock batch.
- If using neutral oil, expect less coconut aroma.
- No precision scale is in the kitchen (equipment.md: ordinary kitchen scale, coffee grinder, mortar
  and pestle only); the roasted curry powder below is stated in spoon/pinch measures for the
  sub-5g spices rather than sub-gram weights, since the equipment can't reliably resolve those.
## QUANTITIES
Portions: 3.
- Bone-in chicken: 900g, small pieces
- Light soy sauce: 13ml
- Fine salt: begin with 8g
- Ground black pepper: 1 tsp
- Kashmiri chilli powder: about 12g [approx]
- Coconut oil: 50ml; neutral oil is a real-compromise fallback
- Cassia: 1 small stick
- Whole cloves: 4
- Green cardamom pods: 2, bruised
- Onion: 100g, finely chopped
- Green chillies: 2, split
- Garlic: 15g
- Ginger: 15g
- Pandan leaf: 1 small piece, optional
- Curry leaves: 20
- Turmeric: 1/2 tsp
- Water: 225ml initially, with a small amount extra only if required

Dish-size roasted curry powder; use all:
- Coriander seed: 5.5g
- Cumin seed: 5.5g
- Black peppercorn: 3.5g
- Basmati rice: 3.5g
- Green cardamom seed: 1/2 tsp, scraped from pods
- Fennel seed: 1/2 tsp
- Whole cloves: 3–4, whole
- Black mustard seed: 1/4 tsp, optional
- Curry leaves: 3–4
## HOW TO COOK IT
1. Dry the curry leaves for the powder over low heat. Toast rice until light brown, then add the remaining powder spices and toast until darker and aromatic without burning. Cool and grind.
2. Separately dry-roast the Kashmiri chilli powder very carefully until deep chocolate-red, not black. Combine with the finished roasted curry powder.
3. Mix chicken with soy sauce, starting salt and ground pepper.
4. Heat coconut oil. Fry cassia, cloves, cardamom, onion, chillies, garlic, ginger, optional pandan and the 20 curry leaves until onion begins to brown.
5. Add turmeric and the complete dark spice mixture; stir briefly.
6. Add 225ml water and bring to a simmer. Add chicken, coating it thoroughly. Add only enough extra water to come close to, but not fully cover, the pieces.
7. Cover and simmer about 10 minutes. Uncover and continue until chicken is safely cooked and the black sauce reduces to a thick coating.
8. Rest 5 minutes and correct salt.
## WHAT SUCCESS LOOKS LIKE
Chicken remains intact beneath a very dark peppery spice coating that clings rather than pools. Curry leaves remain visible; spice tastes deeply roasted, not burnt or ashy.

Visual/process reference — https://greatcurryrecipes.net/2024/02/13/sri-lankan-black-chicken-curry/ — Observe chilli/curry powder darkened only to chocolate brown, aromatic tempering, brief covered cook and uncovered reduction to a dry coating. Ignore its purchased curry powder because this task makes the equivalent component from scratch.
## WATCH OUT FOR
Do not roast the already-finished homemade curry powder a second time, burn the chilli powder or add coconut milk. Pandan omission and neutral oil are real aromatic compromises. This reconstruction deliberately removes the prior tomato-and-tamarind branches because they came from different curry systems and made the formula an unbounded composite.
## STORAGE
Refrigerate up to 4 days or freeze in portions. Reheat with a small splash of water if spices cake onto the chicken.
---
## PROCESS RECORD
{{MIGRATED_DISH_STATE_BLOCK}}
### Planning brief
Dish candidate: Sri Lankan black chicken curry
Purpose: Use the limited frozen curry leaves deliberately and learn a Sri Lankan black-curry system distinct from North Indian bhuna, korma and Chettinad.
Role: main
Priors: Legacy source references prior related work: Spice construction — The Flavor Bender, https://www.theflavorbender.com/sri-lankan-roasted-curry-powder/ — the source's actual ingredient list totals 119g (not the ~99g previously stated here — that was a descriptive-summary arithmetic error; the per-ingredient scale factors below were always correctly proportional to the real 119g total). This task scales it to approximately 21g total, enough for the source's two-tablespoon dish dose, and uses the whole mix immediately.
Locks: Prioritise the dish to use curry leaves. | Use no coconut milk and make the roasted curry powder from scratch rather than buying a blend.
Exemptions: None
Research emphasis: None
Destination section: Subcontinent — {{TARGET_SECTION_GID}}
### Decisions
Human — Marco: Prioritise the dish to use curry leaves.
Human — Marco: Use no coconut milk and make the roasted curry powder from scratch rather than buying a blend.
### Research basis
Classification: Source-backed dish
Human-approved no-coconut and from-scratch route.
Construction — The Curry Guy, https://greatcurryrecipes.net/2024/02/13/sri-lankan-black-chicken-curry/ — per 1kg chicken uses 2 tbsp curry powder, 2 tbsp Kashmiri chilli, soy, coconut oil, whole spices, onion, garlic, ginger, pandan, curry leaves and about 250ml water, then reduces uncovered to a thick black coating. It explicitly says already-roasted curry powder need not be roasted again.
Spice construction — The Flavor Bender, https://www.theflavorbender.com/sri-lankan-roasted-curry-powder/ — the source's actual ingredient list totals 119g (not the ~99g previously stated here — that was a descriptive-summary arithmetic error; the per-ingredient scale factors below were always correctly proportional to the real 119g total). This task scales it to approximately 21g total, enough for the source's two-tablespoon dish dose, and uses the whole mix immediately.
Legacy material-change narration (not canonical Dish audit history and not Dish evidence):
2026-07-16 — Claude — Delta: removed coconut milk and introduced a from-scratch powder, but retained tomato, tamarind and a method combined from incompatible source systems.
2026-07-16 — GPT — Reconstruction: selected one coherent black-curry method, scaled a dish-size powder, removed the mixed tomato/tamarind branches and reset whole-task verification to Claude.
2026-07-17 — Claude — Delta: fixed a recurrence of incident 15 (sub-gram spice precision unmeasurable with stated equipment) — green cardamom seed, fennel seed, whole cloves and black mustard seed were still specified to 0.1g; restated as spoon/count measures (1/2 tsp, 1/2 tsp, 3-4 whole, 1/4 tsp) achievable without a precision scale, keeping the same approximate proportions. Corrected the "99g" descriptive total in Research basis to the source's actual 119g. Contained to the curry-powder sub-list and one Research basis line; the rest of the construction is unaffected.
### Material changes
