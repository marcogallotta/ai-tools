Pasta alla Genovese — no-tomato beef and onion ragù
no-tomato beef and onion ragù
A Neapolitan beef-and-onion ragù with no tomato: browned beef, a very large onion mass, restrained soffritto and slow reduction.

WHY COOK IT
Cook the onion-led form directly after earlier tomato-containing house versions.
## WHAT TO BUY
[Not specified in legacy source.]
## QUANTITIES
Portions: 3 substantial sauce portions; cook pasta fresh for each sitting.
- Beef chuck or similar collagen-rich beef: 600g, cut into 4cm pieces
- Onions: 1.3kg, thinly sliced
- Carrot: 80g, finely chopped
- Celery: 80g, finely chopped
- Olive oil: 45ml
- Fine salt: begin with 10g and adjust after reduction
- Black pepper
- Water or unsalted stock: 100–150ml only if the onions do not release enough liquid
- Dry pasta: use the normal per-sitting amount
- Parmigiano: optional
## HOW TO COOK IT
1. Brown the beef well in batches.
2. Add onions, carrot, celery, oil and salt. Cover initially so the onions collapse and release liquid.
3. Cook low and slow, stirring regularly, until the onions are tan, sweet and nearly melted.
4. Return or retain the beef in the onion mass. Add only enough water or stock to prevent catching.
5. Continue until the beef is tender and the onions form a thick ragù. Remove the beef temporarily only if the onions need further reduction.
6. Divide the sauce into three portions. Cook pasta fresh and toss vigorously with one sauce portion and pasta water.
## WHAT SUCCESS LOOKS LIKE
The onions collapse into a tan-gold, nearly melted ragù with no sliced-onion bulk or tomato character. Tender beef integrates into a sauce that clings to pasta without watery pooling or an oil slick.
## WATCH OUT FOR
Do not add tomato, rush onion collapse, darken the onions into bitterness or add an unnecessary herb bundle.
## STORAGE
Refrigerate or freeze the sauce in three portions. Cook pasta fresh.
---
## PROCESS RECORD
{{MIGRATED_DISH_STATE_BLOCK}}
### Planning brief
Dish candidate: Pasta alla Genovese — no-tomato beef and onion ragù
Purpose: Cook the onion-led form directly after earlier tomato-containing house versions.
Role: main
Priors: None
Locks: Make this a normal no-tomato Genovese batch, not a browning comparison. Use about 600g beef and 1.3kg onions for three sauce portions.
Exemptions: None
Research emphasis: None
Destination section: Verification Queue — {{TARGET_SECTION_GID}}
### Decisions
Human — Marco: Make this a normal no-tomato Genovese batch, not a browning comparison. Use about 600g beef and 1.3kg onions for three sauce portions.
### Research basis
Classification: Source-backed dish
Source-backed pasta alla Genovese.
Construction — Serious Eats, Pasta alla Genovese — supports the Neapolitan beef-and-onion identity, massive onion collapse and no-tomato structure.
Construction — Mission Food, Pasta alla Genovese — corroborates beef, onions, aromatics and long cooking as the sauce structure.
The halal version uses olive oil rather than pancetta or lardo.
### Material changes
