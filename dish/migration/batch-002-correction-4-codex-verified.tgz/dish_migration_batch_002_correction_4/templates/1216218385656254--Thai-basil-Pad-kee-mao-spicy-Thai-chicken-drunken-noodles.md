Pad kee mao — Thai basil; spicy Thai chicken drunken noodles
Thai basil; spicy Thai chicken drunken noodles
A hot, dry-glossy stir-fry of dried wide rice noodles, thin chicken breast, garlic, Thai chilli, Chinese broccoli and Thai basil, cooked in three small batches for the weak burner.

WHY COOK IT
Learn the chilli–garlic–basil noodle system and controlled weak-burner execution, distinct from the sweeter, darker pad see ew profile. Chicken replaces the prior beef version because beef was chosen mainly to fill a cuisine gap rather than for a structural advantage.


WHAT TO BUY
- Chicken breast: 600 g
- Chinese broccoli or tender-stem broccoli: 240 g
- Dried 10 mm rice noodles: 270 g

CHECK BEFORE COOKING
- Thai basil: harvest 30 g good leaves; postpone rather than substitute Italian basil.
- Soak dried noodles in cool water for 45–60 minutes until flexible, then boil until just tender and rinse in cold water before stir-frying.
- Slice and marinate chicken close to cooking.
- Mix the sauce and divide every component into three batches before heating the wok.

SUBSTITUTION DISCLOSURE
- Chicken breast replaces beef. Rating: close-enough for the dish’s chilli–garlic–basil noodle purpose; the beef-specific browned flavour is lost, but beef was not structurally necessary.
- Vegetarian mushroom oyster sauce replaces oyster sauce. Rating: close-enough in this sauce system.
- Dried noodles and Thai basil remain disclosed compromises against fresh wide noodles and holy basil.

QUANTITIES
Portions: 3 substantial portions, cooked as 3 separate batches.

Chicken
- Chicken breast: 600 g, thinly sliced across the grain
- Light soy: 18 ml
- Cornstarch: 12 g
- Neutral oil: 12 ml

Noodles and vegetables
- Dried rice noodles: 270 g, boiled and cold-rinsed before the wok
- Chinese broccoli: 240 g, stems and leaves separated
- Garlic: 24 g
- Thai chilli: 12–18 g
- Thai basil: 30 g
- Neutral oil: 45 ml total

Sauce
- Vegetarian mushroom oyster sauce: 55 ml
- Light soy: 35 ml
- Fish sauce: 15 ml
- Dark soy: 10 ml
- White sugar: 12 g
- Water: 60 ml

HOW TO COOK IT
For each batch:
1. Heat the wok fully. Sear 200 g chicken quickly and remove while just underdone.
2. Cook broccoli stems, then leaves, until bright and almost tender; remove if heat is falling.
3. Fry garlic and chilli for 15–20 seconds.
4. Add the pre-boiled, cold-rinsed noodles and sauce. Toss 30–60 seconds until glossy and evenly coated. Add water only by the teaspoon if dry.
5. Return chicken and vegetables and toss only until the chicken is just cooked.
6. Remove from direct heat, fold through basil and serve immediately.

WHAT SUCCESS LOOKS LIKE
Noodles are separate, lightly chewy and dry-glossy. Chicken is juicy rather than cottony; chilli, garlic and basil lead; vegetables, herbs and protein occupy substantial space and no sauce pools.

WATCH OUT FOR
Do not overcook the chicken, overload the wok, use added water routinely, or leave dried noodles to finish cooking by sauce absorption.

STORAGE
Best fresh. Chicken, sauce and vegetables may be staged ahead; boil and rinse noodles shortly before cooking.

Legacy divider: ———

    legacy process-record heading
    Status: verification_pending
    Stage: Researched draft
    Human decision: Marco rejected the prior beef choice as unjustified and approved conversion to chicken. The task requires independent verification after the protein, quantity, vegetable and sauce changes.
    Verification: Not done for this version.

    RESEARCH BASIS
    The prior task established the dried-noodle preparation, one-portion batching, sauce family and Thai-basil compromise from Hot Thai Kitchen and RecipeTin Eats. The migration review rejected beef-gap filling as a valid protein rationale. Chicken breast is retained as a structurally suitable quick-cooking protein, with protein, vegetables, marinade, sauce and water reassessed rather than changed by a blanket multiplier.

    Sources:
    - https://hot-thai-kitchen.com/pad-kee-mao-2/
    - https://www.recipetineats.com/thai-drunken-noodles-pad-kee-mao/
## WHAT TO BUY
[Not specified in legacy source.]
## QUANTITIES
Portions: [Not specified in legacy source.]
[Not specified in legacy source.]
## HOW TO COOK IT
[Not specified in legacy source.]
## WHAT SUCCESS LOOKS LIKE
[Not specified in legacy source.]
---
## PROCESS RECORD
{{MIGRATED_DISH_STATE_BLOCK}}
### Planning brief
Dish candidate: [Thai basil] Pad kee mao — spicy Thai chicken drunken noodles
Purpose: Learn the chilli–garlic–basil noodle system and controlled weak-burner execution, distinct from the sweeter, darker pad see ew profile. Chicken replaces the prior beef version because beef was chosen mainly to fill a cuisine gap rather than for a structural advantage.
Role: main
Priors: None
Locks: Reject the prior beef choice and use chicken; independently verify after the protein, quantity, vegetable and sauce changes.
Exemptions: None
Research emphasis: None
Destination section: Verification Queue — {{TARGET_SECTION_GID}}
### Decisions
### Research basis
Classification: Source-backed dish
No explicit legacy Research basis captured.
### Material changes
