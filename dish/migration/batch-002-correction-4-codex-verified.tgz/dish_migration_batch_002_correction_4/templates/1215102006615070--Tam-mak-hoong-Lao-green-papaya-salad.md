[non-main] Tam mak hoong — Lao green-papaya salad
Lao green-papaya salad
Lao pounded green-papaya salad led by padaek, lime, chilli and garlic, with sweetness restrained. Salted crab is excluded under the project's fixed dietary rules.

WHY COOK IT
Learn padaek-led mortar sequencing, sour-salty-hot balance and controlled bruising of crunchy green papaya.
## WHAT TO BUY
- Green papaya: enough for 250–300g shredded flesh
- Garlic: 1 clove
- Thai chilli: at least 1
- Lime: enough for at least 20ml juice
- Cherry tomatoes: 3
- Long beans: optional
## CHECK BEFORE COOKING
Mae Boonlam pla ra, fish sauce, kapi, palm sugar and tamarind are in Pantry.
## QUANTITIES
Portions: 1 fresh sitting.
- Green papaya: 250–300g, shredded
- Garlic: 1 clove
- Thai chilli: 1 initially
- Palm sugar: start with 5g
- Lime juice: start with 15ml
- Tamarind paste: 1/2 tsp
- Mae Boonlam padaek: start with 10ml
- Fish sauce: start with 5ml
- Kapi: 1/2 tsp
- Cherry tomatoes: 3, halved
- Long beans: optional small handful
## HOW TO COOK IT
1. Pound garlic and chilli roughly.
2. Add palm sugar and break it down.
3. Add lime, tamarind, padaek, fish sauce and kapi; mix into a dressing.
4. Add papaya and optional long beans; pound and fold, bruising without crushing.
5. Add tomatoes last and lightly smash.
6. Taste. Increase padaek first if fermented salt is weak, then lime, chilli or sugar in small measured steps.
## WHAT SUCCESS LOOKS LIKE
Papaya remains crunchy, lightly bruised and separately stranded. Dressing is sour, salty, hot and fermented, with sweetness only rounding the edges and padaek remaining central.

Visual reference — https://vickypham.com/blog/lao-spicy-papaya-salad/ — Observe the mortar sequence, padaek entering the dressing, papaya being folded and bruised, and tomatoes added last. Ignore the larger batch and serving garnishes.
## WATCH OUT FOR
Salted crab and crab paste are omitted for fixed dietary reasons. This is a real flavour compromise: it loses a distinct briny-fermented crab depth, but the padaek-led Lao structure remains intact. Do not start too sweet, underdose acid or crush the papaya.
## STORAGE
Eat immediately; the papaya softens and releases water after dressing.
---
## PROCESS RECORD
{{MIGRATED_DISH_STATE_BLOCK}}
### Planning brief
Dish candidate: Tam mak hoong — Lao green papaya salad
Purpose: Learn padaek-led mortar sequencing, sour-salty-hot balance and controlled bruising of crunchy green papaya.
Role: non-main — salad side; green-papaya salad is not framed as the full meal
Priors: None
Locks: None
Exemptions: None
Research emphasis: None
Destination section: Isan/Lao — {{TARGET_SECTION_GID}}
### Decisions
### Research basis
Classification: Source-backed dish
Source-backed crab-free adaptation.
Construction — Vicky Pham, https://vickypham.com/blog/lao-spicy-papaya-salad/ — 1130g papaya, 45ml padaek, 45ml fish sauce, about 70g sugar, tamarind, garlic and shrimp paste. Scaling to about 275g gives approximately 11ml padaek, 11ml fish sauce and 17g sugar.
Later validation — SBS Food, https://www.sbs.com.au/food/recipe/green-papaya-salad-tham-mak-hoong/1j9irxemk — confirms the padaek-led Lao mortar structure and tasting adjustment.
The lower 5ml fish sauce and 5g sugar are explicit conservative starting points, not claims that the finished salad must stop there.
Legacy material-change narration (not canonical Dish audit history and not Dish evidence):
2026-07-16 — Claude — Delta: replaced a citation that did not actually use padaek, added complete sourcing and one-sitting framing, and retained the conservative tasting anchors.
2026-07-16 — GPT — Verification correction: made the crab omission's flavour cost explicit, reconciled readiness and signed the contained Delta.
### Material changes
