Chicken ramen — existing stock, tare and aroma-oil assembly
existing stock, tare and aroma-oil assembly
A first clear shoyu-style chicken ramen assembled from the existing 900ml chicken stock, an alcohol-free adapted shoyu tare, scallion-chicken aroma oil and alkaline noodles.

WHY COOK IT
Learn ramen as separately controlled broth, tare, aroma oil, noodle and topping components before rebuilding a ramen-specific stock.
## WHAT TO BUY
- Fresh alkaline ramen noodles: 360–390g
- Chicken skin or rendered chicken fat, only if unavailable from the freezer
- Scallions: one bunch
## CHECK BEFORE COOKING
- Taste the existing 900ml scallion-ginger chicken stock cold and hot. If already salted, start below the stated tare dose.
- The tare omits mirin for halal compliance. The replacement restores dilution and sweetness, not mirin's fermented aroma; this is an explicit adaptation.
- Have all bowls, noodles, stock, tare, oil and toppings ready before boiling noodles.
## QUANTITIES
Portions: 3 fresh bowls. Committed protein is limited to broth-borne chicken flavor plus an
unspecified optional sliced-chicken topping; as written this falls well short of the ~50g/portion
target. If a substantial protein portion is wanted, add a stated quantity of sliced chicken (e.g.
~150g/bowl poached breast or thigh) as a non-optional topping; otherwise this dish is accepted as a
component-technique test, not a full-target meal.
- Existing chicken stock: 900ml, 300ml per bowl
- Fresh ramen noodles: 360–390g, 120–130g per bowl

Alcohol-free adapted shoyu tare, small batch:
- Japanese soy sauce: 75g
- Water: 10g
- White sugar: 3g
- Kombu: 2.5g
- Katsuobushi: 2.5g
- Use 20g per bowl initially; up to about 27g after tasting

Scallion-chicken aroma oil:
- Rendered chicken fat: 60ml; neutral oil is an allowed but weaker fallback
- Scallion whites: 20g
- Garlic: 5g
- Use 10ml per bowl initially; up to 15ml

Optional simple toppings:
- Sliced chicken, scallion greens, soft egg, nori or greens
## HOW TO COOK IT
1. For the tare, combine soy sauce, water, sugar and kombu. Refrigerate 6–24 hours.
2. Heat the mixture to about 71°C and hold 10 minutes. Remove kombu, add katsuobushi, raise to about 82°C and hold 10 minutes without boiling; strain and cool.
3. For the aroma oil, heat chicken fat gently with scallion whites and garlic until aromatic and pale-golden, not browned; strain.
4. Taste the hot stock. Warm three bowls.
5. In the first bowl combine 20g tare and 10ml aroma oil, then add 300ml hot stock. Taste before noodles. Increase tare in 2–3g steps or oil in 2ml steps and record the final dose.
6. Cook one noodle portion separately, drain very hard and add immediately. Assemble only restrained toppings.
7. Use the recorded first-bowl dose as the starting point for bowls two and three, correcting only if the stock is not homogeneous.
## WHAT SUCCESS LOOKS LIKE
Clear-to-lightly-cloudy broth remains recognisably chicken-led. Soy seasons without tasting like diluted table soy; a thin fragrant fat sheen adds body without an oil slick. Noodles stay springy and loose in ample broth.

Visual/process reference — https://www.cookwell.com/recipe/chicken-shoyu-ramen — Observe separate clear chicken broth, shoyu tare and rendered scallion-chicken oil assembled in the bowl. Ignore its fresh stock, mirin and exact 350g broth portion.

### DECISION RULES
- Salty but thin: reduce tare; do not fix body with more salt.
- Rich but flat: increase tare before adding toppings.
- Fragrant but greasy: reduce oil.
- Existing stock weak: record it as the stock limitation; do not disguise it with excessive tare.
## WATCH OUT FOR
Neutral oil is a real compromise versus chicken fat: it carries aroma but loses poultry body. The alcohol-free tare is also adapted, not authentic equivalence. Do not boil kombu, brown the oil aromatics hard or let cooked noodles wait.
## STORAGE
Tare and strained oil keep refrigerated separately. Stock may be frozen in bowl portions. Cook noodles only at service.
---
## PROCESS RECORD
{{MIGRATED_DISH_STATE_BLOCK}}
### Planning brief
Dish candidate: Chicken ramen — existing stock, tare and aroma-oil assembly
Purpose: Learn ramen as separately controlled broth, tare, aroma oil, noodle and topping components before rebuilding a ramen-specific stock.
Role: main
Priors: None
Locks: Use the existing 900ml scallion-ginger chicken stock rather than waiting for a new ramen stock. | Avoid overlapping separate Japanese component tasks; keep tare and aroma-oil calibration inside this task.
Exemptions: None
Research emphasis: None
Destination section: Verification Queue — {{TARGET_SECTION_GID}}
### Decisions
Human — Marco: Use the existing 900ml scallion-ginger chicken stock rather than waiting for a new ramen stock.
Human — Marco: Avoid overlapping separate Japanese component tasks; keep tare and aroma-oil calibration inside this task.
### Research basis
Classification: Halal port of Chicken ramen
Human-approved component-assembly test.
Construction — CookWell, https://www.cookwell.com/recipe/chicken-shoyu-ramen — directly supports clear chicken broth, cold-steeped soy/kombu tare finished with bonito, rendered chicken-scallion-garlic oil and bowl assembly. Its dose is 30g tare per 350g unsalted soup, about 8.6%.
Later validation — Way of Ramen, https://wayoframen.com/recipe/10-minute-easy-chuka-soba-recipe/ — supports per-bowl calibration and increasing tare only after tasting.
This task uses 20–27g tare per 300ml soup, 6.7–9%, inside the sourced range. The small tare batch is one quarter of CookWell's soy/kombu/bonito formula; its 10g mirin fraction is replaced by 10g water and 3g sugar as a disclosed halal adaptation.
Legacy material-change narration (not canonical Dish audit history and not Dish evidence):
2026-07-16 — Claude — Delta: consolidated the task around Marco's existing-stock decision but retained an unsupported tare formula and a contradictory title.
2026-07-16 — GPT — Reconstruction: renamed the task, replaced the untraceable tare with a scaled source-anchored alcohol-free adaptation, rebuilt the small aroma-oil batch and reset whole-task verification to Claude.
2026-07-17 — Claude — Local: added the contract-required protein-shortfall disclosure under Portions (no committed protein quantity beyond an optional topping, well under the ~50g target); no other field affected.
### Material changes
