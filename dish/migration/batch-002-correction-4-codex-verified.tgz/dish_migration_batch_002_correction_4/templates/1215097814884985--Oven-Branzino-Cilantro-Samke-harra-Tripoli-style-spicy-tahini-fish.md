Samke harra — Oven; Tripoli-style spicy tahini fish
Oven; Tripoli-style spicy tahini fish
Deferred Levant dish for a future kitchen with an oven.

Planning brief:
- Preferred fish: one small whole branzino, roughly 350–450g.
- Defining structure: whole roasted fish with a spicy tahini-lemon sauce containing garlic, chilli, cumin and fresh cilantro, finished with toasted pine nuts.
- Do not research, verify or adapt this to stovetop equipment now.
- Reopen only when an oven is available; then construct the canonical recipe from direct samke harra sources.

Blocker: oven unavailable.

legacy process-record heading
Stage: Planning — deferred
Human review: Moinudin, complete
Verification: Not applicable while deferred

Human decision — Moinudin: Mark this explicitly as oven-blocked, keep it in the Levant section for later, and do not spend research or verification work on it now.

## WHAT TO BUY
[Not specified in legacy source.]
## QUANTITIES
Portions: [Not specified in legacy source.]
[Not specified in legacy source.]
## HOW TO COOK IT
[Not specified in legacy source.]
## WHAT SUCCESS LOOKS LIKE
[Not specified in legacy source.]
---
## PROCESS RECORD
{{MIGRATED_DISH_STATE_BLOCK}}
### Planning brief
Dish candidate: [Oven] [Branzino] [Cilantro] Samke harra — Tripoli-style spicy tahini fish
Purpose: Preserve a deferred oven-only Tripoli-style samke harra candidate for reconstruction from direct sources when an oven becomes available.
Role: main
Priors: None
Locks: Mark this explicitly as oven-blocked, keep it in the Levant section for later, and do not spend research or verification work on it now.
Exemptions: None
Research emphasis: None
Destination section: Levant — {{TARGET_SECTION_GID}}
### Decisions
### Research basis
Classification: Source-backed dish
No explicit legacy Research basis captured.
### Material changes
