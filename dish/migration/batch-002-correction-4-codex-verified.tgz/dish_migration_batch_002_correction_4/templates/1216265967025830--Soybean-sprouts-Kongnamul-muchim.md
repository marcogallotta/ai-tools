[non-main] Kongnamul-muchim — Soybean sprouts
Soybean sprouts
A light Korean banchan of just-cooked soybean sprouts seasoned with garlic, scallion, sesame, and a restrained amount of young homemade ganjang.

WHY COOK IT
Build namul technique and use young ganjang in a simple exposed seasoning role.
## WHAT TO BUY
- Soybean sprouts: 300g
- Scallions, if low
## CHECK BEFORE COOKING
- Use soybean sprouts, not mung-bean sprouts.
- Use the homemade ganjang only after it has been separately released for food use.
- Keep the seasoning mild; this is one normal banchan, not a comparison exercise.
## QUANTITIES
Portions: [Not specified in legacy source.]
Yield: 3 banchan portions.
- Soybean sprouts: 300g
- Water: 160ml
- Fine salt: 2g for cooking
- Garlic: 5g
- Scallion: 20g
- Toasted sesame oil: 7ml
- Toasted sesame seeds: 6g
- Young homemade ganjang: begin with 5ml, then taste
- Gochugaru: up to 1/2 tsp, optional
## HOW TO COOK IT
1. Put sprouts, water and 2g salt in a lidded pot.
2. Bring to a boil and cook covered for 3–4 minutes without repeatedly opening the lid.
3. Drain immediately and spread briefly so steam escapes.
4. While warm, toss with garlic, scallion, sesame oil and sesame seeds.
5. Add 5ml young ganjang, taste, and add no more unless the sprouts remain clearly underseasoned. Add a little gochugaru only if wanted.
## WHAT SUCCESS LOOKS LIKE
Sprouts are cooked through but retain snap, with long distinct stems and plump bean heads. Seasoning is light, nutty and garlicky, and no watery pool remains.

Visual reference and free video — https://www.maangchi.com/recipe/kongnamul-muchim — Observe cooked sprouts retaining long distinct stems and plump bean heads after draining and hand-mixing, with no liquid pool. This validates intact sprouts and a dry finish only; internal snap must be judged directly. Ignore the source’s fish-sauce seasoning and 10-minute cook.
## WATCH OUT FOR
Do not undercook the bean heads, leave sprouts in hot water, or season heavily enough to obscure the sprouts.
## STORAGE
Refrigerate up to 2 days; best on day one.
---
## PROCESS RECORD
{{MIGRATED_DISH_STATE_BLOCK}}
### Planning brief
Dish candidate: [Soybean sprouts] Kongnamul-muchim
Purpose: Build namul technique and use young ganjang in a simple exposed seasoning role.
Role: non-main — side; kongnamul-muchim is a banchan side
Priors: None
Locks: None
Exemptions: None
Research emphasis: At cooking time, confirm the released homemade ganjang’s salinity and final dose.
Destination section: Korean — {{TARGET_SECTION_GID}}
### Decisions
### Research basis
Classification: Source-backed dish
Source-backed dish.
Construction — Korean Bapsang, https://www.koreanbapsang.com/kongnamul-muchim-seasoned-soybean/ — for 454g sprouts uses 240ml water and a covered 3–4-minute boil without opening the lid, then rapid draining. At 300g this scales to about 160ml water. Seasoning is kept deliberately light so the sprouts remain legible.
### Material changes
