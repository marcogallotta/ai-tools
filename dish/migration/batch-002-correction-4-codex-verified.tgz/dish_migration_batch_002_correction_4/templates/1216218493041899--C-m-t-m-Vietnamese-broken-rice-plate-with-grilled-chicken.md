Cơm tấm — Vietnamese broken-rice plate with grilled chicken
Vietnamese broken-rice plate with grilled chicken
Southern Vietnamese broken-rice plate with lemongrass chicken, fried egg, scallion oil, quick pickles, cucumber and nước chấm. The first halal version omits bì and chả trứng.

WHY COOK IT
Build a composed Vietnamese meal system: rice texture, lemongrass chicken, egg, scallion oil, pickles and nước chấm.
## WHAT TO BUY
[Not specified in legacy source.]
## CHECK BEFORE COOKING
- Marinate chicken for at least 4 hours, preferably overnight.
- Use genuine Vietnamese broken rice.
- Remove excess wet marinade before high-heat cooking.
- Fry eggs and slice cucumber fresh.
- Verify brown sugar in stock for the chicken marinade; white sugar is an acceptable substitute with slightly less skin caramelization.
## QUANTITIES
Portions: 3 substantial plates.

Broken rice:
- Vietnamese broken rice: 360g dry
- Water: start with 420ml after rinsing and a 20-minute soak
- Fine salt: 2g

Lemongrass chicken:
- Chicken breast: 600g, even 1.5–2cm thickness
- Lemongrass tender inner part: 15g
- Shallot: 30g
- Garlic: 12g [approx]
- Fish sauce: 79ml [approx]
- Light soy: 79ml [approx]
- Brown sugar: 73g [approx] (white sugar acceptable substitute)
- Neutral oil: 15ml
- Black pepper: 1 tsp

Quick pickles:
- Carrot: 150g
- Daikon: 150g
- Rice vinegar: 120ml
- Water: 120ml
- White sugar: 50g
- Fine salt: 6g

Scallion oil:
- Scallions: 45g
- Neutral oil: 45ml
- Fine salt: 1g

Nước chấm:
- Fish sauce: start with 45–50ml; increase toward 60ml only after tasting
- Warm water: 120ml
- White sugar: 60g
- Lime juice: 45ml
- Garlic: 10g
- Thai chilli: 1–2

To serve:
- Eggs: 3
- Cucumber: about 300g
- Neutral oil for eggs
## HOW TO COOK IT
1. Rinse and soak rice for 20 minutes, drain, cook with water and salt, then rest covered for 10 minutes. Adjust future batches by 20–30ml for the rice brand.
2. Marinate the chicken, remove excess wet marinade and cook over high heat in batches until browned and just cooked. Rest 5 minutes and slice.
3. Rest the pickles for at least 1 hour.
4. Pour shimmering oil over scallions and salt.
5. Build each plate with one-third of each component. Spoon scallion oil over rice and serve nước chấm separately.
## WHAT SUCCESS LOOKS LIKE
The plate remains composed rather than muddled: a distinct mound of broken rice, browned sliced chicken, crisp-edged egg, fresh cucumber and pickles, with scallion oil on the rice and nước chấm served separately.

Visual reference — https://www.seriouseats.com/vietnamese-recipes-8681536 — Observe the Cơm Tấm image: broken rice forms the centre of a composed plate with grilled protein, egg, cucumber and pickles separately legible. This validates plate architecture and separation. Ignore the pork chop, bì and chả trứng; it does not validate the chicken substitution or omission of those components.
## WATCH OUT FOR
Chicken breast does not reproduce a pork chop's fat or char behaviour. Omitting bì and chả trứng makes this a simplified halal plate. Do not rely on time alone for chicken doneness or drown the composed plate in nước chấm.
## STORAGE
Refrigerate rice and chicken up to 3 days. Store pickles, nước chấm and scallion oil separately. Fry eggs and slice cucumber fresh.
---
## PROCESS RECORD
{{MIGRATED_DISH_STATE_BLOCK}}
### Planning brief
Dish candidate: Cơm tấm — Vietnamese broken-rice plate with grilled chicken
Purpose: Build a composed Vietnamese meal system: rice texture, lemongrass chicken, egg, scallion oil, pickles and nước chấm.
Role: main
Priors: Legacy source claims: Lemongrass ratio correction — the task's original 30g lemongrass per 600g chicken (5g/100g) sits Chicken marinade seasoning correction (garlic/sugar/fish sauce/soy), Delta, 2026-07-17 (Claude) — the
Locks: Approved dropping bì and chả trứng entirely after asking whether honest omission was preferable to faking them.
Exemptions: None
Research emphasis: None
Destination section: Verification Queue — {{TARGET_SECTION_GID}}
### Decisions
Human — Marco: Approved dropping bì and chả trứng entirely after asking whether honest omission was preferable to faking them.
### Research basis
Classification: Halal port of Cơm tấm
Halal port of cơm tấm, human-approved.
Construction update — The approved omission of bì and chả leaves a coherent chicken plate: broken rice, grilled chicken,
đồ chua, raw vegetables, scallion oil and nước chấm. Cook rice to package ratio because fracture
size varies; use the researched chicken marinade and standard nước chấm above. Bloom scallion off
heat in hot neutral oil. Research is sufficient; rice hydration is product calibration.
Sources: <https://theravenouscouple.com/2009/06/com-tam-tau-hu-ky-suon-bi-broken-rice-with-bean-curd-wrapped-shrimp-pork-chop-and-pork-skin.html>
Lemongrass ratio correction — the task's original 30g lemongrass per 600g chicken (5g/100g) sits
well above comparable lemongrass-chicken recipes. Nom Nom Paleo's Vietnamese Lemongrass Chicken uses
3 tablespoons minced lemongrass (~18–21g [approx], at ~6–7g/tbsp) for 8 bone-in, skin-on chicken
thighs (~3.5 lb / ~1588g), ~1.13–1.32g/100g [approx]. Gimme Some Oven's version uses 2 stalks
lemongrass, tender white parts only (~20–30g [approx]) for 2 lb (907g) boneless chicken,
~2.2–3.3g/100g [approx]. Together these bracket a real-world range of roughly 1.1–3.3g/100g,
comfortably below the task's original 5g/100g. Corrected to 15g lemongrass per 600g chicken
(2.5g/100g), inside this range.
Sources: <https://nomnompaleo.com/post/132500915613/vietnamese-lemongrass-chicken>,
<https://www.gimmesomeoven.com/vietnamese-lemongrass-chicken/>
Chicken marinade seasoning correction (garlic/sugar/fish sauce/soy), Delta, 2026-07-17 (Claude) — the
task's non-lemongrass seasoning quantities were originally attributed to hungryhuy.com's bún thịt
nướng pork marinade page, but that source's marinade (scaled ~0.882x from ~680g pork to 600g chicken)
gives garlic ~21g, sugar ~39g, fish sauce ~17ml — none matching the task's stated 15g/30g/30ml, and
that source has no light soy at all. That attribution was wrong; the figures did not derive from the
cited page. Replaced with The Seasoned Wok's "Com Ga Nuong" (grilled lemongrass chicken over rice, the
direct sister dish to this one — the same page explicitly names Cơm Tấm Gà Nướng as its broken-rice
variant and states the marinade also works for pork chops, bridging the task's pork-to-chicken
substitution). Source marinade for 1 lb (454g) boneless, skin-on chicken thighs: 3 cloves garlic
(~9g [approx], at ~3g/clove), 4 tbsp brown sugar (~55g, at ~13.75g/tbsp), 4 tbsp fish sauce (60ml),
4 tbsp light soy sauce (60ml), 1 tbsp oil (15ml; oil left unchanged as out of scope). Scale factor
600/454 = 1.3216. Scaled: garlic 12g [approx] (was 15g), sugar 73g [approx] brown sugar (was 30g
white — white sugar kept as an explicit fallback since the rest of the task otherwise uses white
sugar), fish sauce 79ml [approx] (was 30ml), light soy 79ml [approx] (was 15ml, previously
unsourced). This roughly doubles-to-triples fish sauce, soy and sugar versus the prior figures; judged
plausible rather than an error because the source is a full wet-immersion marinade (marinade:meat
~38% by weight) and the task's own method already wipes excess marinade before high-heat cooking, i.e.
it was already designed for a strong marinade that isn't fully absorbed. Marco confirmed this reads as
legit given the wet-marinade mechanism. Checked a second candidate (vietfoodnet.com's "Ga Nuong Sa")
but rejected it as a ratio anchor: its photos are credited to other sites (Allrecipes, Pups with
Chopsticks) with no identifiable author, indicating derivative/aggregator content rather than a
primary tested recipe.
Source: <https://www.theseasonedwok.com/com-ga-nuong-lemongrass-chicken/>
Legacy material-change narration (not canonical Dish audit history and not Dish evidence):
2026-07-17, Claude, Delta — Corrected chicken marinade (garlic, sugar, fish sauce, light soy) to a
properly sourced anchor after the prior citation was found not to support the stated figures; see
Research basis. Added a CHECK BEFORE COOKING line on brown-sugar stock/substitution. Removed legacy
Ready to shop/Initial construction fields at this touch per contract. Contained to the Lemongrass
chicken ingredient block, one CHECK BEFORE COOKING line, and this Research basis entry; rice, pickles,
scallion oil, nước chấm, method, portions, and the Human-approved bì/chả omission are unaffected.
Verification reset to require GPT (opposite family from this edit) under contract a0a390b. Not yet
verified.
### Material changes
