[non-main] Sesame spinach — homemade Chinese sesame-paste dressing
homemade Chinese sesame-paste dressing
Blanched spinach dressed with a creamy, savoury-tart homemade Chinese sesame-paste sauce.

WHY COOK IT
Use the homemade sesame paste in a normal cold side dish and judge whether its roast, bitterness, salt and dilution are balanced in practical eating—not as part of a multi-branch condiment experiment.


WHAT TO BUY
- Spinach: 500–600 g

CHECK BEFORE COOKING
- Confirm the homemade Chinese sesame paste is fresh enough to judge. If stale or harsh, stop rather than masking it.
- Keep the dressed spinach separate until serving; it will shed water if held.

QUANTITIES
Three side portions.
- Spinach: 500–600 g
- Homemade Chinese sesame paste: 45 g
- Warm water: begin with 35 ml; add only to a thick, pourable texture
- Light soy: 12 ml
- Chinkiang vinegar: 12 ml
- White sugar: 3 g
- Garlic: 1 large clove, finely grated immediately before dressing
- Toasted sesame oil: 6 ml
- Fine salt: only after tasting

HOW TO COOK IT
1. Whisk sesame paste with warm water until completely smooth before adding other seasonings.
2. Add soy, vinegar, sugar, garlic and sesame oil; taste before adding salt.
3. Blanch spinach briefly until just collapsed, shock cold, squeeze very dry and cut into manageable lengths.
4. Dress immediately before serving, using only enough sauce to coat without a watery ring.

WHAT SUCCESS LOOKS LIKE
Spinach remains green and distinct. The dressing is creamy and clings cleanly, with deep sesame flavour but no burnt bitterness, harsh raw garlic or separated water.

DECISION RULES
- Paste remains stiff or grainy: add warm water 5 ml at a time before changing seasoning.
- Dressing tastes flat: adjust vinegar or soy in 2 ml increments, not both together.
- Spinach sheds water: squeeze again before adding more sauce.

WATCH OUT FOR
Do not treat this as evidence about chilli oil, cucumber or tofu. Do not overdress or hold mixed for later sittings.

STORAGE
Store cooked squeezed spinach and dressing separately for up to 2 days. Dress each portion shortly before eating.

Legacy divider: ———

    legacy process-record heading
    Status: verification_pending
    Stage: Researched draft
    Human decision: Marco rejected the previous three-branch calibration as an unsigned, overcomplicated experiment and approved simplification into one normal dish. Sesame spinach was retained because the prior task explicitly identified homemade sesame-paste quality as the useful question.
    Verification: Not done for this simplified version.

    RESEARCH BASIS
    The retained spinach construction comes from the prior task’s cited Chinese home-cooking reference. The cucumber and tofu branches, chilli-oil comparison, and experiment claims were removed.

    Source:
    - https://m.xiachufang.com/recipe/107602298/
## WHAT TO BUY
[Not specified in legacy source.]
## QUANTITIES
Portions: [Not specified in legacy source.]
[Not specified in legacy source.]
## HOW TO COOK IT
[Not specified in legacy source.]
## WHAT SUCCESS LOOKS LIKE
[Not specified in legacy source.]
---
## PROCESS RECORD
{{MIGRATED_DISH_STATE_BLOCK}}
### Planning brief
Dish candidate: Sesame spinach — homemade Chinese sesame-paste dressing
Purpose: Use the homemade sesame paste in a normal cold side dish and judge whether its roast, bitterness, salt and dilution are balanced in practical eating—not as part of a multi-branch condiment experiment.
Role: non-main — side dish; spinach with dressing is a side rather than a full meal
Priors: None
Locks: Reject the previous three-branch calibration and simplify this into one normal sesame-spinach dish.
Exemptions: None
Research emphasis: None
Destination section: Verification Queue — {{TARGET_SECTION_GID}}
### Decisions
### Research basis
Classification: Source-backed dish
No explicit legacy Research basis captured.
### Material changes
