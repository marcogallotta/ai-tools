Bò kho — Vietnamese lemongrass beef stew with noodles
Vietnamese lemongrass beef stew with noodles
Southern Vietnamese lemongrass beef stew with tomato, carrot, warm spice and fish sauce, served over rice noodles. It is brothy and aromatic, not a dark caramel kho and not phở.

WHY COOK IT
Add a Vietnamese beef stew and noodle reference point. The Instant Pot version tests lemongrass-spice beef extraction while keeping the hot-season workflow practical.
## WHAT TO BUY
[Not specified in legacy source.]
## CHECK BEFORE COOKING
- Marinate the beef for 30–60 minutes.
- Batch the stew base and cook noodles fresh.
- Pressure-cooker liquid is independent from stovetop formulas.
- Carrots are added after the pressure cycle, not pressure-cooked with the beef — see Decisions.
- Annatto is useful but non-blocking; omit if unavailable.
- This counts as the week's red-meat dish.
## QUANTITIES
Portions: 3 substantial portions.
- Beef chuck: 900g, 4cm cubes
- Fish sauce: 35ml, divided
- Soy sauce: 15ml
- White sugar: 6g [approx] (substitute for source's brown sugar; scaled to The Woks of Life's ratio)
- Five-spice powder: 1 tsp
- Black pepper: 1 tsp
- Lemongrass: 3 stalks, inner part minced and outer parts bruised
- Garlic: 4 cloves
- Ginger: 20g
- Onion: 200g
- Tomato paste: 50g [approx] (matched to primary source's ratio; canned tomatoes dropped, see Research basis)
- Star anise: 2
- Cinnamon: 1 small stick
- Annatto oil: optional 15ml
- Beef stock or water: up to 500ml, only as needed
- Carrots: 350g
- Rice noodles: 300g dry
- Scallions and cilantro
- Optional lime and chilli
## HOW TO COOK IT
1. Marinate beef with 20ml fish sauce, sugar, five-spice, pepper, minced lemongrass and half the garlic.
2. Brown beef in batches and remove.
3. Soften onion, remaining garlic and ginger. Fry tomato paste for 1 minute.
4. Return beef with soy sauce, bruised lemongrass, star anise, cinnamon and only enough liquid for the pressure-cooker base, up to 500ml.
5. Pressure-cook on high for 30 minutes; natural release for 15 minutes, then vent.
6. If beef remains tight, pressure-cook another 5–10 minutes.
7. Remove whole spices and bruised lemongrass.
8. Add carrots and simmer uncovered until tender while the broth reduces but stays noodle-soup-like.
9. Add remaining fish sauce after final concentration is set. Adjust salt, sweetness and water.
10. Cook 100g noodles fresh per portion and serve with beef, carrots and broth.
## WHAT SUCCESS LOOKS LIKE
Beef is tender but not shredded. The red-gold broth flows freely around large intact beef and carrot pieces, remains lemongrass-forward and warm-spiced, and is still brothy enough for noodles.

Visual reference — https://www.simplyrecipes.com/for-better-beef-stew-make-it-the-vietnamese-way-8759816 — Observe the bò-kho image for red-gold broth flowing around intact beef and carrots rather than a dark sticky kho. This validates brothy identity, colour and component integrity. Ignore its exact recipe, stovetop method and serving choice; it does not validate pressure timing or noodles.
## WATCH OUT FOR
Do not force all 500ml liquid into the pot, season fully before reduction, or store noodles in stew. Do not pressure-cook carrots with the beef — see Decisions for why.
## STORAGE
Refrigerate the stew base up to 3 days or freeze portions. Cook noodles and prepare garnishes fresh.
---
## PROCESS RECORD
{{MIGRATED_DISH_STATE_BLOCK}}
### Planning brief
Dish candidate: Bò kho — Vietnamese lemongrass beef stew with noodles
Purpose: Add a Vietnamese beef stew and noodle reference point. The Instant Pot version tests lemongrass-spice beef extraction while keeping the hot-season workflow practical.
Role: main
Priors: Legacy source references prior related work: no canned tomatoes), soy sauce (1 tbsp/15ml, present — task previously omitted this with no basis; Canned chopped tomatoes previously listed in this task's ingredients had no support in any of the
Locks: Approved Instant Pot tenderizing followed by open reduction, connecting the method to his own practice of reducing tagine openly after braising. | Carrot timing — carrots are added after the pressure cycle (late-carrot), not pressure-cooked with the beef. The primary/controlling source (pressurecookrecipes.com) pressure-cooks carrots together with the beef in one 30-32 min HP + 10 min NR cycle; two secondary sources (Hungry Huy, The Woks of Life) add carrots late, but only in stovetop atmospheric-simmer contexts, not under pressure. This departs from the primary source deliberately: pressure cooking runs far hotter than atmospheric simmering (~121°C vs ~100°C), and carrot chunks in an Instant Pot typically go from firm to mush in 2-5 minutes at high pressure — a 30+ minute HP cycle is 6-15x longer than carrots need, so pressure-cooking them the full cycle would very likely produce mush well before this task's own stated success criterion of "intact beef and carrot pieces" is met. Late addition costs one extra step and directly protects that criterion.
Exemptions: None
Research emphasis: None
Destination section: Vietnamese — {{TARGET_SECTION_GID}}
### Decisions
Human — Marco: Approved Instant Pot tenderizing followed by open reduction, connecting the method to his own practice of reducing tagine openly after braising.
Human — Marco: Carrot timing — carrots are added after the pressure cycle (late-carrot), not pressure-cooked with the beef. The primary/controlling source (pressurecookrecipes.com) pressure-cooks carrots together with the beef in one 30-32 min HP + 10 min NR cycle; two secondary sources (Hungry Huy, The Woks of Life) add carrots late, but only in stovetop atmospheric-simmer contexts, not under pressure. This departs from the primary source deliberately: pressure cooking runs far hotter than atmospheric simmering (~121°C vs ~100°C), and carrot chunks in an Instant Pot typically go from firm to mush in 2-5 minutes at high pressure — a 30+ minute HP cycle is 6-15x longer than carrots need, so pressure-cooking them the full cycle would very likely produce mush well before this task's own stated success criterion of "intact beef and carrot pieces" is met. Late addition costs one extra step and directly protects that criterion.
### Research basis
Classification: Intentional test dish, human-approved
Intentional test dish, human-approved.
Construction update — A tested Instant Pot construction validates beef, lemongrass, star anise/cinnamon,
tomato, and open reduction. Brown in batches, fully deglaze, use minimum thin liquid to reach pressure.
Noodles, baguette and rice are legitimate services. Pressure time remains cut-size calibration.
Sources: <https://www.pressurecookrecipes.com/instant-pot-bo-kho/> — Construction, direct read (raw
fetch, confirmed against reader-facing ingredients/instructions). Confirms tomato paste (3 tbsp/50ml,
no canned tomatoes), soy sauce (1 tbsp/15ml, present — task previously omitted this with no basis;
restored), fish sauce, no five-spice, no annatto, no added sugar. Also confirms carrots are layered
on the raw beef and pressure-cooked together in the same 32 min HP + 10 min NR cycle — this task's
late-carrot instruction departs from this source; see Decisions above for the reasoning and Marco's
approval.
Two independent secondary sources confirm late-carrot timing, but only in a stovetop-simmer context,
not pressure cooking:
- <https://www.hungryhuy.com/bo-kho-recipe-vietnamese-beef-stew/> — Later validation, direct read
  (raw fetch). Adds carrots in the final 10 minutes of a 60-90 min atmospheric simmer, to prevent
  overcooking. No five-spice, no annatto, no added sugar; uses tomato paste (2 tbsp) and soy sauce
  (2 tbsp + 2 tbsp dark soy).
- <https://thewoksoflife.com/bo-kho-spicy-vietnamese-beef-stew/> — Later validation, direct read
  (raw fetch). Adds carrots after 1 hour of a ~1h40 atmospheric simmer. Also the source for this
  task's five-spice powder (2.5 tsp, marinade), brown sugar (1.5 tsp, marinade — task uses white
  sugar as an available substitute, scaled down to 6g to match this source's ratio for a comparable
  beef weight), and optional ground annatto (1 tsp — task substitutes annatto oil for the powder
  form, same coloring purpose, disclosed here). Neither secondary source addresses carrot handling
  under pressure specifically — see Decisions above for how this task resolves that gap.
Canned chopped tomatoes previously listed in this task's ingredients had no support in any of the
three sources reopened here (all three use tomato paste only) and have been dropped. Tomato paste
increased from 30g to 50g to match the primary source's ratio, since removing the canned tomatoes
would otherwise leave the dish under-tomatoed relative to the source actually driving construction.
Legacy material-change narration (not canonical Dish audit history and not Dish evidence):
2026-07-17, Claude, Delta — Dropped unsourced canned chopped tomatoes; increased tomato paste
30g->50g to match primary-source ratio; restored omitted soy sauce (15ml, all three sources use it);
reduced sugar 12g white->6g white to match The Woks of Life's scaled ratio and disclosed it as a
brown-sugar substitute; disclosed five-spice and annatto-oil sourcing to The Woks of Life as a
secondary-source regional variant, not present in the primary source; disclosed and resolved the
primary source's carrot-pressure-cooking conflict with this task's late-carrot instruction, previously
concealed by citing only the agreeing secondary sources — Marco confirmed late-carrot (Route B),
recorded in Decisions with the food-science reasoning. Removed legacy Ready to shop/Initial
construction fields at this touch per contract. Contained to the seasoning list, carrot-timing
Decision, and Research basis disclosure; core method (Instant Pot tenderize + open reduction) and
portions unaffected. Verification reset to require GPT (opposite family from this edit) under contract
a0a390b. Not yet verified.
### Material changes
