Labu kuning masak lemak — pumpkin season; A Malay-style pumpkin side in which dense squash is cooked until tender but intact, then finished in a fragrant coconut, turmeric, chilli and lemongrass gravy. This first baseline omits anchovy, dried shrimp and shrimp paste and does not claim to reproduce their savoury depth.
pumpkin season; A Malay-style pumpkin side in which dense squash is cooked until tender but intact, then finished in a fragrant coconut, turmeric, chilli and lemongrass gravy. This first baseline omits anchovy, dried shrimp and shrimp paste and does not claim to reproduce their savoury depth.

WHY COOK IT
Use autumn pumpkin to learn how squash sweetness, starch and water content change a coconut gravy without allowing the pieces to collapse.
## WHAT TO BUY
- Pumpkin or dense winter squash: 700–900g whole, enough for 550g peeled flesh
- Full-fat unsweetened coconut milk: 400ml
- Shallots: 80g
- Lemongrass: 1 stalk
- Fresh red chilli: 1, about 15g
## CHECK BEFORE COOKING
- Choose a dense squash that holds a clean cut. Postpone rather than use a watery, fibrous or flavourless specimen.
- Confirm garlic, turmeric, neutral oil, salt and sugar from live stock.
- The baseline is intentionally free of anchovy, dried shrimp and shrimp paste. Do not add an unverified substitute merely to chase umami.
- Measure 150ml initial water and 100ml reserve separately. Do not pour in the reserve unless the pumpkin needs it to soften.
## QUANTITIES
Portions: 3 side portions with rice.
- Pumpkin or winter-squash flesh: 550g, peeled and cut into 3–4cm chunks
- Shallots: 80g
- Garlic: 8g
- Fresh turmeric: 10g, or ground turmeric: 1 tsp
- Fresh red chilli: 15g, roughly chopped
- Optional bird's-eye chilli: 1, only if the long chilli is very mild
- Lemongrass: 1 stalk, bruised
- Neutral oil: 15ml
- Water: 150ml initially
- Water reserve: 100ml
- Full-fat unsweetened coconut milk: 400ml
- Fine salt: begin with 5g
- White sugar: up to 5g, only after tasting the cooked pumpkin
## HOW TO COOK IT
1. Pound or blend shallots, garlic, turmeric and chilli with only enough of the measured initial water to move the blades. Keep the paste slightly textured rather than turning it into thin soup.
2. Heat the oil in a wide pot over medium heat. Fry the paste for 3–5 minutes, stirring, until its colour deepens slightly, the raw shallot smell is gone and it smells fully aromatic. Do not brown it hard.
3. Add the pumpkin, bruised lemongrass, remaining initial water and starting salt. Fold to coat, cover and simmer gently for 8 minutes.
4. Check the pumpkin. Continue covered in 2–3 minute intervals until a skewer enters with some resistance and the centres are nearly tender. Add the measured water reserve only in 25ml increments if the pot is drying before that point.
5. Pour in the coconut milk and stir gently. Bring only to a gentle simmer; do not boil hard. Cook uncovered for 4–6 minutes until the pumpkin is tender through but still lifts intact and the gravy lightly coats a spoon.
6. Taste before adding sugar. Correct salt first, then add sugar only if the squash itself is flat. Remove the lemongrass and rest 5 minutes before serving.
## WHAT SUCCESS LOOKS LIKE
Pumpkin pieces are tender and naturally sweet but retain clean edges. The gravy is yellow, coconut-rich, lightly spicy and fluid enough to spoon, with no raw paste taste and no split, greasy boil. The absence of seafood umami should read as a simpler vegetable baseline, not be hidden.

Visual reference — https://thelynalina.blogspot.com/2020/06/masak-lemak-labu-malay-style-.html — Observe intact pumpkin pieces in flowing yellow coconut gravy. Ignore its anchovies and exact coconut quantity.
## WATCH OUT FOR
Do not simmer raw paste directly in coconut milk, boil the coconut hard, add all reserve water automatically, cut the pumpkin small or keep cooking after the centres are tender.
## STORAGE
Refrigerate up to 3 days. Reheat gently without boiling; add a splash of water only if the gravy has tightened.
---
## PROCESS RECORD
{{MIGRATED_DISH_STATE_BLOCK}}
### Planning brief
Dish candidate: Labu kuning masak lemak — pumpkin in coconut-turmeric gravy
Purpose: Use autumn pumpkin to learn how squash sweetness, starch and water content change a coconut gravy without allowing the pieces to collapse.
Role: main
Priors: None
Locks: Replace the seasonal pumpkin placeholder with labu masak lemak.
Exemptions: None
Research emphasis: None
Destination section: Verification Queue — {{TARGET_SECTION_GID}}
### Decisions
Human — Marco: Replace the seasonal pumpkin placeholder with labu masak lemak.
### Research basis
Classification: Source-backed dish
Intentional anchovy-free Malay pumpkin masak lemak baseline; the named dish and its defining pumpkin-coconut-turmeric mechanism are directly supported, while the seafood-free flavour balance remains a disclosed first-run adaptation.
Construction — Lyn's Homelicious, “Masak Lemak Labu Mudah,” https://thelynalina.blogspot.com/2020/06/masak-lemak-labu-malay-style-.html — fries a shallot, garlic, chilli, turmeric and anchovy paste for about two minutes; cooks pumpkin in water until soft but not mushy; then adds coconut cream for another five minutes. This directly controls the repaired cooking order and tender-but-intact endpoint. Its anchovies are omitted under the chosen baseline.
Construction — Cook with Ipohbunny, “Gulai Labu,” https://www.cookwithipohbunny.com/recipe-gulai-labu-pumpkin-curry/ — uses pumpkin, shallot, turmeric, lemongrass, chilli, coconut and water, with dried prawn or salted fish for savoury depth. It independently supports the ingredient family and confirms that the omitted seafood normally contributes more than saltiness.
Construction — The Kampung Vegan, “Vegan Masak Lemak Cili Padi,” https://www.thekampungvegan.com/recipes/vegan-masak-lemak-cili-padi — fries the paste until dry and aromatic, cooks vegetables in measured water, and adds coconut cream only after the vegetables are cooked. It supports the seafood-free process branch but uses mushroom seasoning/MSG and a different vegetable mix, so it is process support rather than a pumpkin ratio anchor.
Ratio note: the accessible direct recipes vary widely in pumpkin size, water and coconut concentration and do not provide a clean common normalization for this exact thick-gravy target. The task therefore preserves 550g pumpkin and 400ml coconut milk as an explicit first-run project calibration, with staged water and a recorded risk of either excess dilution or excessive richness.
Legacy agent construction/provenance (not Dish evidence):
Agent — GPT: Keep the first baseline free of anchovy, dried shrimp and shrimp paste and disclose the missing savoury depth instead of pretending salt or sugar replaces it.
Legacy material-change narration (not canonical Dish audit history and not Dish evidence):
2026-07-17 — GPT — Reconstruction. Removed the unsupported raw-paste-in-coconut method; restored frying the paste, staged the water, moved coconut to the finishing phase, removed ginger from the baseline, made the seafood omission and flavour loss explicit, and reset whole-task verification to Claude.
### Material changes
