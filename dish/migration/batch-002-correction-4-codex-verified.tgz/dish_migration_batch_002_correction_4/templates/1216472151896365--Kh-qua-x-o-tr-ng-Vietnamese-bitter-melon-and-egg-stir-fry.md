[non-main] Khổ qua xào trứng — Vietnamese bitter melon and egg stir-fry
Vietnamese bitter melon and egg stir-fry
Thin-sliced bitter melon is salted briefly, rinsed, then stir-fried with garlic and egg so the bitterness remains readable but not punishing.

WHY COOK IT
Use a seasonal Vietnamese vegetable side to learn bitterness management directly: slice thickness, salt-rest and rinse, egg as softener, and the point at which bitterness remains characteristic without becoming harsh.
## WHAT TO BUY
- Bitter melon: 1–2 medium, about 300–400g total
- Eggs: 3
- Scallions or garlic chives
## CHECK BEFORE COOKING
- Use firm, fresh bitter melon; avoid yellowing, soft or damaged fruit.
- This is a vegetable side, not a solo main.
- Omit dried shrimp for the first clean bitterness baseline.
- Do not remove all bitterness; the point is controlled bitterness, not disguise.
## QUANTITIES
Portions: 2 generous vegetable-side portions.
- Bitter melon: 300g after trimming, halved, seeded and sliced 2–3mm
- Fine salt for pre-salting: 3g
- Eggs: 3 large
- Garlic: 8g, minced
- Fish sauce: 8–10ml total
- White sugar: 2g
- Neutral oil: 20ml, divided
- Scallion: 20g, sliced
- Black pepper: generous finish
## HOW TO COOK IT
1. Halve the bitter melon, scrape out seeds and soft white pith, then slice 2–3mm thick.
2. Toss with 3g salt for 20–30 minutes. Rinse briefly and drain or squeeze well.
3. Beat eggs with 3ml fish sauce, sugar and black pepper.
4. Soft-scramble eggs in half the oil; remove while still tender.
5. Add remaining oil, garlic and scallion whites; fry briefly.
6. Add bitter melon and stir-fry until bright and just tender, about 3–5 minutes.
7. Season with remaining fish sauce, tasting before adding all of it.
8. Return egg and fold gently. Finish with scallion greens and black pepper.
9. Eat one portion fresh. Cool the second promptly in a shallow container and refrigerate within 2 hours.
## WHAT SUCCESS LOOKS LIKE
Bitter melon stays recognisably bitter but clean rather than medicinal. Egg is soft and rounds the dish without hiding it. The pan is dry rather than watery.
## WATCH OUT FOR
Do not slice too thick, skip draining, overcook the eggs, or add strong sauces that hide the bitter melon. The refrigerated portion will soften slightly; treat that as a quality tradeoff, not a safety defect.
## STORAGE
Best fresh, but a second side portion is reasonable. Refrigerate promptly in a shallow covered container and use within 3 days. Reheat gently only until hot, or eat at room temperature after safe refrigeration; do not repeatedly reheat.
---
## PROCESS RECORD
{{MIGRATED_DISH_STATE_BLOCK}}
### Planning brief
Dish candidate: Khổ qua xào trứng — Vietnamese bitter melon and egg stir-fry
Purpose: Use a seasonal Vietnamese vegetable side to learn bitterness management directly: slice thickness, salt-rest and rinse, egg as softener, and the point at which bitterness remains characteristic without becoming harsh.
Role: non-main — side dish; bitter melon and egg is framed as a vegetable side
Priors: None
Locks: use this as a vegetable side, not one large solo meal. Two or three side portions are acceptable only if refrigeration is sensible.
Exemptions: None
Research emphasis: None
Destination section: Verification Queue — {{TARGET_SECTION_GID}}
### Decisions
Human — Marco: use this as a vegetable side, not one large solo meal. Two or three side portions are acceptable only if refrigeration is sensible.
### Research basis
Classification: Source-backed dish
Vicky Pham supports salted sliced bitter melon, eggs, fish sauce, sugar, garlic, scallion or chives and black pepper: https://vickypham.com/blog/vietnamese-bitter-melon-and-egg/
Delightful Plate supports khổ qua/mướp đắng xào trứng as a lightly seasoned Vietnamese side: https://delightfulplate.com/vietnamese-bitter-melon-egg-stir-fry/
Wandering Chopsticks supports a simple salted bitter melon, egg, fish sauce and garlic version: https://wanderingchopsticks.blogspot.com/2014/08/o-kho-qua-xao-trung-vietnamese-bitter.html
Food-safety boundary: USDA-FSIS advises cooling leftovers promptly, refrigerating within two hours and using cooked egg dishes/most leftovers within 3–4 days.
Legacy agent construction/provenance (not Dish evidence):
Agent — GPT: set the current 300g bitter-melon/3-egg construction to two generous side portions. USDA-FSIS guidance supports prompt cooling and 3–4 refrigerated days for cooked egg dishes and most leftovers; the task uses a conservative three-day quality boundary.
Legacy material-change narration (not canonical Dish audit history and not Dish evidence):
2026-07-30 — Removed the solo-main branch; fixed the dish at two generous vegetable-side portions and added an explicit prompt-cooling, three-day refrigerated plan.
### Material changes
