Joojeh — Persian saffron-lemon-yogurt chicken kebab
Persian saffron-lemon-yogurt chicken kebab
Boneless chicken thigh marinated in saffron, yogurt, onion and lemon, then pan-seared as an explicit no-charcoal adaptation.

WHY COOK IT
Learn a central Persian kebab flavour system and complete the three-day koobideh/joojeh comparison without risking both proteins in one first cook.
## WHAT TO BUY
- Boneless skinless chicken thigh: 550g
- Full-fat yogurt: 120ml
- Saffron threads: 1/2 tsp
- Onion: 1/2 medium
- Lemon or lime juice: 22ml - check stock first, buy fresh if low
## QUANTITIES
Portions: 3 portions cooked from one marinated batch.
- Boneless skinless chicken thigh: 550g, cut into even chunks
- Full-fat yogurt: 120ml
- Onion: 1/2 medium, grated
- Olive oil: 25–30ml
- Lemon or lime juice: 22ml
- Saffron threads: 1/2 tsp, bloomed in 20ml hot water
- Fine salt: about 3g
- Black pepper: about 1/2 tsp

Estimated [approx]: 550g boneless thigh / 3, cooked yield ~75%, gives roughly 236 kcal / 36g protein per portion from chicken; marinade/oil add roughly 110 kcal. With the rice accompaniment (~230 kcal / 4g protein), total is approximately 570-600 kcal / ~40g protein per portion - short of the ~800kcal/50g target, stated as a shortfall per contract; mast-o-khiar side on Day 3 adds further protein/kcal, uncosted here.
## HOW TO COOK IT
1. Mix yogurt, onion, oil, citrus, saffron water, salt and pepper.
2. Coat chicken and marinate for 6–8 hours or overnight.
3. Remove excess wet marinade so the chicken can brown.
4. Pan-sear the full batch in uncrowded rounds over medium-high heat in the 24cm non-stick, turning for even browning, until safely cooked and still juicy. Judge by piece thickness and doneness rather than a fixed clock.
5. Serve one portion immediately with 1 medium flatbread (~90g) or ~180g cooked basmati rice (~100g dry, in stock). Cool the remaining cooked chicken promptly and refrigerate for later portions; Day 3 may pair with koobideh and mast-o-khiar.
## WHAT SUCCESS LOOKS LIKE
Chicken pieces remain plump and moist, with a clear golden saffron colour and browned edges. Yogurt solids may caramelise in small patches but do not form a black crust or wet coating that prevents browning.

Visual sourcing gap — strong Persian references checked use charcoal grilling or broiling, and those heat-source differences overlap the colour, browning and moisture boundary this pan adaptation needs to validate. Photograph wiped marinated pieces, the first browned face and a cut centre.
## WATCH OUT FOR
Pan-searing loses charcoal aroma and skewer-roasted character. Do not crowd the pan or leave a heavy wet coating. Cook the full marinated batch on the first day rather than holding citrus-yogurt-marinated raw chicken across several days.
## STORAGE
Cool cooked leftovers promptly and refrigerate up to 3 days. Reheat gently once, or serve at room temperature if preferred.
---
## PROCESS RECORD
{{MIGRATED_DISH_STATE_BLOCK}}
### Planning brief
Dish candidate: Joojeh — Persian saffron-lemon-yogurt chicken kebab
Purpose: Learn a central Persian kebab flavour system and complete the three-day koobideh/joojeh comparison without risking both proteins in one first cook.
Role: main
Priors: None
Locks: Approved pan-searing without charcoal, using the same practical logic as bún chả.
Exemptions: None
Research emphasis: None
Destination section: Persian — {{TARGET_SECTION_GID}}
### Decisions
Human — Marco: Approved pan-searing without charcoal, using the same practical logic as bún chả.
Human — Marco: 2026-07-31 — Cook the entire marinated batch on the first day; do not hold or freeze raw marinated portions for later service.
### Research basis
Classification: Intentional test dish, human-approved
Intentional test dish, human-approved.
Construction update — Yogurt is a documented joojeh branch rather than an invented addition. A published 900g-thigh formula uses 200g yogurt, 45g lemon, 30g oil, onion and saffron; the task's 550g chicken, 120ml yogurt and 22ml citrus are proportionate. Marco approved pan-searing as the explicit no-charcoal adaptation.
Sources: <https://www.bonappetit.com/recipe/joojeh-kebab>, <https://persianmama.com/joojeh-kabob-grilled-chicken-thighs/>
Legacy agent construction/provenance (not Dish evidence):
Agent — Codex: Reconciled the construction update with the recorded Human Review result and removed stale pending/rejected branches from the process record.
### Material changes
