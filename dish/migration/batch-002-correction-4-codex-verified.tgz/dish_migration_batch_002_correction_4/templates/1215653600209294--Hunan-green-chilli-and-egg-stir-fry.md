[non-main] Hunan green-chilli and egg stir-fry — peak long green chillies
peak long green chillies
Blistered long green chillies stir-fried with soft egg, garlic and scallion. This is one normal seasonal vegetable-and-egg dish, not a controlled plain-versus-aromatic experiment.

WHY COOK IT
Use genuinely good peak Italian long green chillies or homegrown Hangjiao as a chilli-as-vegetable dish and learn the balance between blistered chilli flesh and soft egg.
## WHAT TO BUY
- Long green chillies: 250g, only if no meaningful homegrown Hangjiao harvest is available
- Eggs: 4
- Scallion: 1
## CHECK BEFORE COOKING
- Use genuinely good peak-season long green chillies. Postpone if they are wrinkled, hollow, aroma-less, excessively thin-skinned or generic off-season stock.
- Prefer homegrown Hangjiao when a meaningful harvest is available; otherwise note the market variety or origin.
- Taste a small raw piece. If the heat is too punishing to eat 250g as a vegetable, use a milder identified long chilli or postpone.
## QUANTITIES
Portions: 2 generous vegetable-side portions.
- Long green chillies: 250g, stemmed and cut into broad pieces
- Eggs: 4 large
- Neutral oil: 30ml total
- Garlic: 2 small cloves, about 6g, finely chopped
- Scallion: 1 medium, about 16g, whites and greens separated
- Fine salt: begin with 2g; hold 1g reserve
## HOW TO COOK IT
1. Heat a dry wok or wide pan over medium-high heat. Add the chillies without oil and press against the surface, turning, for 3–5 minutes until irregularly blistered and softened while retaining shape. If the weak burner causes isolated scorching before the flesh softens, use no more than 5ml taken from the measured oil.
2. Beat the eggs with about 0.5g salt.
3. Heat 20ml of the remaining oil over high heat. Add the eggs and stir quickly into large soft curds; remove while slightly under-set.
4. Add the remaining oil, garlic and scallion whites. Fry for about 20 seconds without browning the garlic.
5. Add the blistered chillies and season with part of the remaining salt.
6. Return the eggs and add scallion greens. Fold briefly until the eggs are just set. Taste before using the salt reserve.
## WHAT SUCCESS LOOKS LIKE
The chillies are tender, blistered and still substantial rather than collapsed or raw-centred. Egg forms large soft curds. Garlic and scallion support the chilli without burying its sweetness, green fragrance, bitterness and heat.

Visual/technique reference — https://thewoksoflife.com/quick-egg-stir-fry-with-peppers/ — Observe dry-fried blistered long peppers and large soft egg curds. The source directly supports 227g peppers with four eggs, garlic and scallion. Ignore its soy, sugar, sesame oil, white pepper and Shaoxing wine; this simplified seasonal version uses salt as the sole liquid-free seasoning.
## WATCH OUT FOR
Do not turn this back into a side-by-side control, leave the pepper centres raw while burning the skin, introduce soy or bean paste, or overcook the eggs.
## STORAGE
Best fresh. Refrigerate leftovers promptly and reheat once; expect softer egg and chilli texture.
---
## PROCESS RECORD
{{MIGRATED_DISH_STATE_BLOCK}}
### Planning brief
Dish candidate: Hunan green-chilli and egg stir-fry
Purpose: Use genuinely good peak Italian long green chillies or homegrown Hangjiao as a chilli-as-vegetable dish and learn the balance between blistered chilli flesh and soft egg.
Role: non-main — side dish; the green-chilli and egg stir-fry is a small plate
Priors: None
Locks: None
Exemptions: None
Research emphasis: None
Destination section: Verification Queue — {{TARGET_SECTION_GID}}
### Decisions
Human — Marco: Remove the overcontrolled plain-versus-aromatic comparison and make one normal seasonal chilli-and-egg dish with garlic and scallion.
### Research basis
Classification: Source-backed dish
Construction — The Woks of Life, “Quick Egg Stir-Fry with Peppers,” https://thewoksoflife.com/quick-egg-stir-fry-with-peppers/ — uses 227g long hot green peppers, four eggs, oil, two garlic cloves and one scallion; dry-fries the peppers for 3–5 minutes, cooks soft eggs separately, then recombines them.
Project context — culinary-planning.md supports long green chillies as a Hunan chilli-as-vegetable lane while warning that cultivar quality matters.
Legacy material-change narration (not canonical Dish audit history and not Dish evidence):
2026-07-30 — Removed the two-pan controlled comparison, duplicate seasoning branches and scoring procedure; retained one sourced blistered-chilli, soft-egg, garlic-and-scallion construction; reset verification.
### Material changes
