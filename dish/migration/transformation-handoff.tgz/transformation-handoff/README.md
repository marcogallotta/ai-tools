# Corpus migration — offline transformation handoff

This is Open Decision #3's input package: give this to a fresh ChatGPT session to produce Dish
document templates for the corpus migration, per [`../../docs/rollout.md`](../../docs/rollout.md)'s
"Corpus migration" procedure and [`../corpus-migration-status.md`](../corpus-migration-status.md).

Contents:

- `cooking-raw-capture/` — exact source capture (name, notes, section, `modified_at`, SHA-256) for
  all 99 governed tasks, captured live 2026-07-31. `capture-manifest.json` is the index;
  `notes/<gid>.txt` holds each task's exact notes bytes.
- `honest-protocol-bundle/` — the current Honest protocol/schema assets from `~/honest-pantry`
  (`DISH_VERSION` = PROTOCOL_VERSION 1.0.10 / SCHEMA_VERSION 2, `dish-docs-design.md`,
  `dish-task-schema.json`, `dish-classes.md`, `dish-cooking-protocol.md`,
  `dish-planning-protocol.md`, `dish-research-protocol.md`, `dish-verification-protocol.md`,
  `dish-verification-protocol-compact.md`), copied 2026-07-31.
- `template-contract.md` — carried over from the reviewed v3 archive
  (`../corpus-migration-pre-batch-002-v3.tgz`). It was confirmed to match the rollout checkout at
  that review; it has not been re-diffed against the `honest-protocol-bundle/` copies above, so
  treat any apparent conflict between the two as a question to raise, not something to resolve by
  guessing which is current.

## What the fresh agent must do

Follow `dish-docs-design.md`'s corpus-migration procedure and
`corpus-migration-status.md`'s "Transformation contract" section exactly, in particular:

- Produce one Dish document template per task in `cooking-raw-capture/capture-manifest.json`
  (all 99 — the original 88, the 5 released Planned, and the 6 Korean).
- Do not fabricate or infer Research/Verification evidence, `ready` status, provenance, or
  destination data. Stop and ask when source facts are ambiguous, contradictory, or insufficient.
- For the 6 Korean tasks specifically: `Status` must reflect genuinely not-yet-researched/
  not-yet-verified. Do not start or imply Planning, Research, or Verification progress for them.
- Use `{{TARGET_SECTION_GID}}` and `{{MIGRATED_DISH_STATE_BLOCK}}` placeholders exactly as specified;
  neither may be resolved or fabricated by the transformation step.
- Return a manifest of produced templates plus an exceptions report for anything it stopped on.

This package is read-only input. It does not authorize any Asana write, Dish durable-state
mutation, or cutover step.
