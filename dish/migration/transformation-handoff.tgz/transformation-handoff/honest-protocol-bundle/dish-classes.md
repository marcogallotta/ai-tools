# Dish Classes — Cross-Cuisine Format Lens

A horizontal lens alongside `cuisine-map.md` (which cuisine gets effort) and each cuisine's
`planning/<cuisine>.md` (why that cuisine's trajectory looks the way it does): this file tracks dish
**formats** — the technique class a finished dish belongs to — across cuisines, so a recommendation
isn't limited to "go deeper in one cuisine" when "compare the same format across cuisines" is the
more useful move. It is the mechanism behind the contrast lane in `cuisine-map.md`'s tier-3 rules,
and behind the "before recommending a dish, scan for sister dishes/audit for untouched classes"
cross-cutting rule in `culinary-planning.md`.

Like `cuisine-map.md`, this is a maintained planning index, not raw evidence. The cooked-evidence
and concentration notes below are an incremental cache derived from `culinary-experience.md` and
Asana planning state; update this file when that evidence or relevant Asana planning state
materially changes instead of re-deriving the whole class map on every planning pass. Fall back to
`culinary-experience.md` and Asana, according to which cached claim is being checked, when an entry
is missing, contradicted, or being refreshed.

## How to update

This is an update, not a rebuild — same convention as `culinary-experience.md`'s regeneration
prompt. Read the current version first and merge in changes rather than regenerating from scratch,
so the judgment calls and corrections already made here (e.g. the mapo-tofu short-simmer caveat, the
dolsot-bibimbap correction) don't silently get re-lost.

**Last updated:** don't hardcode a date in this file — check
`git log -1 --format="%aI" -- dish-classes.md` for the actual last update, same as
`culinary-experience.md` does for its own regeneration cutoff.

**When to update:**

1. **A cooked dish fills a class** — this trigger fires every time `culinary-experience.md` is
   updated with new cooked-dish evidence, not just when noticed separately; that doc's own
   regeneration prompt now points back here for the same reason. Cross-check the new entries against
   the classes above; move a class's cooked-evidence bullet from "none cooked" to the real entry,
   and re-check its concentration read (a class can flip from thin to adequate, or from
   breadth-sampling to core-lane-depth if it turns out to sit on a mastery ladder).
1. **A new class or attribute is discovered** — via a fork/agent survey (like the tier-1/2 cuisine
   technique-taxonomy pass that found grill/skewer, hot pot, and the rice-format splits) or through
   ordinary conversation noticing a gap. Check it against "What counts as a class" above before
   adding it as a class rather than an attribute or ingredient track.
1. **A sister-dish candidate gets cooked** — move it out of the candidates list into cooked evidence
   for its class.

Not on a schedule — there's no cadence to this, it updates opportunistically whenever one of the
three triggers above happens, same as `culinary-experience.md`.

## What counts as a class (and what doesn't)

A dish class describes the **format of the finished dish** — what it'd be called on a menu, the
thing a sister-dish comparison is actually comparing (a bowl of noodle soup, a braise, a grilled
skewer). It is not a technique-skill, equipment constraint, or adaptation-difficulty dimension that
cuts *across* many formats — those are **attributes**, tagged onto a specific candidate dish at
planning time, not classes here. Examples of attributes, not classes: emulsification (a skill inside
korma, dressings, sauces), Instant Pot (equipment, modifies whether a braise-class dish is
cool-season-only or year-round), halal-substitution-intensity (how hard a dish is to adapt off its
pork/lard original), plant-gating (whether a dish depends on a limited homegrown herb), and
oil-reuse/inflammation caution (see Deep-fry below). Letting skill-axes become classes would explode
the list into every cooking skill that exists — keep the boundary strict.

## Main dish classes

Each class lists cooked evidence (cross-ref `culinary-experience.md`), sister-dish candidates not
yet cooked, and the concentration read (see the two-signal note further down).

### Rice porridge / rice soup / congee

- **Cooked evidence:** Vietnamese cháo gà rau răm; Indo/Malay bubur ayam (IP version, chicken/rice
  cooked together — good first cook but later reheated servings declined, fried-shallot technique
  not yet dialed in, see `planning/sea-core.md`); Subcontinent moong dal khichdi is a soft
  grain-legume cousin, not a direct analogue.
- **Sister-dish candidates:** Filipino arroz caldo is a tier-3 fallback. Thai khao tom gai is
  conceptually related but parked until the Thai dipping-sauce lane is built deliberately (see
  `planning/sea-core.md`).
- **Concentration:** Two tier-1/2 reps now (Vietnamese, Indo/Malay) rather than one; still thin
  overall — no repeat/refinement rep on either yet.

### Broth soups / light soups

Non-curry, non-noodle — miso isn't literally clear but sits in the same light/non-curry bucket.

- **Cooked evidence:** Thai tom yum, Vietnamese phở gà (once, good result — see multi-row note
  below), Vietnamese canh chua cá (hake, sweet-sour tamarind soup, once — broth good but too
  sweet-forward, not sour enough, see `culinary-experience.md`), Isan/Lao gaeng om, Japanese
  dashi/miso soup, Subcontinent sambar (dal-thickened cousin, caveat like khichdi).
- **Sister-dish candidates:** Korean miyeok-guk.
- **Concentration:** Thin in tier 1/2 — no Sichuan or Korean entry.

### Noodle soups

- **Cooked evidence:** Vietnamese phở gà (once, good result — see multi-row note below), Japanese
  udon/soba tests.
- **Sister-dish candidates:** Korean kalguksu / janchi guksu, Thai khao soi (rich/curry-adjacent).
- **Concentration:** Real gap — no Sichuan/Korean/Thai entry. **Noodle-making-block attribute:** a
  from-scratch Asian noodle (kalguksu, hand-pulled/knife-cut wheat noodles) is currently blocked
  more by never having made this specific dough/cut than by dough-handling skill generally — the
  pre-Asana baking era (`culinary-experience.md`'s "Pre-Asana baking, pastry, and dough experience"
  section) included repeated fresh-pasta dough work (lasagna sheets, phyllo, gnocchi, tagliatelle,
  ravioli, pizza dough), which is real prior art for rolling/cutting/hydration judgment but not a
  substitute for the specific technique of an Asian wheat noodle — treat it as an accelerant on a
  first attempt, not as evidence this class is already covered.

### Hot dressed / stir-fried noodles

Not soup, not cold.

- **Cooked evidence:** Sichuan Yibin burning noodles (elite, #1 dish), dan dan noodles (excellent),
  repeat dan-dan-style beef chard noodles (excellent, sesame-paste calibration), ants climbing a
  tree / mayi shang shu (delicious; mung-bean vermicelli's dry-absorption texture beat rice
  vermicelli, but the held/reheated sauce base lost aroma over successive servings — see
  `planning/sichuan.md`); Thai pad see ew (top-two Thai dish); Thai pad thai (cooked once, no
  outcome recorded — `culinary-experience.md`); Filipino pancit canton (good first pass, wrong
  noodle choice).
- **Sister-dish candidates:** Korean japchae, Vietnamese bún-style dressed bowl.
- **Concentration:** Sichuan core-lane depth (this is the noodle/sauce system described in
  `culinary-experience.md`'s Sichuan cross-dish finding) plus a strong Thai entry; gap is
  Korean/Vietnamese, not tier 1/2 generally.

### Braises / stews

Incl. master-stock/lu-braise and reduction-to-glaze kho/jorim sub-case.

- **Cooked evidence:** Sichuan mapo tofu (excellent, correction repeat cooked and diagnosed —
  technique-braise once the doubanjiang base is built, per `sichuan/cuisine-map.md`; **caveat: a
  short-simmer sauced braise, not long-braise evidence** — doesn't count against the master-stock/
  long-stew gap below); Italian spezzatino/cacciatore (strong), Vietnamese rau răm sticky wings,
  Vietnamese cà tím kho (first real kho-specific rep — caramel/fish-sauce/dark-soy reduction to a
  glossy glaze, 2026-07-10), Vietnamese gà kho gừng (excellent ginger-led caramel wing braise),
  Vietnamese cà tím đậu hũ kho (informative but not compelling aubergine-tofu adaptation), Maghreb
  tagine/chorba including fresh-apricot beef tagine, Persian khoresh-e gheimeh, Persian very-unripe
  plum khoresh (successful extreme-sour branch), Filipino adobo.
- **Sister-dish candidates:** Korean jjigae/jorim, Indo/Malay rendang/gulai (IP only in hot season);
  master-stock/lu-braise and long-simmer stew specifically still have no entry.
- **Concentration:** Sichuan has short-simmer core-lane evidence via mapo tofu; Vietnamese kho now
  has a small but real cluster across vegetable, tofu, and chicken rather than one isolated rep;
  Korean gap remains; master-stock/lu-braise and long-stew are the real thin spot, not the whole
  class.

### Dry stir-fry / dry-fragrant (干煸)

- **Cooked evidence:** Sichuan dry-fried green beans, dry-pot cauliflower; Subcontinent karahi; Thai
  pad kra pao; Vietnamese lemongrass-chilli chicken.
- **Sister-dish candidates:** Subcontinent jalfrezi — still open per `planning/subcontinent.md`,
  don't count it as cooked evidence for this class.
- **Concentration:** Adequate — breadth-sampling, not core-lane; low marginal value in adding more
  reps here.

### Sauced stir-fry / wok-glazed dish

Distinct from dry-fragrant — starch-slurry sauce coats and glosses rather than reducing to dry.

- **Cooked evidence:** Sichuan yuxiang chicken+eggplant (OK), yuxiang chicken+bamboo shoots (major
  win — sauce breakthrough), yuxiang qiezi with peak-season Italian aubergine and homemade pao
  lajiao (excellent; preferred aubergine version), gongbao chicken (dual-profile, also glazed); Thai
  pad makheua (fish-sauce/mushroom-oyster-sauce/Thai-basil glazed aubergine — liked, notably saltier
  than the other aubergine dishes in rotation but enjoyable, read as a distinct contrasting
  aubergine format, see `planning/sea-core.md`); Thai goong pad nam prik pao (shrimp glazed in
  homemade roasted-chilli-shrimp paste — excellent, distinctive, the fresh paste itself was the
  defining feature, see `planning/sea-core.md`).
- **Sister-dish candidates:** Thai cashew chicken, Korean spicy stir-fried squid/chicken, Vietnamese
  bò lúc lắc.
- **Concentration:** Sichuan core-lane depth — yuxiang is a named flavor-profile pillar, not
  breadth-sampling; tier-2 gap narrows further with a second Thai rep (pad makheua and goong pad nam
  prik pao), still thin outside Sichuan.

### Flash-fry at sustained extreme heat (爆炒/炝炒)

- **Cooked evidence:** Overlaps with dry-fragrant entries above but specifically
  wok-temperature-dependent.
- **Sister-dish candidates:** Gongbao chicken repeat once burner allows.
- **Concentration:** Burner-constrained, per `culinary-experience.md`'s dry-pot cauliflower note.
  **Equipment attribute:** no true wok hei on this burner — treat as aspirational, not plannable
  yet.

### Deep-fry in oil immersion (tod/gorengan/chiên/twigim)

- **Cooked evidence:** None cooked in this specific class within active Asana-era cuisine work —
  doesn't erase the deep general fried-fish background noted in `culinary-experience.md`'s Fish
  section, which is a different application of oil-frying skill, not evidence for this class. Pre-
  Asana background does include batter/oil-immersion frying itself: pakora (Subcontinent, savory
  batter fritter) and deep-fried donuts (sweet dough, not batter) both made repeatedly, per
  `culinary-experience.md`'s "Pre-Asana baking, pastry, and dough experience" section — real prior
  technique reps, but dated and not a substitute for tier-1/2 sister-dish evidence (chả giò, twigim,
  tod, gorengan) or current practice.
- **Sister-dish candidates:** Vietnamese chả giò, Korean twigim, Thai tod, Indo gorengan.
- **Concentration:** Real gap for tier-1/2 sister dishes, though not a fully blank technique — see
  pre-Asana pakora/donut reps above. **Caution attribute:** capped/deliberate oil reuse with a
  stable oil (peanut/rice bran), judged by smell/color/smoke-point rather than a fixed count —
  balances inflammation risk (Hu et al. 2024, *Microorganisms* 12(6):1210,
  doi:10.3390/microorganisms12061210, <https://pmc.ncbi.nlm.nih.gov/articles/PMC11205791/>) against
  waste (isrāf). **Ventilation/session-cost attribute:** batch deliberately as an occasional
  session, not a weeknight add-on.

### Blanch-then-hot-oil-pour (水煮 shuǐzhǔ)

- **Cooked evidence:** Sichuan shuizhu yu, shuizhu niu rou — strong.
- **Sister-dish candidates:** —
- **Concentration:** Sichuan-only; core-lane depth, not breadth-sampling.

### Twice-cooked / double-cook (回锅 huíguō)

- **Cooked evidence:** None cooked.
- **Sister-dish candidates:** Sichuan huiguorou-style halal adaptation.
- **Concentration:** Real gap in a named core Sichuan technique. **Halal-substitution attribute:**
  pork-belly-centered original; fatty beef offcuts are an imperfect substitute (same issue as
  dry-pot cauliflower) — only worth doing if the adaptation itself is the learning target.

### Smoke / cure / wind-dry (熏/腌/腊)

- **Cooked evidence:** None cooked anywhere.
- **Sister-dish candidates:** Sichuan camphor-tea duck (halal, duck not pork — lower substitution
  difficulty than most of this class), broader cured-meat halal substitution work.
- **Concentration:** Fully unexplored. **Halal-substitution and food-safety/space attribute:**
  mostly pork-based traditions (above-average substitution difficulty); curing/drying also needs
  food-safety discipline and fridge space this kitchen lacks (see `CLAUDE.md` storage notes).

### Grill / roast / open-flame / skewer

Broadened from skewer-only — also covers non-skewer roasted formats.

- **Cooked evidence:** None cooked anywhere.
- **Sister-dish candidates:** Vietnamese nướng, Korean gui, Thai kai yang, Indo/Malay sate.
- **Concentration:** Fully unexplored and **equipment-blocked** — no oven or true grill; only
  stovetop-pan approximations are possible, real open-flame/char isn't achievable here.

### Curry paste / rempah / spice-paste system

- **Cooked evidence:** Thai green/panang/chu chee (strong); Indonesian/Malay sambal goreng
  tahu-tempe (decent/successful guest-safe version, but aromatics under-extracted under time
  pressure); terong balado (successful on the corrective second pass — a small real oil-frying step
  materially improved aroma, integration, gloss, and coating, but did not rescue dull chilli
  colour).
- **Sister-dish candidates:** Indo/Malay short-cook or IP rempah dish (ayam masak merah,
  gulai-style); an IP-based lamb rendang or gulai kambing is a live hot-season candidate too, not
  deferred — per `planning/sea-core.md`'s hot-season rule, only a stovetop/oven long-cook reduction
  version of rendang is deferred, not the dish itself.
- **Concentration:** Thai-dominant; Indo/Malay now has two sambal/rempah reps but remains narrow and
  underdeveloped for its tier.

### Hot pot / communal simmer

Shared simmering vessel, diner-cooked-at-table — distinct from broth-soup and braise.

- **Cooked evidence:** None cooked yet, as far as this file's sources show.
- **Sister-dish candidates:** Sichuan mala hotpot/mala tang, Korean jeongol, Vietnamese lẩu, Thai
  suki, Japanese nabe.
- **Concentration:** Thin, worth having on the radar — not an urgent gap the way grill/roast is.
  **Social/equipment-scale attribute:** a hosting-session dish, not weeknight — ties to the
  local-circumstance hosting lane; the 6L pot covers the equipment need.

### Raw-herb salad / fresh-herb plate

- **Cooked evidence:** Thai green mango salad, Vietnamese gỏi gà rau răm, Levant fattoush (first
  cook poor/okay — bitter cucumber skin and tired herbs, diagnostic value only; repeat with
  purslane, 2026-07-13, clearly successful, confirming the first result was a produce-quality
  problem, not structural), Isan/Lao larb.
- **Sister-dish candidates:** —
- **Concentration:** Adequate — breadth-sampling. **Plant-gated:** check rau răm/Thai basil
  harvestability before planning.

### Pounded sour salad / som-tam-family

Fruit or vegetable pounded/bruised into a lime/fish-sauce/chilli/sugar dressing with optional
funk/crunch; distinct from raw-herb salad because the core learning is dressing extraction,
ingredient water-control, and sour/funk balance rather than herb freshness.

- **Cooked evidence:** Thai green mango salad (som tam mamuang-style, standout), Isan/Lao daikon som
  tam-style salad with carrot and peanuts (nice side, less exciting than green mango; needed
  stronger funk/aroma), peach salad with the same lime/fish-sauce/chilli/Thai-basil/peanut system
  (technically successful, not compelling — peach is already soft/sweet/perfumed so the dressing
  seasoned rather than transformed it; dropped as a standalone dish, better routed toward a creamy
  dairy pairing instead); Isan/Lao tam mak hoong with home-dried shrimp (pounded, pla
  ra/kapi-forward green papaya salad; strong fermented funk judged appropriate to style, not a
  defect) and Vietnamese nộm bò khô (tossed, soy-vinegar/biltong/Thai-basil green papaya salad)
  cooked same day for direct architecture comparison — Marco preferred the milder soy-forward nộm bò
  khô on the day (see `planning/sea-core.md`).
- **Sister-dish candidates:** fuller Thai yam mamuang/tam mamuang version with dried shrimp and
  roasted peanuts.
- **Concentration:** Now has a real cross-cuisine comparison (Lao pounded-fermented vs. Vietnamese
  tossed-soy architectures on the same green papaya base), not just single-cuisine reps. Still
  ingredient-sensitive. Green papaya is not worth a dedicated Milan/Turin trip on its own per
  `planning/sea-core.md`; use opportunistic substitutes or reraises when sourcing already lines up.

### Dip / mezze spread (bread-scoop format)

Distinct from the ferment-based condiment/paste pantry systems below — a dip/spread is eaten as the
dish itself (scooped with bread), not consumed as an input inside a separately cooked dish.

- **Cooked evidence:** Informal, uncaptured — Levant yogurt-lemon chicken sauce, beef kofta's
  parsley yogurt, Persian dill cucumber yogurt (mast-o-khiar) are all herb-varied yogurt dips/sauces
  already cooked but never logged as a coherent thread; see `culinary-experience.md`. Mostly
  incidental (cooked because yogurt was already being eaten, not a deliberate herb comparison), so
  treat as suggestive, not rigorous technique-building evidence. Levant mutabbal (charred
  whole-aubergine tahini dip) is the first deliberate, logged cook in this class: the direct-flame-
  char/whole-fruit-collapse/hand-mash technique was genuinely novel and flavour was strong, though
  the skin ruptured before the interior fully collapsed, leaving texture chunkier than intended — an
  execution finding, not a structural failure (`1216470745791137`, `planning/med-group.md`).
- **Sister-dish candidates:** Muhammara, hummus (Levant) remain uncooked. Korean ssamjang has a
  similar scoop-with-vehicle architecture but is eaten alongside a separate main (ssam wrap), not as
  a standalone course — related, not a direct sister.
- **Concentration:** One real deliberate cook now (mutabbal) beyond the incidental yogurt dips;
  muhammara and hummus are still open.

### Raw protein preparation (hoe/yukhoe)

- **Cooked evidence:** None cooked.
- **Sister-dish candidates:** Korean yukhoe.
- **Concentration:** Fully unexplored. **Food-safety gating attribute:** requires trusted fresh
  sourcing, same-day handling, and temperature control — only plan against a real sourcing/handling
  protocol, not as a casual first attempt.

### Omelette / pan-set egg

A single coherent format — distinct from the broader egg-centered ingredient track, which covers
custard/soup/sauce forms instead.

- **Cooked evidence:** None cooked.
- **Sister-dish candidates:** Thai khai jiao, Korean gyeran-mari, Japanese tamagoyaki, Subcontinent
  omelette/bhurji cousin.
- **Concentration:** Fully unexplored.

### Blanch-and-dress vegetable side (namul-style)

- **Cooked evidence:** Italian cime di rapa / rapini blanched salad/side (manual evidence); foraged
  nettles blanched/wilted spinach-style (handling evidence, not a fully diagnosed dressed side).
- **Sister-dish candidates:** Korean namul.
- **Concentration:** No longer blank as a handling format, but still a tier-1 Korean gap — distinct
  from muchim (raw-toss), raw-herb salad (never-cooked), and cooked bitter-greens ripassata-style
  sides.

### Cold dressed noodles / cold sauce plates

Incl. cold dressed protein.

- **Cooked evidence:** Sichuan ma la cold noodles, red-oil cold chicken, guaiwei jisi (definite
  keeper; the multi-axis balance held even with commodity chilli inputs — see
  `culinary-experience.md`).
- **Sister-dish candidates:** Korean bibim-guksu/naengmyeon-class.
- **Concentration:** Strong Sichuan evidence across noodle and protein formats; the real gap is
  outside Sichuan.

### Steamed custard / steamed set protein

- **Cooked evidence:** Thai hor mok-style hake (needs correction).
- **Sister-dish candidates:** Korean gyeran-jjim (already planned), Japanese chawanmushi.
- **Concentration:** Thin.

### Stuffed / parcel-steamed / leaf-wrapped format

Split out — a genuinely different technique from custard/set-protein.

- **Cooked evidence:** None cooked.
- **Sister-dish candidates:** Indonesian pepes, stuffed vegetables, leaf-wrapped parcels, whole fish
  steamed in leaf/parcel form (would expand whole-fish evidence into parcel-steam territory, but
  does not count against the separate grill/open-flame gap noted under Whole-fish preparation below
  — steaming isn't grilling).
- **Concentration:** Fully unexplored.

### Savory batter pancake (jeon/bánh xèo/bakwan)

- **Cooked evidence:** None cooked.
- **Sister-dish candidates:** Korean jeon, Vietnamese bánh xèo, Indo bakwan.
- **Concentration:** Fully unexplored.

### Dumpling / wrapped format

Incl. table-wrap ssam as a soft sub-case.

- **Cooked evidence:** Sichuan — a first batch of standard Sichuan dumplings already made and in the
  freezer (tracked in the Cooking Asana project); not yet cooked/tasted as a finished dish as far as
  this file's sources show.
- **Sister-dish candidates:** Sichuan hong you chao shou / zhong shui jiao (the sauced/dressed
  serving format, distinct from the frozen dumplings above), Vietnamese gỏi cuốn, Korean mandu.
- **Concentration:** Less thin than it looked — a batch already exists, just not yet cooked and
  evaluated. Not the clearest single gap; see Grill/roast for that instead.

### Fried rice / wok rice

Rice fried in, split from topped-rice below — different technique.

- **Cooked evidence:** Indo/Malay nasi goreng kampung.
- **Sister-dish candidates:** Korean kimchi-bokkeumbap (once kimchi/jang state supports it), Sichuan
  fried rice (only with a leftover/product-test reason).
- **Concentration:** Thin. **Leftover-dependency attribute:** best planned against leftover cold
  rice, not fresh-cooked (see nasi goreng's fix note in `culinary-experience.md`).

### Topped rice bowl / mixed rice plate

Rice as base, protein/topping plated over — not fried in, a different architecture from the row
above.

- **Cooked evidence:** None cooked.
- **Sister-dish candidates:** Korean bibimbap, Japanese donburi, Thai khao man gai, Indo/Malay nasi
  lemak/nasi campur.
- **Concentration:** Fully unexplored.

### Claypot / one-pot rice

Rice cooked with other ingredients in one vessel from raw — distinct from both rows above. Note:
dolsot bibimbap is rice crisped *after* cooking, not cooked-from-raw-in-vessel, so it belongs under
Topped rice bowl above, not here.

- **Cooked evidence:** Subcontinent biryani (pakki milestone reached, "strong" per
  `culinary-experience.md`).
- **Sister-dish candidates:** Sichuan claypot rice, Korean sotbap.
- **Concentration:** Tier-3/local-circumstance evidence exists via biryani; tier-1/2 gap remains (no
  Sichuan or Korean entry).

### Bread / flatbread

Incl. steamed bun/bao (mantou, baozi) as a subcase, distinct from oven/pan bread but grouped here
rather than as a full separate row.

- **Cooked evidence:** Maghreb khobz/msemen, Subcontinent roti; Ethiopian injera (solid homemade
  result, later judged very comparable after eating injera in Ethiopia; manual background evidence,
  exact method not captured).
- **Sister-dish candidates:** Sichuan/Northern Chinese mantou, bing, or baozi, only if tied to a
  specific dish, not a standalone priority.
- **Concentration:** Not urgent; no East Asian tier-1/2 entry, low priority.

## Checked but not currently promoted

Recent cooked evidence that was cross-checked against this file but does not currently warrant a
class entry:

- **Peach and burrata raw summer fruit-and-cheese plate** — useful Mediterranean seasonal-produce
  evidence, but no live tier-1/2 sister-dish comparison or business lane. Revisit only if raw
  produce-and-dairy plates become a deliberate local/seasonal format, not just because one plate was
  successful.
- **Plum, burrata, and mint on brown seeded toast** — checked as a direct seasonal comparison to
  peach and burrata; the sharper plum integrated less naturally and the seeded bread was too heavy.
  Useful evidence, but it does not create a new live class or priority.
- **Raw courgette ribbons with lime and Parmigiano** — successful produce-quality and immediate-
  dressing evidence, but not a raw-herb plate and not currently part of a tier-1/2 sister-dish
  comparison. Keep as checked seasonal evidence rather than promoting a class.
- **Panzanella with brown seeded bread and weak cherry tomatoes** — useful evidence for tomato-
  salad-as-sauce and bread-as-absorber mechanics, but not currently a cross-cuisine class priority.
  Revisit only if bread-soaked/chopped salad formats become a deliberate local/seasonal comparison.
- **Puntarelle / catalogna shoots, regular raw preparation** — useful bitter-green salad evidence,
  separate from cooked catalogna ripassata and blanch-and-dress greens, but not currently a tier-1/2
  sister-dish class.
- **Italian bitter-green side batch** — radicchio seared, scarola wilted with olives/capers,
  catalogna ripassata, and coste/chard ribs with garlic/lemon were cross-checked. They matter for
  Mediterranean/local greens literacy and stem/leaf handling, but do not currently promote a new
  cross-cuisine class beyond the blanch-and-dress note above.

## Pantry systems that drive dish classes

Not dish classes themselves — a ferment/paste is an input consumed across many different formats
above, not a format in its own right (see "What counts as a class" above). Progression already
tracked in dedicated files; this section only points there, it doesn't duplicate:

- **Ferment-based condiment/paste** — `sichuan/chilli-oil.md`, `sichuan/sesame-paste.md`, Korean
  jang/kimchi staged plan in `planning/korean.md`.
- **Chutney / pickle / relish** — Subcontinent apricot chutney, Sichuan suan cai/pao lajiao as
  pickle; no dedicated file yet.

## Ingredient tracks

An ingredient that recurs across many *different* format classes above (not a format itself) — the
same shape as whole-fish. Kept here so tofu/egg-centered dishes don't get invented as a new format
class when they're really an ingredient cutting across braise (mapo), steam
(agedashi/chawanmushi-adjacent), broth-soup (sundubu-jjigae), and stir-fry classes that already
exist.

- **Whole-fish preparation** — existing-strength lane per `planning/fish.md`, not a gap to plan
  against. **Caveat:** this strength is pan-sear/cure/steam/stovetop handling, not grill/open-flame
  evidence — don't let it mask the Grill/roast class's gap. Ikan balado (whole mackerel, chilli
  sambal) extends whole-fish evidence into a sambal-coated format but still doesn't count toward
  grill/open-flame.
- **Tofu / bean curd** — Sichuan mapo tofu (excellent, strong evidence, filed under Braise above);
  thin elsewhere — Korean dubu-jorim/sundubu-jjigae, Japanese agedashi/hiyayakko, Vietnamese đậu phụ
  sốt cà chua all uncooked.
- **Egg-centered dishes, custard and soup/sauce forms only** — pan-set omelette was pulled out as
  its own main-dish-class entry above (see Omelette / pan-set egg), since it passes the "what's on
  the menu" test as a single format, unlike this catch-all. Thai hor mok (filed under Steamed
  custard above) and Subcontinent methi eggs (a bhurji/scramble-in-sauce cousin, not a clean example
  of either sub-form) are cooked; Korean gyeran-tang/egg-drop soup forms still uncooked.

**Ingredient-authenticity/sourcing-gate note:** some candidate dishes above collapse without a
specific correct ingredient (Korean gochugaru/jang, Sichuan doubanjiang/huajiao, Thai
basil/holy-basil distinction, rau răm, fresh rice noodles) — check the Pantry Asana project and
relevant sourcing docs (`import-strategy.md`, cuisine pantry files) before committing to one of
these, rather than restating sourcing status here.

**Stock/broth-dependency attribute:** broth soups, noodle soups, rice porridge, and hot pot (plus
some braises) depend on the quality of their stock/broth base — plan around an existing stock/bones/
shells or a deliberate broth-making session, not as a quick weeknight add-on.

**Batch/freezer-suitability attribute:** dumplings, stocks, curry pastes/rempah, fried items, and
hot-pot bases are good candidates for a deliberate prep/batch session rather than a one-off dinner —
this is just the freezer-forward storage default already set in `CLAUDE.md` (small fridge, large
freezer) applied to these specific classes, not a new rule.

**Multi-row counting note:** a dish can legitimately count as cooked evidence in more than one class
when it genuinely teaches both formats (phở gà counts toward both broth-soup and noodle-soup
architecture) — but don't let that inflate the read of either class into two separate successes when
it's one cook's evidence.

## Concentration flag: two different signals, not one

"Thin" or "fully unexplored" means a real gap worth noticing — not automatically a dish to schedule.
Tier priority, equipment (grill/oven access), season, food-safety gating, and sourcing all still
decide whether a gap becomes actionable (see the equipment-blocked grill entry, the
food-safety-gated raw-protein entry, and the halal-substitution-flagged twice-cook/smoke entries
above for cases where a real gap isn't currently plannable). Separately, "adequate" does **not**
automatically mean diminishing returns — check whether the class is a named pillar of a tier-1
mastery ladder (`sichuan/mastery-priority.md`, `sequence.md`'s gates, Korean's staged plan) before
treating more reps as low-value:

- **Core-lane depth** — the class is a named mastery-ladder pillar for a tier-1 lane. More reps are
  deliberate skill-building toward a business gate, not sampling — no "enough already" signal
  applies regardless of rep count (e.g. blanch-then-hot-oil-pour for Sichuan).
- **Breadth-sampling** — the class isn't tied to a specific lane's mastery ladder; it's general
  technique/palate exposure (e.g. raw-herb salad across four cuisines, dry-fragrant across four
  cuisines). Diminishing returns is a real signal here — another rep teaches less than filling a
  zero-entry class.

## How to use this

1. When a dish just cooked opens a recognizable format, or when auditing what to cook next, scan the
   classes above for the one that format belongs to.
1. Use this file as the maintained dish-class planning index. Check `culinary-experience.md` when an
   entry is missing, contradicted, being refreshed, or when new evidence has been added since the
   last dish-class update.
1. Use `cuisine-map.md`'s tiers to decide which sister-dish candidate gets priority — a thin/
   unexplored class doesn't override tier; it tells you where a tier-1/2 sister dish would teach the
   most, and it's the concrete test for whether a tier-3 candidate qualifies for the contrast lane.
1. Check the concentration flag's two signals before treating "adequate" as a reason to move on — a
   core-lane-depth class still deserves more reps if it's on a mastery ladder.
1. Check for attribute flags (plant-gating, oil-reuse caution, burner constraint, halal-substitution
   difficulty) before committing to a specific candidate — these aren't in the class entry, they're
   conditions on the specific dish.
