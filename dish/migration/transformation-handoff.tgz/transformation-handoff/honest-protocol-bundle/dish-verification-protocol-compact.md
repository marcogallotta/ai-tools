# Dish Verification Protocol — Compact Test Variant

**Status:** Proposal for rollout testing. It does not replace the current beta.
`dish-verification-protocol.md` is authoritative; this compact variant must preserve every routing,
independence, correction, hold, approval, and submit invariant it defines, and is stale wherever the
two diverge until reconciled.

Decide whether the exact dish task is safe and reliable enough to sign. Material means a plausible
failed cook, hard-constraint breach, changed dish or comparison, impractical execution,
contradiction of Marco's decision, or false approval.

"Review" means run this pass and report signability and blockers. Unless Marco explicitly requests
read-only review, resolve every agent-owned correction the verifier can confidently complete.
Signoff, movement, or rejection still requires its normal authorization.

The release frozen when the task enters `pending-verification` governs through signoff. Verify
against the exact text identified by `Verification protocol release`; if it cannot be recovered,
report the release blocker and stop. When starting a new cycle after a material edit, use the latest
Git commit that changed this file, or without Git use the SHA-256 of the exact text plus read time.

## State

The task contains these lines exactly once; use literal `None` where inapplicable:

```text
Status: pending-research | pending-evidence | pending-human-review | pending-verification | ready
Status detail: None | <one-sentence immediate work, evidence request, or decision>
Resume status: None | pending-research | pending-verification
Verification protocol release: None | <release>
Researched by: <agent> — <model>, <YYYY-MM-DD>
Verified by: None | <agent> — <model>, <YYYY-MM-DD>
Self-verified: None | <agent> — <model>, <YYYY-MM-DD>
```

Accept only these combinations:

- `pending-research`: detail required; resume, release, and `Verified by` are `None`;
  `Self-verified` may be `None`.
- `pending-evidence`: detail names the missing fact, reason, and exact evidence; resume the
  interrupted phase. Preserve the release only when resuming Verification; `Verified by` is `None`.
  `Self-verified` may be `None` only when resuming Research.
- `pending-human-review`: detail and resume required. Preserve the release only when resuming
  Verification. Preserve the valid `Self-verified` value from the interrupted phase; it may be
  `None` only when resuming Research.
- `pending-verification`: frozen release and completed `Self-verified` required; detail, resume, and
  `Verified by` are `None`.
- `ready`: frozen release, completed `Self-verified`, and completed `Verified by` required; detail
  and resume are `None`.

`Researched by` always records the original constructor. `Self-verified` is `None` until an exact
candidate has been reviewed end to end by its latest material editor; afterward it records that
editor. A fresh independent run that did not construct or materially edit that candidate must
perform signoff. `Status` is the sole readiness field. Routine stock, thaw, soak, harvest, sprout,
and ferment-start checks remain title brackets plus `CHECK BEFORE COOKING`; they do not change
Status.

## Review

Verify only when `Status` is `pending-verification`. For any other status, report the next pending
action and stop without running the pass, correcting, signing, or moving the task. Marco's explicit
`override` bypasses this entry gate: run the pass and record exactly which gate was waived. Every
normal pass uses a fresh run by any agent that did not construct or materially edit the exact
candidate. A fresh run means a distinct agent invocation carrying its own `client.run_id`, not
merely a new governed operation ID or Verification cycle ID opened inside an ongoing run. Verifier
identity and agent/model family (Claude, Codex, ChatGPT, or the Custom GPT) describe who ran the
pass, not whether it was independent. A run is independent of the constructor or material editor
only when its `client.run_id` differs from the run that constructed or last materially edited the
exact candidate; the same agent, model, or verifier identity may recur across genuinely separate
runs. A new operation or cycle ID alone, issued inside the run that constructed or edited the
candidate, does not establish independence.

First read the task, its Planning brief, its material sources, and only the live context needed to
test a material claim. Do not read the Research Protocol.

Work by recognition, not deliberation. Almost every defect worth catching is one an experienced cook
sees immediately: the wrong physical result, liquid carried unchanged across a vessel change, a
fragile component batched. Do not build long chains of reasoning to reach them, and do not narrate
the pass. A finding that needs a long argument to justify is usually not material.

Check these five things. The first is the job: a task can have correct quantities, sound sources,
and a clean state block and still produce a failed dish.

1. **It will come out as the dish.** Read it as the cook standing at the stove and find where it
   breaks. The method must produce the dish's defining physical result — wet paste not dry rub,
   reduced glossy sauce not thin liquid, crisp not steamed, tender not tough. Where a method was
   transposed to a different vessel or heat mode — stovetop to pressure, wok to pan, simmer to
   braise — liquid, reduction, and timing are recalculated for the new one rather than carried
   across unchanged. Where a cut, form, or substitute was chosen, it still delivers the stated
   Purpose. Report anything an experienced cook would expect to fail, even where every quantity,
   source, and field is correct.
1. **It is the agreed dish.** The dish, purpose, role, priors, locks, exemptions, Research emphasis,
   and Marco's recorded decisions are preserved. Any material departure is supported and approved.
   Do not re-litigate an approved intentional test or identity classification merely because a
   conventional route is safer or more authentic; its still-unknown outcome does not block `ready`.
1. **It can actually be cooked as written.** Buying and ingredient quantities reconcile against
   `pantry-snapshot.md`; arithmetic, units, portions, nutrition, equipment, ordered method, stop
   points, storage, and success boundaries are workable. No pork or added alcohol; aquatic animals
   and derivatives are only fish and shrimp. Nutrition applies to main tasks only. `[non-main]` is
   an identity claim — a dessert, small side, or little test dish, matching the brief's `Role` and
   stating its kind and reason — never a way to miss a limit; a dish eaten as a main stays main and
   takes a `[nutrition-*]` exemption. For a main, nutrition covers the complete portion: block
   outside 700–1,000 kcal, below 35 g protein, or above 40 g fat; every fat excess requires Human
   Review and is presumptively rejected. Confirm purchase-price Human Review above EUR22/kg for
   boneless, filleted, or peeled meat/seafood; above EUR16/kg for bone-in or shell-on meat/seafood;
   and above EUR15/kg for fish sold whole. The whole-fish rule controls for fish sold whole;
   otherwise use the purchased form. Do not calculate usable yield. These prices are escalation
   triggers, not budget ceilings: crossing one is permitted with Human Review, and staying under one
   never justifies a worse dish. Confirm fragile components are handled per sitting and equipment
   limits are respected. Pre-cook title markers and `CHECK BEFORE COOKING` must be truthful and
   actionable, but routine pre-cook items are not system-state blockers.
1. **The important claims are supported.** The task uses one coherent construction rather than a
   silent blend. Any substitute, including the chosen cut or form, preserves the dish's Purpose,
   defining identity, and lesson; lower cost or easier sourcing does not justify a material
   compromise or bypass Human Review. Material ratios, methods, substitutions, and adaptations have
   exact accessible support, an explicit close-precedent inference, or an approved test
   classification. A broken, placeholder, or non-resolvable locator counts as missing support. When
   only Marco can supply a material factual input, use `pending-evidence`, request the exact
   evidence, and stop; resume the interrupted phase after receipt. Do not call it Human Review
   unless Marco must choose, authorize, or accept a material change.
1. **The record and state are honest.** The task body, Planning brief, Decisions, Research basis,
   Material changes, fixed state block, and destination agree. A material prior-cook claim rests on
   the Planning brief's priors; do not read Asana cooking history. The closing `Schema version` line
   is present and matches the current `SCHEMA_VERSION`; an older value means migration, not signoff.
   `prepare` validates the destination structurally at every write, so a bad destination normally
   fails Planning or Research, not Verification. If it becomes invalid only after handoff — the
   section is renamed or removed while the task sits in Verification — the resulting failed final
   move is a hard error: stop immediately, leave the task exactly as the tool left it, and report
   the blocker to Marco. Do not attempt to correct the destination, retry with a guessed value, or
   open a `pending-human-review` cycle for it; this follows the same rule as any other failed or
   uncertain tool result. Each `Material changes` entry identifies date, editor/model, what changed,
   why, whether the change was material, and verification state, in this exact grammar:
   `<date> — <agent> — <model> — <change> — <reason> — <materiality> — <verification state>`, for
   example
   `2026-07-20 — Claude — claude-sonnet-5 — recalculated braise liquid for the pressure conversion — stovetop volume was carried over unchanged — Large — pending-verification`.
   On approval, the tool finalizes a tool-generated change-flow entry's `<verification state>` to
   `verified — <agent>, <model>, <date>`, and it stays finalized after submit; do not hand-edit it.

## Result

State whether the task is signable. Report every blocker, any material correction, and only genuine
Marco decisions. Resolve arithmetic, source access, and minor corrections yourself.

Keep the report short: one line per defect naming what breaks and at which step, then the verdict.
Do not restate the task, summarize what you read, or show your working.

Small preserves the settled construction and only makes execution compliant. Large materially
changes identity or route; quantities, ratios, portions, nutrition; a decision, lock, exemption, or
test; or feasibility, safety, halal, sourcing, or risk. A Small correction may be fixed, recorded in
`Self-verified` with the verifier/editor model and date, rechecked, and signed in the same pass. For
a Large but resolvable correction, the verifier fixes it, records the change, updates
`Self-verified`, clears `Verified by`, freezes a new release, and leaves
`Status: pending-verification`; a fresh independent run must verify the corrected artefact. Use
`pending-evidence` or `pending-human-review` only when Marco must supply a fact or make a decision.
A Human Review interruption preserves the frozen release unless its resolution requires a material
edit. After two unsuccessful independent passes, stop: set `Status: pending-human-review` with
`Resume status: pending-verification`. Only Marco's admin action reopens it, after recording the
concrete change in evidence, premise, method, or scope.

Sign only the exact final content. Set `Status: ready`, retain the frozen release, and set
`Verified by` to the signing agent, model, and date. On authorized signoff, move a task currently in
the runtime-context Verification Queue to its recorded Destination only when the destination is
valid. Never move a rejected task or a task manually positioned outside the queues. Runtime context
is authoritative for project and section identifiers; this protocol's text is authoritative for
workflow semantics.

## Mandatory dish-tool boundaries

Run the Verification boundary check before semantic review, after every Small or Large correction,
and immediately before signing the exact final live task. Small may sign in the same pass only after
write, reread, and recheck; Large remains `pending-verification` for a fresh independent verifier.
Any post-signoff material body edit opens a new cycle. After successful approval, run the returned
`submit` action in the same pass. Tool pass is deterministic conformance only, never
semantic/provenance approval. Tool failures are tooling failures, not dish blockers; on
tool/protocol disagreement, or any failed or uncertain tool result, stop, leave the task exactly as
the tool left it, and report; never repair it by hand. This protocol wins. See
`dish verification --help` for the boundary-check command — shell-agent guidance for Claude/Codex;
the Custom GPT follows the Verification Action sequence in `dish-custom-gpt-instructions.md`, not
this help text. This protocol governs when the stage is done, not how its Actions are called.
