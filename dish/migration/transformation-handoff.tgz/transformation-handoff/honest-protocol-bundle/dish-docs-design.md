# Dish system remaining design

This document records unresolved Honest-side dish-system design and the stable corpus-migration
invariants that the production rollout imports.

## Authority and current state

Current behaviour is authoritative in:

- `dish-planning-protocol.md`, `dish-research-protocol.md`, `dish-verification-protocol.md`, and
  `dish-cooking-protocol.md`;
- `dish-task-schema.json`, `dish-schema-migrations/`, and `DISH_VERSION`; and
- the implemented Dish architecture and runtime contract under `../ai-tools/dish/`.

Completed implementation plans and compatibility analyses belong to Git history, not this remaining
design register. Unimplemented tool work is tracked only in
[`../ai-tools/dish/docs/future.md`](../ai-tools/dish/docs/future.md). Older incident or review
entries may cite sections removed from this file; those references are historical provenance in Git
and do not override the current assets named above.

Dish implementation and connectivity are complete; production activation is not. `rollout.md` owns
Honest-side semantic release evidence, while
[`../ai-tools/dish/docs/rollout.md`](../ai-tools/dish/docs/rollout.md) owns the coordinated
test-project rehearsal, operational migration, production cutover, and rollback.

This document records design, not authorization. It does not authorize production edits, Asana
writes, migrations, or tool changes.

## Settled rollout boundary

The protocol/schema overhaul and compatible Dish tool/service release activate together. Do not
leave production using a mixed protocol, schema, repository-routing, tool, service, or database set.

The release freezes an exact compatible Honest revision and Dish revision, passes the joint semantic
and operational gates, and activates only after Marco's separate production authorization. Current
protocol prose governs active current-schema tasks; a task's `Schema version` is a
data-compatibility marker, not a permanent pin to old protocol behaviour.

No remaining tool implementation plan lives here. Any activation decision that does not change the
protocol's own structure belongs in the operational rollout runbook.

## Corpus-migration invariants

Corpus migration begins only after the bundled semantic and operational rehearsals pass:

1. Snapshot the complete approved target corpus to disk and archive it as a tarball.
1. Give a fresh agent the snapshot and final protocol bundle to produce the migrated corpus locally,
   removing legacy structure without inventing content that requires judgment.
1. Run deterministic validation over every result and return each structural failure for correction
   until the corpus passes.
1. Upload through a script that stops instead of overwriting when a live task no longer matches its
   snapshot input.
1. Never infer `ready`, provenance, Human decisions, or destination data.
1. Activate matching protocol authority, repository routing, Dish service, and compatible database
   state as one deliberate cutover.
1. Retain the prior project and database snapshot until the migration is accepted.

Completed historical tasks remain untouched unless deliberately reopened, when they must migrate
before substantive work. `dish-admin migrate` handles an individual older-schema task encountered
after cutover; it is not the initial corpus-migration mechanism.

Corpus migration requires deterministic structural validation, not per-task semantic attestation or
a claim of semantic equivalence. The operational runbook owns whether to retain a one-task
operational canary. If retained, that canary tests the migration and lifecycle machinery; it does
not semantically attest the remaining corpus.

## Remaining design

### Cooking destination sections

Cuisine destination sections may later be replaced by queues that mirror workflow state, followed by
a ready set divided by dish kind or what a dish awaits. These are separate axes: a task waiting for
a seasonal ingredient may still be fully designed and retain `Status: ready`.

`Status` remains authoritative and section placement is derived from it, never the reverse. Current
destination metadata remains mandatory until a replacement model is designed and migrated
atomically.

Still design:

- the ready-set divisions, names, and admission criteria;
- precedence when several waiting conditions apply;
- whether Global Planning owns prioritisation instead of section placement;
- mapping and review of the live corpus; and
- the migration procedure for the replacement taxonomy.

### Ingredient-led dish discovery

Given an ingredient, the future system should return live dishes that use it, required form and
quantity, and which matters most to cook next. For time-sensitive purchasing, it should show which
purchase unblocks the most important dishes.

Still design:

- authoritative inputs and ingredient/form normalization;
- quantity extraction and treatment of uncertain mentions;
- index ownership, storage, and freshness; and
- priority ranking.

Do not create a new task taxonomy merely to support discovery.

### Wide batch or snapshot review

A later audit may give one agent a large raw task snapshot without the ordinary protocol checklist
or incident-specific seeds. Its purpose is to find corpus-wide patterns such as copied assumptions,
recurring contradictions, systematic gaps, or verifier blind spots.

Findings must remain concrete task-level catches and be checked against each task's Decisions and
process record before becoming live gaps. A synthesized narrative is not evidence by itself, and
this audit does not replace independent per-task Verification.

Still design:

- snapshot scope and grouping;
- cadence or trigger;
- output and expected-finding records;
- Decisions reconciliation; and
- the threshold and route for promoting repeated patterns into the review log or protocol design.

## Evidence records

`dish-review-log.md` is the evidence register for validation catches and process patterns.
`dish-incident-log.md` records incidents, protected outcomes, grades, and approvals. Neither is an
implementation specification or a substitute for the current protocols, rollout record, or
architecture.
